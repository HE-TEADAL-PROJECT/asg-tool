"""
Classes and functions supporting models hosted on IBM BAM.
"""

from typing import Any, Dict, List
from genai.client import Client, Credentials
from genai.extensions.langchain import (
    LangChainEmbeddingsInterface,
    LangChainInterface,
)
from gin.common.types import PlatformCredentials


class LangChainEmbeddingsInterface(LangChainEmbeddingsInterface):
    def rerank(self, query: str, docs: List[str]):
        """Perform reranking for the given docs to the given query."""
        response = self.client.text.experimental.rerank.create(
            parameters=self.parameters,
            model_id=self.model_id,
            query=query,
            documents=docs,
        )
        return response


# Client cache, indexed by endpoint + key
client_cache = {}


class BAM:
    @staticmethod
    def get_llm_interface(
        model_id: str,
        credentials: PlatformCredentials,
        params: Dict[str, Any] | None = None,
    ):
        """
        Get a language model hosted on BAM.
        model_id (str): Model ID.
        credentials (PlatformCredentials): Credentials for BAM.
        params (Dict[str, Any] | None): Parameters for the model.

        Returns:
            LangChainInterface: Language model hosted on BAM.
        """

        client = get_bam_client(
            credentials.api_key.get_secret_value(), credentials.api_base
        )
        return LangChainInterface(
            client=client, model_id=model_id, parameters=params
        )

    @staticmethod
    def get_embedding_interface(
        model_id: str,
        credentials: PlatformCredentials,
        params: Dict[str, Any] | None = None,
    ):
        """
        Get a embeddings model hosted on BAM.

        Args:
            model_id (str): Model ID.
            credentials (PlatformCredentials): Credentials for BAM.
            params (Dict[str, Any] | None): Parameters for the model.

        Returns:
            LangChainEmbeddingsInterface: Embeddings model hosted on BAM.
        """

        def rerank(self, query: str, docs: List[str]):
            """Perform reranking for the given docs to the given query."""
            response = self.client.text.experimental.rerank.create(
                parameters=self.parameters,
                model_id=self.model_id,
                query=query,
                documents=docs,
            )
            return response.result.results

        client = get_bam_client(
            credentials.api_key.get_secret_value(), credentials.api_base
        )
        LangChainEmbeddingsInterface.rerank = rerank
        embedding_model = LangChainEmbeddingsInterface(
            client=client, model_id=model_id, parameters=params
        )
        return embedding_model


def get_bam_client(api_key: str, api_base: str) -> Client:
    """
    Get a BAM client, pulling from cache if one already exists.

    Args:
            api_key (str): API key for BAM.
            api_base (str): API endpoint for BAM.

    Returns:
        Client: Client to BAM.
    """
    if api_base + api_key in client_cache:
        return client_cache[api_base + api_key]
    client = Client(
        credentials=Credentials(api_key=api_key, api_endpoint=api_base)
    )
    client_cache[api_base + api_key] = client
    return client
