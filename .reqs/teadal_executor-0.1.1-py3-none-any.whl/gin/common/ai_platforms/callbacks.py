from typing import Dict, Any, List

import logging

from langchain.callbacks.base import BaseCallbackHandler
from langchain.schema import LLMResult

from gin.common.logging import Logging


class LoggingCallbackHandler(BaseCallbackHandler):
    """
    Callbacks for printing LLM prompt and response.
    """

    def on_llm_start(
        self, serialized: Dict[str, Any], prompts: List[str], **kwargs: Any
    ) -> Any:
        """Run when LLM starts running."""
        llm_log = logging.getLogger(Logging.LLM)
        for prompt in prompts:
            llm_log.info("***LLM prompt***\n%s\n", prompt)

    def on_llm_end(self, response: LLMResult, **kwargs: Any) -> Any:
        """Run when LLM ends running."""
        llm_log = logging.getLogger(Logging.LLM)
        llm_log.info(
            "***LLM Response:***\n%s\n", response.generations[0][0].text
        )
