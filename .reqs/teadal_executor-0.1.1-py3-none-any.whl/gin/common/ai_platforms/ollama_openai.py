"""
Classes and functions supporting models hosted on IBM RITS.
https://rits.fmaas.res.ibm.com/
https://github.ibm.com/rits/rits

Creating LangChain custom LLM classes
https://python.langchain.com/docs/how_to/custom_llm/

Example custom LLM class for RITS
https://github.ibm.com/BARHA/RITS-langchain
"""

from typing import Optional, Any
from langchain_openai import ChatOpenAI

from gin.common.types import PlatformCredentials
from gin.common.ai_platforms.callbacks import LoggingCallbackHandler
from langchain_openai import OpenAIEmbeddings
from typing import Dict

# RITS requires model both as a path parameter before the endpoint, as well as
# a parameter to the body JSON data in "model", but the values for each of
# these differ. We will use the value that goes in the body as the primary name,
# and look up the path parameter name in this dict.
MODEL_PATH_PARAMS = {
    ""
}

EMBEDDINGS_PATH_PARAMS = {
    "ibm/slate-125m-english-rtrvr-v2": "slate-125m-english-rtrvr-v2",
}


class OLLAMA_OPENAI:
    """
    A class representing the RITS OpenAI platform interface.

    This class provides static methods to configure and obtain a ChatOpenAI interface
    for interacting with RITS OpenAI models.

    Methods:
        get_llm_interface: Creates and returns a ChatOpenAI instance configured for RITS.

    Example:
        llm = RITS_OPENAI.get_llm_interface(
            model_id="ibm-granite/granite-3.1-8b-instruct",
            credentials=platform_credentials
    """

    @staticmethod
    def get_llm_interface(
        model_id: str,
        credentials: PlatformCredentials,
        base_url="https://inference-3scale-apicast-production.apps.rits.fmaas.res.ibm.com/{model_name}/v1",
        params: Optional[dict[str, Any]] = None,
    ) -> ChatOpenAI:
        logging_callback_handler = LoggingCallbackHandler()
        model_name = MODEL_PATH_PARAMS[model_id]
        return ChatOpenAI(
            model=model_id,
            base_url=base_url.format(model_name=model_name),
            api_key=credentials.api_key.get_secret_value(),
            callbacks=[logging_callback_handler],
            default_headers={
                "RITS_API_KEY": credentials.api_key.get_secret_value()
            },
            **params,
        )

    @staticmethod
    def get_embedding_interface(
        model_id: str,
        credentials: PlatformCredentials,
        params: Dict[str, Any] | None = None,
    ):
        """
        Get a embeddings model hosted on RITS.

        Args:
            model_id (str): Model ID.
            credentials (PlatformCredentials): Credentials for RITS.
            params (Dict[str, Any] | None): Parameters for the model.

        Returns:
            LangChainEmbeddingsInterface: Embeddings model hosted on RITS.
        """
        model_name = EMBEDDINGS_PATH_PARAMS[model_id]
        return OpenAIEmbeddings(
            model=model_id,
            base_url=f"https://inference-3scale-apicast-production.apps.rits.fmaas.res.ibm.com/{model_name}/v1",
            api_key=credentials.api_key.get_secret_value(),
            default_headers={
                "RITS_API_KEY": credentials.api_key.get_secret_value()
            },
            **params,
        )
