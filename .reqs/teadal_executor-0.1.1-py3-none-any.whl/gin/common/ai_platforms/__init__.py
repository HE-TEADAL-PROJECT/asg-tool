"""
Platforms for hosting AI models.
"""

import logging
from langchain_core.language_models.llms import LLM
from genai.schema import (
    DecodingMethod,
)

from gin.common.ai_platforms.bam import BAM
from gin.common.ai_platforms.rits import RITS
from gin.common.ai_platforms.openai import OPENAI
from gin.common.ai_platforms.watsonx import (
    Watsonx,
    GenTextParamsMetaNames,
    EmbedTextParamsMetaNames,
)
from gin.common.types import ModelDef, Platform, ModelType
from gin.common.logging import Logging


def get_llm_on_platform(model_def: ModelDef) -> LLM:
    """
    Get LLM class instance for provided model.

    Args:
        model_def (ModelDef): Model to create an instance of.

    Returns:
        LLM: Model instance on requested platform.
    """
    base_log = logging.getLogger(Logging.BASE)

    if model_def.platform == Platform.BAM:
        if model_def.model_type == ModelType.EMBEDDINGS:
            parameters = {"truncate_input_tokens": 256}
            model_interface = BAM.get_embedding_interface

        elif model_def.model_type == ModelType.LLM:
            parameters = {
                "decoding_method": DecodingMethod.GREEDY,  # GREEDY or SAMPLE
                "max_new_tokens": 4096,  # 0 to 4096
                "min_new_tokens": 1,  # >=0
                "random_seed": 10,  # 1 to 4294967295
                "repetition_penalty": 1.0,  # 1.0 - 2.0, step 0.01
                "temperature": 0,  # 0.0 - 2.0, step 0.01
            }
            model_interface = BAM.get_llm_interface

        else:
            base_log.error(
                "Model type is not supported: %s", model_def.model_type
            )
            raise NotImplementedError()

        if model_def.model_params:
            parameters.update(model_def.model_params)

        return model_interface(
            model_id=model_def.model_id,
            credentials=model_def.credentials,
            params=parameters,
        )

    elif model_def.platform == Platform.RITS:
        if model_def.model_type == ModelType.EMBEDDINGS:
            base_log.error("Model embedding on RITS not implemented yet")
            raise NotImplementedError()

        elif model_def.model_type == ModelType.LLM:
            parameters = {
                "max_tokens": 4096,
                "min_tokens": 1,
                "seed": 10,
                "repetition_penalty": 1.0,
                "temperature": 0,
            }
            model_interface = RITS.get_llm_interface
        else:
            base_log.error(
                "Model type is not supported: %s", model_def.model_type
            )
            raise NotImplementedError()

        if model_def.model_params:
            parameters.update(model_def.model_params)

        return model_interface(
            model_id=model_def.model_id,
            credentials=model_def.credentials,
            params=parameters,
        )

    elif (
        model_def.platform == Platform.OPENAI
        or model_def.platform == Platform.RITS_OPENAI
    ):
        if model_def.model_type == ModelType.EMBEDDINGS:
            model_interface = OPENAI.get_embedding_interface
            parameters = {}

        elif model_def.model_type == ModelType.LLM:
            parameters = {
                "max_tokens": 4096,
                "seed": 10,
                "temperature": 0,
                "max_retries": 5,
            }
            model_interface = OPENAI.get_llm_interface
        else:
            base_log.error(
                "Model type is not supported: %s", model_def.model_type
            )
            raise NotImplementedError()

        if model_def.model_params:
            parameters.update(model_def.model_params)

        if model_def.platform == Platform.RITS_OPENAI:
            parameters.update(
                {
                    "default_headers": {
                        "RITS_API_KEY": model_def.credentials.api_key.get_secret_value()
                    }
                }
            )

        return model_interface(
            model_id=model_def.model_id,
            credentials=model_def.credentials,
            params=parameters,
        )

    elif model_def.platform == Platform.WATSONX:
        if model_def.model_type == ModelType.EMBEDDINGS:
            parameters = {
                EmbedTextParamsMetaNames.TRUNCATE_INPUT_TOKENS: 256,
                EmbedTextParamsMetaNames.RETURN_OPTIONS: {"input_text": True},
            }
            model_interface = Watsonx.get_embedding_interface

        elif model_def.model_type == ModelType.LLM:
            parameters = {
                GenTextParamsMetaNames.DECODING_METHOD: "greedy",
                GenTextParamsMetaNames.MAX_NEW_TOKENS: 4096,
                GenTextParamsMetaNames.MIN_NEW_TOKENS: 1,
                GenTextParamsMetaNames.RANDOM_SEED: 10,
                GenTextParamsMetaNames.REPETITION_PENALTY: 1.0,
                GenTextParamsMetaNames.TEMPERATURE: 0,
            }
            model_interface = Watsonx.get_llm_interface
        else:
            base_log.error(
                "Model type is not supported: %s", model_def.model_type
            )
            raise NotImplementedError()

        if model_def.model_params:
            parameters.update(model_def.model_params)

        return model_interface(
            model_id=model_def.model_id,
            credentials=model_def.credentials,
            params=parameters,
        )

    else:
        base_log.error("Platform is not supported: %s", model_def.platform)
        raise NotImplementedError()
