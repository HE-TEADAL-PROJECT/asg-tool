from dotenv import load_dotenv
from typing import Any, Dict, Optional, List
from langchain_ibm import WatsonxLLM, WatsonxEmbeddings
from gin.common.types import PlatformCredentials
from gin.common.ai_platforms.callbacks import LoggingCallbackHandler
from ibm_watsonx_ai.metanames import (
    GenTextParamsMetaNames,
    EmbedTextParamsMetaNames,
)
from langchain.evaluation import EmbeddingDistance
from langchain.evaluation import load_evaluator
from pydantic import BaseModel

load_dotenv()


class Watsonx:
    """A class that provides methods for creating WatsonxLLM models."""

    @staticmethod
    def get_llm_interface(
        model_id: str,
        credentials: PlatformCredentials,
        params: Optional[Dict[GenTextParamsMetaNames, Any]] = None,
        **kwargs: Any
    ) -> WatsonxLLM:
        """Generates and returns an instance of WatsonxLLM.
        Args:
            model_id (str): The identifier for the WatsonxLLM model to use.
            llm_params (Optional[Dict[str, Any]], optional): Parameters for text generation. Defaults to None.
            **kwargs (Any): Additional parameters that can be passed to the WatsonxLLM constructor.
        Returns:
            WatsonxLLM: An instance of WatsonxLLM.
        Raises:
            ValueError: If WATSONX_PROJECT_ID is not provided in the environment.
        """
        loggingCallbackHandler = LoggingCallbackHandler()

        return WatsonxLLM(
            model_id=model_id,
            apikey=credentials.api_key.get_secret_value(),
            url=credentials.api_base,
            project_id=credentials.api_project_id,
            params=params,
            callbacks=[loggingCallbackHandler],
        )

    @staticmethod
    def get_embedding_interface(
        model_id: str,
        credentials: PlatformCredentials,
        params: Optional[Dict[EmbedTextParamsMetaNames, Any]] = None,
        **kwargs: Any
    ) -> WatsonxEmbeddings:
        """Generates and returns an instance of WatsonxEmbeddings.
        Args:            model_id (str): The identifier for the WatsonxEmbeddings model to use.
            params (Optional[Dict[str, Any]], optional): Parameters for embedding. Defaults to None.
            **kwargs (Any): Additional parameters that can be passed to the WatsonxEmbeddings constructor.
        Returns:
            WatsonxEmbeddings: An instance of WatsonxEmbeddings.
        Raises:
            ValueError: If WATSONX_PROJECT_ID is not provided in the environment.
        """

        def rerank(self, query: str, docs: List[str]) -> List[str]:
            """Rerank documents by relevance to the query using cosine similarity."""

            class RerankResult(BaseModel):
                score: float
                document: str
                index: int

            evaluator = load_evaluator(
                "pairwise_embedding_distance",
                embeddings=self,
                distance_metric=EmbeddingDistance.COSINE,
            )

            scores = []
            for idx, doc in enumerate(docs):
                evaluation_result = evaluator.evaluate_string_pairs(
                    prediction=query, prediction_b=doc
                )
                score = (
                    evaluation_result.get("score")
                    if isinstance(evaluation_result, dict)
                    else evaluation_result
                )
                scores.append(
                    RerankResult(score=score, document=doc, index=idx)
                )

            # Sort results by relevance score in descending order
            sorted_results = sorted(
                scores, key=lambda x: x.score, reverse=True
            )
            return sorted_results

        WatsonxEmbeddings.rerank = rerank
        embeddings = WatsonxEmbeddings(
            model_id=model_id,
            apikey=credentials.api_key.get_secret_value(),
            project_id=credentials.api_project_id,
            url=credentials.api_base,
            params=params,
        )
        return embeddings
