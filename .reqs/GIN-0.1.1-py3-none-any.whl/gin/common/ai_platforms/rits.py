"""
Classes and functions supporting models hosted on IBM RITS.
https://rits.fmaas.res.ibm.com/
https://github.ibm.com/rits/rits

Creating LangChain custom LLM classes
https://python.langchain.com/docs/how_to/custom_llm/

Example custom LLM class for RITS
https://github.ibm.com/BARHA/RITS-langchain
"""

from typing import Optional, Any
import time
from pydantic import SecretStr
import requests
from langchain_core.language_models.llms import LLM
from langchain_core.callbacks.manager import CallbackManagerForLLMRun

from gin.common.types import PlatformCredentials
from gin.common.ai_platforms.callbacks import LoggingCallbackHandler

# Timeout in seconds for calls to RITS
# If a model on RITS has not been active for some (unknown) period of time, it
# will be scaled to zero and GPUs freed for usage elsewhere. When this happens
# the first call to this model can take a few minutes before a result is
# returned, so the default timeout here is rather long.
TIMEOUT = 4 * 60

# Exponential backoff parameters
MAX_RETRIES = 5
BACKOFF_FACTOR = 2
INITIAL_DELAY = 1  # Initial delay in seconds

# RITS requires model both as a path parameter before the endpoint, as well as
# a parameter to the body JSON data in "model", but the values for each of
# these differ. We will use the value that goes in the body as the primary name,
# and look up the path parameter name in this dict.
MODEL_PATH_PARAMS = {
    "codellama/CodeLlama-34b-Instruct-hf": "codellama-34b-instruct-hf",
    "deepseek-ai/DeepSeek-V2.5": "deepseek-v2.5",
    "deepseek-ai/deepseek-coder-33b-instruct": "deepseek-coder-33b-instruct",
    "ibm-fms/avengers-jamba-9b": "avengers-jamba-9b",
    "ibm-granite/granite-13b-chat-v2": "granite-13b-chat-v2",
    "ibm-granite/granite-13b-instruct-v2": "granite-13b-instruct-v2",
    "ibm-granite/granite-20b-code-base-content-linking": "granite-20b-cbcl",
    "ibm-granite/granite-20b-code-base-sql-gen": "granite-20b-cbsql",
    "ibm-granite/granite-20b-code-instruct-8k": "granite-20b-code-instruct-8k",
    "ibm-granite/granite-20b-code-instruct-r1.1": "granite-20b-ci-r1-1",
    "ibm-granite/granite-20b-code-instruct-unified-api": "granite-20b-code-instruct-uapi",
    "ibm-granite/granite-3.0-8b-instruct": "granite-3-0-8b-instruct",
    "ibm-granite/granite-3.1-8b-instruct": "granite-3-1-8b-instruct",
    "ibm-granite/granite-3-1-8b-tooltest": "granite-3-1-8b-tooltest",
    "ibm-granite/granite-34b-code-instruct-8k": "granite-34b-code-instruct-8k",
    "ibm-granite/granite-8b-code-instruct-128k": "granite-8b-code-instruct-128k",
    "ibm-granite/granite-8b-code-instruct-4k": "granite-8b-code-instruct-4k",
    "ibm-granite/granite-8b-instruct-preview-4k": "granite-8b-instruct-preview-4k",
    "ibm-granite/granite-8b-japanese-instruct": "granite-8b-japanese-instruct",
    "ibm/granite-20b-code-8k-ansible": "granite-20b-code-8k-ansible",
    "ibm/granite-20b-code-instruct-lh": "granite-20b-code-instruct-lh",
    "ibm/granite-20b-schema-sqlinstruct-granite-fine-vs": "granite-20b-cbsl",
    "ibm/granite-34b-content-linking": "granite-34b-content-linking",
    "ibm/granite-34b-question-gen": "granite-34b-question-gen",
    "ibm/granite-34b-schema-linking": "granite-34b-schema-linking",
    "ibm/granite-34b-sql-gen": "granite-34b-sql-gen",
    "ibm/granite-7b-lab": "granite-7b-lab",
    "meta-llama/Llama-3.1-8B-Instruct": "llama-3-1-8b-instruct",
    "meta-llama/Llama-3.2-11B-Vision-Instruct": "llama-3-2-11b-vision-instruct",
    "meta-llama/Llama-3.2-90B-Vision-Instruct": "llama-3-2-90b-instruct",
    "meta-llama/llama-3-1-405b-instruct-fp8": "llama-3-1-405b-instruct-fp8",
    "meta-llama/llama-3-1-70b-instruct": "llama-3-1-70b-instruct",
    "meta-llama/llama-3-3-70b-instruct": "llama-3-3-70b-instruct",
    "mistralai/mistral-large-instruct-2407": "mistral-large-instruct-2407",
    "mistralai/mixtral-8x22B-instruct-v0.1": "mixtral-8x22b-instruct-v01",
    "mistralai/mixtral-8x7B-instruct-v0.1": "mixtral-8x7b-instruct-v01",
    "Qwen/Qwen2.5-72B-Instruct": "qwen2-5-72b-instruct",
    "Qwen/Qwen2.5-Coder-32B-Instruct": "qwen2-5-coder-32b-instruct",
    "Qwen/Qwen2-VL-72B-Instruct": "qwen2-vl-72b-instruct",
}


class RITS_LLM(LLM):

    base_url: str = (
        "https://inference-3scale-apicast-production.apps.rits.fmaas.res.ibm.com/"
    )
    api_key: SecretStr
    model: str
    max_tokens: int
    min_tokens: int
    seed: int
    repetition_penalty: int
    temperature: int

    @property
    def _identifying_params(self) -> dict[str, Any]:
        """Get the identifying parameters."""
        return {"model_name": "RITSModel"}

    @property
    def _llm_type(self) -> str:
        """Return the type of LLM. This is used for logging purposes only."""
        return "RITS"

    def _call(
        self,
        prompt: str,
        stop: Optional[list[str]] = None,
        run_manager: Optional[CallbackManagerForLLMRun] = None,
        **kwargs: Any,
    ) -> str:
        """Run the LLM on the given input.

        Args:
            prompt (str): The prompt to generate from.
            stop (list[str]): Stop words to use when generating (not
                implemented).
            run_manager: Callback manager for the run.

        Returns:
            str: The model output as a string.
        """
        if stop is not None:
            raise NotImplementedError()
        if self.model not in MODEL_PATH_PARAMS:
            raise ValueError(f"Unsupported model: {self.model}")

        base_url_model = (
            self.base_url.removesuffix("/")
            + "/"
            + MODEL_PATH_PARAMS[self.model]
        )
        params = {
            "max_tokens": self.max_tokens,
            "min_tokens": self.min_tokens,
            "seed": self.seed,
            "repetition_penalty": self.repetition_penalty,
            "temperature": self.temperature,
        }

        for retry in range(MAX_RETRIES):
            try:
                response = requests.post(
                    url=f"{base_url_model}/v1/completions",
                    headers={
                        "RITS_API_KEY": self.api_key.get_secret_value(),
                        "Content-Type": "application/json",
                    },
                    json={"prompt": [prompt], "model": self.model, **params},
                    timeout=TIMEOUT,
                )

                if response.status_code == 200:
                    return response.json()["choices"][0]["text"]
                elif response.status_code in [429, 503]:
                    # Rate limit or service unavailable, will retry
                    pass
                else:
                    # Any other status code is an error
                    raise requests.exceptions.RequestException(
                        f"RITS failed with status code {response.status_code}: {response.text}",
                    )
            # Retry on timeout or connection error
            except (
                requests.exceptions.Timeout,
                requests.exceptions.ConnectionError,
            ):
                pass
            # Retry on rate limit or service unavailable
            sleep_time = INITIAL_DELAY * (BACKOFF_FACTOR**retry)
            time.sleep(sleep_time)

        raise requests.exceptions.RequestException(
            f"RITS request failed after {MAX_RETRIES} retries.",
        )


class RITS:

    @staticmethod
    def get_llm_interface(
        model_id: str,
        credentials: PlatformCredentials,
        params: Optional[dict[str, Any]] = None,
    ) -> RITS_LLM:
        """
        Get a language model hosted on RITS.
        model_id (str): Model ID.
        credentials (PlatformCredentials): Credentials for RITS.
        params (dict[str, Any] | None): Parameters for the model.

        Returns:
            LangChainInterface: Language model hosted on RITS.
        """
        logging_callback_handler = LoggingCallbackHandler()

        return RITS_LLM(
            model=model_id,
            base_url=credentials.api_base,
            api_key=credentials.api_key,
            callbacks=[logging_callback_handler],
            **params,
        )
