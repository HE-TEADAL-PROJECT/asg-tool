from typing import Optional, Any
from langchain_openai import ChatOpenAI

from gin.common.types import PlatformCredentials
from gin.common.ai_platforms.callbacks import LoggingCallbackHandler
from langchain_openai import OpenAIEmbeddings
from typing import Dict


class OPENAI:
    """
    A class representing the OpenAI platform interface.

    This class provides static methods to configure and obtain a ChatOpenAI interface
    for interacting with OpenAI compatible API.

    Methods:
        get_llm_interface: Creates and returns a ChatOpenAI instance configured for OpenAI compatible API .
    """

    @staticmethod
    def get_llm_interface(
        model_id: str,
        credentials: PlatformCredentials,
        params: Optional[dict[str, Any]] = None,
    ) -> ChatOpenAI:
        logging_callback_handler = LoggingCallbackHandler()
        return ChatOpenAI(
            model=model_id,
            base_url=credentials.api_base,
            api_key=credentials.api_key.get_secret_value(),
            callbacks=[logging_callback_handler],
            **params,
        )

    @staticmethod
    def get_embedding_interface(
        model_id: str,
        credentials: PlatformCredentials,
        params: Dict[str, Any] | None = None,
    ):
        """
        Create and return an OpenAIEmbeddings instance configured for OpenAI compatible API.

        Returns:
            OpenAIEmbeddings: OpenAIEmbeddings instance configured for OpenAI compatible API.
        """
        return OpenAIEmbeddings(
            model=model_id,
            base_url=credentials.api_base,
            api_key=credentials.api_key.get_secret_value(),
            **params,
        )
