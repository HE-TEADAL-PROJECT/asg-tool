"""Connector specification."""

from enum import Enum, StrEnum, auto
import json
import re
import logging
from typing import Dict, List, Any, Optional
import yaml
import yaml.parser
from langchain_core.documents.base import Document
from pydantic import ConfigDict, BaseModel, Field, ValidationError

from gin.common.util import get_details_for_call
from gin.common.types import (
    HTTPParamLocation,
    APITypes,
    ApiCallInf,
    AuthType,
    AppInstance,
)
from gin.common.logging import Logging


class ArgSourceEnum(str, Enum):
    """
    ArgSourceEnum is an enumerated type that represents the source of an argument value

    Attributes
        CONSTANT: str
            The argument value is a constant defined in the user's input utterance.
        RUNTIME: str
            The argument value is provided at runtime as an input to the call.
        REFERENCE: str
            The argument value is obtained by referencing an API call or env variable.
    """

    CONSTANT = "constant"
    RUNTIME = "runtime"
    REFERENCE = "reference"


class ArgLocationEnum(str, Enum):
    """
    ArgLocationEnum is an enumerated type that represents how the argument should be passed to the API.

    Attributes
        PARAMETER: str
            The argument value is a path or query string parameter to the API.
        HEADER: str
            The argument value is a header to the API.
        DATA: str
            The argument value is a data argument to the API.
    """

    PARAMETER = "parameter"
    HEADER = "header"
    DATA = "data"


class MethodEnum(str, Enum):
    """
    MethodEnum is an enumerated type that represents the type of HTTP method to use.

    Attributes
        POST: str
            The argument value is an HTTP POST method.
        GET: str
            The argument value is an HTTP GET method.
        PUT: str
            The argument value is an HTTP PUT method.
    """

    POST = "post"
    GET = "get"
    PUT = "put"


class PaginationTypeEnum(StrEnum):
    """
    Enumeration of supported pagination methods

    Attributes
        PAGE: str
            Page-based pagination
        CURSOR: str
            Cursor pagination
        OFFSET: str
            Offset pagination
        KEYSET: str
            Keyset (seek) pagination
        SEEK: str
            Synonym for KEYSET
        TIME: str
            Time-based pagination

    """

    PAGE = auto()
    CURSOR = auto()
    OFFSET = auto()
    KEYSET = auto()
    SEEK = KEYSET
    TIME = auto()


class CallTypeEnum(StrEnum):
    """
    Enumeration of call types.

    Attributes
        URL: str
            Call is a URL
    """

    URL = auto()


class RuntimeTypeEnum(StrEnum):
    """
    Enumeration of runtime types.

    Attributes
        PYTHON: str
            Connector is to be executed with Python runtime
    """

    PYTHON = auto()


class ArgTypeEnum(StrEnum):
    """
    Enumeration of argument types.

    Attributes
        ANY: str
        ARRAY: str
        ARRAYLIST: str
        BIGINT: str
        BOOL: str
        BOOLEAN: str
        BYTE: str
        CHAR: str
        DICT: str
        DOUBLE: str
        FLOAT: str
        HASHTABLE: str
        HASHMAP: str
        INTEGER: str
        LIST: str
        LONG: str
        NUMBER: str
        NULL: str
        OBJECT: str
        QUEUE: str
        STACK: str
        SHORT: str
        STRING: str
        TUPLE: str
    """

    ANY = auto()
    ARRAY = auto()
    ARRAYLIST = auto()
    BIGINT = auto()
    BOOL = auto()
    BOOLEAN = auto()
    BYTE = auto()
    CHAR = auto()
    DICT = auto()
    DOUBLE = auto()
    FLOAT = auto()
    HASHTABLE = auto()
    HASHMAP = auto()
    INTEGER = auto()
    LIST = auto()
    LONG = auto()
    NUMBER = auto()
    NULL = auto()
    OBJECT = auto()
    QUEUE = auto()
    STACK = auto()
    SHORT = auto()
    STRING = auto()
    TUPLE = auto()


class Metadata(BaseModel):
    name: str = "TBD"
    description: str = "TBD"
    input_prompt: Optional[str] = Field(default=None, alias="inputPrompt")


class Dataset(BaseModel):
    """
    The Dataset object describes what is the api call output and how to obtain it.
    Attributes
        api: API name to get the output from.
        path: a string describing the json path to the output data.
        metadata: additional fields (metadata) that should be appended into the output.
    """

    api: str
    path: Optional[str] = ""
    metadata: Optional[List[str]] = None


class TransformFunction(BaseModel):
    """
    The TransformFunction object describes a transformation function.
    Attributes
        function: name of the function.
        description: function description.
        params: Dict of parameters that the transform function needs, key is parameter name in the function, value is the parameter value.
        output: the field name of the function's output, which can be referenced in proceeding functions.
    """

    function: str
    description: Optional[str] = ""
    params: Optional[Dict[str, Any]] = None
    output: Optional[str] = ""


class ProcessDataSet(BaseModel):
    """
    The ProcessDataSet object describes how to generate the output dataframe.
    Attributes
        dataframe: input dataset name to use in the transformation.
        fields: Dict that represents the transformation for each field in the output dataset.
    """

    dataframe: str
    fields: Dict[str, List[TransformFunction]]


class Output(BaseModel):
    """
    The Output object describes how to handle the output of the API calls

    Attributes
        data: A dictionary mapping output dataframes to their sources in the API outputs.
        execution: TBD.
        runtime_type: A string representing the type of runtime used to execute the cell (e.g., "python").
        exports: Descriptive object on how to generate the output dataset, key is the name of the output dataframe,
                   value is the transformation logic that needs to be executed to reach a target schema.
    """

    data: Optional[Dict[str, Dataset]] = None
    execution: str = ""
    runtime_type: RuntimeTypeEnum = Field(
        default=RuntimeTypeEnum.PYTHON, alias="runtimeType"
    )
    exports: Optional[Dict[str, ProcessDataSet]] = None


class Argument(BaseModel):
    name: str
    argLocation: ArgLocationEnum
    type: ArgTypeEnum
    source: ArgSourceEnum
    value: Any


class PagingParamDirectory(BaseModel):
    # Name of key in pagination_params dict that gives page number
    pageRef: str
    # Path in response data to page size number
    pageSizePath: str
    # Path in response data to total data size number
    totalSizePath: str


class Pagination(BaseModel):
    type: Optional[PaginationTypeEnum] = None
    # If a response contains a URL to the next block of paginated data, this
    # field contains the path within the response data to the URL for the next
    # block. If this is provided, no other fields are necessary for determining
    # how to access the next set of data, just execute on this URL until the
    # response data no longer has this path.
    next_path: Optional[str] = Field(default=None, alias="nextPath")
    # Dictionary containing key names equal to a required query parameter(s) to
    # access the next block of paginated data, and values equal to the path for
    # where to find those values in the latest set of response data.
    # Depending on the pagination type, some of these parameters may be handled
    # in special ways (like determining how many blocks of data exist, and
    # where we exist in those blocks).
    pagination_params: Optional[Dict[str, Any]] = Field(
        default=None, alias="paginationParams"
    )
    # This maps parameters needed to implement a certain type of paging
    param_translation: Optional[PagingParamDirectory] = Field(
        default=None, alias="paramTranslation"
    )


class ApiCall(BaseModel):
    type: CallTypeEnum
    endpoint: str
    method: MethodEnum
    arguments: Optional[List[Argument]] = None
    pagination: Optional[Pagination] = None


class Call(BaseModel):
    apicalls: Dict[str, ApiCall] = Field(alias="apiCalls")
    output: Output
    timeout: Optional[int] = 60


class Server(BaseModel):
    url: str
    description: Optional[str] = None


# This is the base of the connector specification


class ConnectorSpec(BaseModel):
    """Connector specification."""

    model_config = ConfigDict(
        title="GIN Connector",
        validate_assignment=True,
        validate_default=True,
        use_attribute_docstrings=True,
    )

    api_version: str = Field("connector/v1", alias="apiVersion")
    kind: str = "connector/v1"
    metadata: Metadata
    spec: Call
    servers: Optional[list[Server]] = None


def import_connector_from_file(file_path: str) -> ConnectorSpec:
    """
    Import connector specification file.

    Args:
        file_path (str): Path to connector specification file.

    Returns:
        ConnectorSpec: Connector specification.
    """
    base_log = logging.getLogger(Logging.BASE)

    with open(file_path, "r", encoding="UTF-8") as file:
        connector = import_connector_from_string(file.read())
        if not connector:
            base_log.error(
                "Validation error loading connector specification file: %s",
                file_path,
            )
        return connector


def import_connector_from_string(connector_spec: str) -> ConnectorSpec:
    """
    Import connector specification from YAML string.

    Args:
        connector_spec (str): string containing the connector specification.

    Returns:
        ConnectorSpec: Connector specification.
    """
    base_log = logging.getLogger(Logging.BASE)
    try:
        conn_spec_dict = yaml.safe_load(connector_spec)
        connector = ConnectorSpec(**conn_spec_dict)
    except ValidationError as err:
        base_log.error(
            "Validation error loading connector specification: %s", err
        )
        base_log.error("Connector specification: %s", connector_spec)
        return None
    except yaml.parser.ParserError as err:
        base_log.error(
            "Parsing error loading connector specification: %s", err
        )
        base_log.error("Connector specification: %s", connector_spec)
        return None
    return connector


def export_connector(connector: ConnectorSpec, file_path: str) -> None:
    """
    Export configuration file.

    Args:
        connector (ConnectorSpec): Connector specification.
        file_path (str): Path to output connector specification file.
    """
    with open(file_path, "w", encoding="UTF-8") as file:
        yaml.dump(connector.model_dump(by_alias=True, mode="json"), file)


def create_output_section(
    call: ApiCallInf, context: List[Document]
) -> Dict[str, Dataset]:
    """
    Create the output section in the connector specification.
    Populate the output section based on the given APi call response schema,
    returning all root level elements.

    Args:
        call (ApiCallInf):API call
        context (List[Document]): Contextual documents provided to LLM of
            available APIs.

    Returns:
        Dict[str, Dataset]: The output section in the connector specification.
    """
    out_dataframes = {}
    tool_details = get_details_for_call(call.name, context)
    if tool_details is None:
        return None
    if tool_details.call_meta and tool_details.call_meta.output_schema:
        schema = tool_details.call_meta.output_schema
    else:
        return None
    if schema["type"] == "array":
        out_dataframes[call.name] = Dataset(api=call.name)
    else:
        for key in schema["properties"].keys():
            out_dataframes[key] = Dataset(api=call.name, path=key)
    if not out_dataframes:  # out_dataframes is empty
        return None
    return out_dataframes


def make_connector_json_schema() -> str:
    """
    Create a JSON Schema for the connector specification.

    Returns:
        str: JSON Schema of connector specification.
    """
    return json.dumps(ConnectorSpec.model_json_schema(), indent=2)


def make_connector_spec(
    api_calls: List[ApiCallInf],
    context: List[Document],
    user_input: str,
    out_dataframes: Dict[str, Dataset],
    exports: Dict[str, ProcessDataSet] = None,
    app_inst: Optional[AppInstance] = None,
) -> ConnectorSpec:
    """Create a connector specification from a list of API call inferences.

    Args:
        api_calls (List[ApiCallInf]): List of API calls.
        context (List[Document]): Contextual documents provided to LLM of
            available APIs.
        user_input (str): User utterance.
        exports (Dict[str, ProcessDataSet]): key - output dataframe name,
            value - ProcessDataSet object.
        app_inst (Optional[AppInstance]): Source application instance details
            to add to connector specification.

    Returns:
        ConnectorSpec:  Connector specification.
    """
    base_log = logging.getLogger(Logging.BASE)
    apicalls_dict = {}
    for call in api_calls:
        apicall = {
            "type": CallTypeEnum.URL,
        }

        tool_details = get_details_for_call(call.name, context)
        if tool_details.api_type != APITypes.REST:
            # This connector exporter is REST specific
            raise ValueError(f"Invalid API type: {tool_details.api_type}")
        apicall["endpoint"] = tool_details.call_meta.endpoint
        apicall["method"] = tool_details.call_meta.method

        list_args = []

        security_arg = {}
        security_arg["type"] = "string"
        security_arg["source"] = ArgSourceEnum.CONSTANT
        if app_inst:
            if app_inst.auth_type != AuthType.NO_AUTH:
                update_app_inst_security_arg(security_arg, app_inst)
                list_args.append(security_arg)
        else:
            if tool_details.call_meta.auth_type:
                auth_types = tool_details.call_meta.auth_type
                if not auth_types:
                    base_log.error(
                        "No app_inst and authentication couldn't be resolved from spec"
                    )
                    raise NotImplementedError(
                        "Authentication cannot be found and handled"
                    )
            # Take the first auth_type of this endpoint, the user can specify explicitly the type
            # he wants to use in the app instance
            default_auth_type = auth_types[0]
            auth_type = default_auth_type["type"].lower()
            if auth_type == "http":
                # Get if this is HTTP basic or HTTP bearer
                auth_type = default_auth_type["scheme"].lower()
            if auth_type != AuthType.NO_AUTH:
                security_arg["argLocation"] = default_auth_type["in"]
                if auth_type == AuthType.API_KEY:
                    security_arg["name"] = default_auth_type["name_in_request"]
                    security_arg["value"] = (
                        default_auth_type["scheme"] + " " + "$TOKEN"
                    ).strip()
                elif auth_type == AuthType.BEARER:
                    security_arg["name"] = "Authorization"
                    security_arg["value"] = "Bearer $TOKEN"
                else:
                    base_log.error(
                        "Security type %s defined in spec is not supported",
                        auth_type,
                    )
                    raise NotImplementedError(
                        "Authentication method is not supported"
                    )
                list_args.append(security_arg)

        for param in tool_details.parameters:
            if (
                param in call.parameters
                or param in tool_details.parameters["required"]
            ):
                args = {}
                args["name"] = param
                if param in call.parameters:
                    args["source"] = ArgSourceEnum.CONSTANT
                    args["value"] = call.parameters[param]
                else:
                    args["source"] = ArgSourceEnum.RUNTIME
                if "type" in tool_details.parameters[param]:
                    args["type"] = tool_details.parameters[param]["type"]
                # TODO Need a cleaner way to sync props.location enum values
                # with ArgLocationEnum, these are not aligned.
                if "location" in tool_details.parameters[param]:
                    if (
                        tool_details.parameters[param]["location"]
                        == HTTPParamLocation.QUERY
                        or tool_details.parameters[param]["location"]
                        == HTTPParamLocation.PATH
                    ):
                        args["argLocation"] = ArgLocationEnum.PARAMETER
                    elif (
                        tool_details.parameters[param]["location"]
                        == HTTPParamLocation.HEADER
                    ):
                        args["argLocation"] = ArgLocationEnum.HEADER
                    else:
                        raise NotImplementedError(
                            f"Unsupported argument location: {
                                tool_details.parameters[param]["location"]}"
                        )
                list_args.append(args)
        apicall["arguments"] = list_args

        apicalls_dict[call.name] = apicall
    con_spec_dict = {
        "apiVersion": "connector/v1",
        "kind": "connector/v1",
        "metadata": {
            "name": "TBD",
            "description": "TBD",
            "inputPrompt": user_input,
        },
        "spec": {
            "apiCalls": apicalls_dict,
            "output": {
                "execution": "",
                "runtimeType": "python",
                "data": out_dataframes,
                "exports": exports,
            },
        },
    }
    base_log.debug("Connector spec dict: %s", con_spec_dict)
    con_spec = ConnectorSpec(**con_spec_dict)
    if app_inst:
        add_app_inst_servers_to_spec(con_spec, app_inst)
    else:
        servers = tool_details.call_meta.servers
        con_spec.servers = resolve_servers_section(servers)
    return con_spec


def resolve_url(url_template: str, variables: Dict[str, Any]) -> str:
    """Replaces placeholders in the URL with default values from variables."""
    resolved_url = url_template

    # Find all placeholders in the URL
    placeholders = re.findall(r"\{(.*?)\}", url_template)

    # Replace each placeholder with its default value
    for placeholder in placeholders:
        default_value = variables.get(placeholder, {}).get(
            "default", f"{{{placeholder}}}"
        )
        resolved_url = resolved_url.replace(
            f"{{{placeholder}}}", default_value
        )

    return resolved_url


def resolve_servers_section(
    servers: list[dict[str:Any]],
) -> list[dict[str:Any]]:
    """
    Processes and resolves the given servers in case the server URL uses a template.
    For example: `url: '{protocol}://api.example.com'`
    In such case in addition to the `url` object there is also a `variables` object.
    Each template variable is a dictionary entry in `variables` that includes
    a `default` entry that can be used to fill the variable name.

    Args:
        servers (list): A list of server dictionaries (from the spec), each containing details about an API server.
    Returns:
        list: A list of resolved server dictionaries.
    """
    resolved_servers = []
    for server in servers:
        url_template = server.get("url", "")
        description = server.get("description", "")
        variables = server.get("variables", {})

        # Resolve the URL with variables
        resolved_url = resolve_url(url_template, variables)

        resolved_servers.append(
            {"description": description, "url": resolved_url}
        )

    return resolved_servers


def add_app_inst_servers_to_spec(
    con_spec: ConnectorSpec,
    app_inst: AppInstance,
) -> None:
    """Add base URL to a connector specification.

    Args:
        con_spec (ConnectorSpec): Connector spec to add instance details to.
        app_inst (AppInstance): Source application instance details
            to add to connector specification.
    """
    con_spec.servers = [Server(url=app_inst.base_url)]


def update_app_inst_security_arg(
    security_arg: dict[str, str], app_inst: AppInstance
) -> None:
    """Update security argument values from app_inst.

    Args:
        security_arg (dict[str, str]): Security argument dictionary.
        app_inst (AppInstance): Source application instance details
            to create the security argument from.
    """
    if app_inst.auth_type == AuthType.API_KEY:
        security_arg["name"] = app_inst.auth_name
        security_arg["value"] = (
            app_inst.auth_scheme + " " + app_inst.key_envar.get_raw_value()
        ).strip()
    elif app_inst.auth_type == AuthType.BEARER:
        security_arg["name"] = "Authorization"
        security_arg["value"] = "Bearer " + app_inst.key_envar.get_raw_value()
    else:
        raise NotImplementedError("Authentication method is not supported")

    # currently assuming the location is only in header, user can set this in app_inst
    security_arg["argLocation"] = ArgLocationEnum.HEADER
