import logging
import re
import pandas as pd
from pydantic import ValidationError
from varsubst import varsubst, exceptions

from gin.common.con_spec import (
    import_connector_from_file,
    import_connector_from_string,
    ArgLocationEnum,
    ArgSourceEnum,
    CallTypeEnum,
    Dataset,
)
from gin.executor.rest_apis import perform_rest_api_call
from gin.executor.transform.transform_exec import (
    apply_transformations_json,
)
from gin.common.util import replace_env_var
from gin.common.logging import Logging


class ConnectorRequest:
    """
    Represents a connector request and handles the request based on the
    connector specification.
    """

    def __init__(
        self, spec_file=None, spec_string=None, user_functions_path=None
    ):
        """
        Initialize the ConnectorRequest with YAML file.

        Args:
            spec_file (str): Path to connector specification file.
            spec_string (str): A string containing the connector specification.
        """
        if spec_file:
            self.spec_file = spec_file
            self.con_spec = import_connector_from_file(spec_file)
        elif spec_string:
            self.spec_file = None
            self.con_spec = import_connector_from_string(spec_string)
        if self.con_spec is None:
            raise ValueError(f"{spec_file} contains invalid specification.")
        self.user_functions_path = user_functions_path
        # Keep track which APIs we have executed.
        # executed_apis is a dict of API calls that need to be executed (key),
        # and a boolean indicating if they have been executed (value).
        self.executed_apis = {}

    def perform_api_call(
        self,
        api_name: str,
        output_data: dict[str, Dataset] = None,
        timeout: int | None = None,
    ) -> dict[str, any]:
        """
        Execute an API call and returns the request output
        as described in the output specification.
        Resolve any dependencies with other API calls.

        Args:
            api_name (str): Name of the API to call.
            output_data (dict[str, Dataset]): Dictionary of output specification.
            timeout (int | None, optional): Timeout for API call.

        Returns:
            dict[str, any]): The output data structure for this API.
        """
        api_call = self.con_spec.spec.apicalls[api_name]

        # Resolve dependencies in the api call's arguments
        # Collect dependencies by api call, including the needed outputs
        # pre_reqs holds dictionary entry for each api, the value is a list of dependencies
        pre_reqs = {}
        if api_call.arguments is not None:
            for arg in api_call.arguments:
                if arg.source != ArgSourceEnum.REFERENCE or arg.value is None:
                    # Skip to next argument if not a reference
                    continue
                # # Resolve a reference to environment variable
                # Only string type arguments can include a reference to an environment variable
                if isinstance(arg.value, str):
                    try:
                        arg.value = varsubst(arg.value)
                    except AttributeError:
                        # The attribute referred in 'fieldname' is not defined in the
                        # configuration class instance, skipping.
                        pass
                    except exceptions.KeyUnresolvedException:
                        # The environment variable that was referred in the configuration
                        # is not defined, skipping.
                        pass
                # Resolve a reference from a prerequistive api
                else:
                    try:
                        value = Dataset(**arg.value)
                        dep_api = value.api
                        if dep_api in pre_reqs:
                            pre_req_entry = pre_reqs[dep_api]
                        else:
                            pre_req_entry = []
                        dep_path_list = value.path.split(".")
                        # Assume that then first value is the array name and the 2nd is the field
                        # The current implementation is scoped to one level array.
                        field_to_get = dep_path_list[1:]
                        if len(field_to_get) > 0:
                            field_to_get_ref = ".".join(dep_path_list[1:])
                        else:
                            field_to_get_ref = None
                        pre_req_entry.append(
                            {
                                "name": arg.name,
                                "path": dep_path_list[0],
                                "field_name": field_to_get_ref,
                            }
                        )
                        pre_reqs[dep_api] = pre_req_entry
                    except ValidationError:
                        continue

        # Are there are pre-req apis to call?
        reference_resolution = {}
        for dep_api, dep_api_entries in pre_reqs.items():
            # Check if we already called this API
            if (
                dep_api not in self.executed_apis
                or self.executed_apis[dep_api] is False
            ):
                dep_api_output_spec = {}
                for entry in dep_api_entries:
                    dep_api_output_spec[entry["path"]] = Dataset(
                        api=dep_api, path=entry["path"]
                    )
                result = self.perform_api_call(
                    dep_api, dep_api_output_spec, timeout
                )
                collect_entries = {}
                for entry in dep_api_entries:
                    collect_entries[entry["name"]] = {
                        "values": result[entry["path"]][entry["field_name"]],
                        "index": 0,
                    }
                reference_resolution[api_name] = collect_entries

        result = self._route_to_api_call_type(
            api_name, reference_resolution, output_data, timeout
        )

        return result

    def _route_to_api_call_type(
        self,
        api_name: str,
        reference_resolution: dict[str, dict[str, any]],
        output_data: dict[str, Dataset] = None,
        timeout: int | None = None,
    ) -> dict[str, any]:
        """
        Execute an API call and returns the request output
        as described in the output specification.
        Resolve any dependencies with other API calls.

        Args:
            api_name (str): Name of the API to call.
            reference_resolution: dict[str, dict[str, any]]: Dictionary of arguments for iteration
            output_data (dict[str, Dataset]): Dictionary of output specification.
            timeout (int | None, optional): Timeout for API call.

        Returns:
            dict[str, any]): The output data structure for this API.
        """
        api_call = self.con_spec.spec.apicalls[api_name]

        # Accumulate the results of multiple queries into a single dataframe
        accumulated_result = {}
        stop_iterations = False
        are_there_dependencies = True

        # Loop for each value of a dependenct argument
        # Currently only one dependent argument is supported
        while are_there_dependencies and not stop_iterations:
            are_there_dependencies = False
            prepend_values = {}
            if api_call.type == CallTypeEnum.URL:
                # Prepare REST API call
                parameter_arguments = {}
                header_arguments = {}
                data_arguments = {}
                if api_call.arguments is not None:
                    # Look for argument that depends on a pre-req API call
                    for arg in api_call.arguments:
                        value = arg.value
                        # Replace environment variables with their actual values
                        if arg.type == "string" and "$" in value:
                            pattern = r"\$\w+"
                            # Replace all environment variables in the value
                            value = re.sub(pattern, replace_env_var, value)
                        # If the arg.name appears in the reference_resolution then we need to resolve to get the value
                        if (
                            api_name in reference_resolution
                            and arg.name in reference_resolution[api_name]
                        ):
                            # reference_resolution is { dependent_api: { argument: {index: ##, values: DF} }}
                            are_there_dependencies = True
                            index_to_reference = reference_resolution[
                                api_name
                            ][arg.name]["index"]
                            reference_values = reference_resolution[api_name][
                                arg.name
                            ]["values"]
                            # Get the value
                            if not isinstance(
                                reference_values, pd.core.series.Series
                            ):
                                reference_values = [reference_values]
                            value = reference_values[index_to_reference]
                            # Signal to stop when we reach the last reference, or up to 20 iteration
                            # Stopping at 20 itertaion is a temporaruy setting due to performance issues.
                            if (
                                index_to_reference == len(reference_values) - 1
                                or index_to_reference > 20
                            ):
                                stop_iterations = True
                            else:
                                reference_resolution[api_name][arg.name][
                                    "index"
                                ] = (index_to_reference + 1)
                            prepend_values[arg.name] = value
                        if arg.argLocation == ArgLocationEnum.HEADER:
                            header_arguments[arg.name] = value
                        elif arg.argLocation == ArgLocationEnum.DATA:
                            data_arguments[arg.name] = value
                        elif arg.argLocation == ArgLocationEnum.PARAMETER:
                            parameter_arguments[arg.name] = value

                servers = []
                for server in self.con_spec.servers:
                    servers.append(server.url)
                api_result = perform_rest_api_call(
                    api_call,
                    servers,
                    parameter_arguments,
                    header_arguments,
                    data_arguments,
                    output_data,
                    timeout,
                )
                for dataset_key, dataset_value in api_result.items():
                    for arg_name, arg_value in prepend_values.items():
                        full_arg_name = "argument-" + arg_name
                        dataset_value[full_arg_name] = arg_value
                    if dataset_key not in accumulated_result:
                        accumulated_result[dataset_key] = dataset_value
                    else:
                        accumulated_result[dataset_key].append(dataset_value)
            else:
                raise NotImplementedError(
                    f"Invalid call type: {api_call.type}"
                )

        return accumulated_result

    def run(
        self,
    ) -> dict[str, any]:
        """
        Execute a connector from the connector specification.
        If the result is paginated, pull in and combine the full data using
        the method stated in the specification at self.spec_file.

        Returns:
            dict[str, any]): The output data structure specified in the API configuration file.
        """
        base_log = logging.getLogger(Logging.BASE)
        # Reset executed apis tracking
        self.executed_apis = {}
        # apis_output_spec is a dict that stores the output specification for each API.
        apis_output_spec = {}
        out_data_spec = self.con_spec.spec.output.data
        base_log.debug("Output spec: %s", out_data_spec)
        # Inspect the request output and add APIs that needs to be executed to satisft the output
        if out_data_spec is not None:
            for out_df_name, df_ref in out_data_spec.items():
                # Add the apiname to the list of not yet executed APIs only if the API
                #  is in the list of APIs to call
                if df_ref.api in self.con_spec.spec.apicalls:
                    base_log.debug(
                        "Adding API call to list of calls to be made: %s",
                        df_ref.api,
                    )
                    self.executed_apis[df_ref.api] = False
                    # Add the output specification for the API
                    if df_ref.api not in apis_output_spec:
                        apis_output_spec[df_ref.api] = {}
                    apis_output_spec[df_ref.api][out_df_name] = df_ref
                else:
                    # The requested output reference points to an API that is not
                    #  part of the connector specification.
                    raise exceptions.KeyUnresolvedException(
                        f"Output endpoint reference {df_ref.api} is not in the api calls list"
                    )

        base_log.debug("APIs to call: %s", list(self.executed_apis.keys()))
        # Loop for all APIs that should be executed, starting of those that provides the output
        output = {}
        for api_name, was_executed in self.executed_apis.items():
            if not self.executed_apis[api_name]:
                base_log.info("Executing API: %s", api_name)
                result = self.perform_api_call(
                    api_name,
                    apis_output_spec[api_name],
                    self.con_spec.spec.timeout,
                )
                base_log.debug("Response from %s: %s", api_name, result)
                output.update(result)
                self.executed_apis[api_name] = True
        # Handle Transform
        if self.con_spec.spec.output.exports is not None:
            transformed_output = {}

            for (
                export_name,
                process_data_set,
            ) in self.con_spec.spec.output.exports.items():
                data_set_path = process_data_set.dataframe
                curr_df = apply_transformations_json(
                    output,
                    data_set_path,
                    process_data_set,
                    self.user_functions_path,
                )
                transformed_output[export_name] = curr_df
            output = transformed_output
        return output


def run_from_spec_file(
    filename: str,
    log_level: str = None,
    user_functions_path=None,
) -> dict[str, any]:
    """
    Execute a connector from a connector specification file.

    Args:
        spec_file (str): Path to connector specification file.
        log_level (str): Logging level to set or None to set the default level.

    Returns:
        dict: Returned data from connector execution.
    """
    # Set log level
    Logging(log_level=log_level)

    connector_request = ConnectorRequest(
        spec_file=filename, user_functions_path=user_functions_path
    )
    return connector_request.run()


def run_from_spec_string(
    spec_string: str,
    log_level: str = None,
) -> dict[str, any]:
    """
    Execute a connector from a connector specification file.

    Args:
        spec_string (str): A string containing the connector configuration.
        log_level (str): Logging level to set or None to set the default level.

    Returns:
        dict: Returned data from connector execution.
    """
    # Set log level
    Logging(log_level=log_level)

    connector_request = ConnectorRequest(spec_string=spec_string)
    return connector_request.run()
