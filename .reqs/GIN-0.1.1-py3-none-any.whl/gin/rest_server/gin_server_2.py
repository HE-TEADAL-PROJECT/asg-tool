import logging
import sys
from typing import Any, Optional
from copy import deepcopy

from fastapi import FastAPI
from pydantic import BaseModel, Field
import yaml
from langchain_core.documents import Document

from gin.common.logging import Logging
from gin.gen.types import ApiCallInf
from gin.common.types import ToolDetails, APITypes
from gin.gen.config import BaseConfig, import_config, get_model_def
from gin.smt import run
from gin.smt.schemas import SupervisionAction
from gin.gen.loaders import tool_to_semantic_description
from gin.gen.util import get_missing_value_int
from gin.gen.agents.tool_calling import ToolCallingState, apply_tool_calling

GIN_CONFIG_FILE = "./examples/cdc-poc2/gin_config.yaml"

conf_dict = yaml.safe_load(GIN_CONFIG_FILE)
conf = import_config(GIN_CONFIG_FILE)

print(conf)
# TODO need a nice way to pass debug level at service runtime
# https://github.com/fastapi/fastapi/discussions/9322
Logging(log_level="mapping_service=DEBUG")
map_log = logging.getLogger(Logging.MAPPING_SERVICE)

app = FastAPI()


class TableField(BaseModel):
    type: Optional[str] = None
    """Data type for field."""

    description: Optional[str] = None
    """Description of field."""


class InputTable(BaseModel):
    title: Optional[str] = None
    """Name of table."""

    description: Optional[str] = None
    """Description of table."""

    # TODO remove this type field? It isn't doing anything useful.
    type: Optional[str] = "object"
    """Type of table."""

    properties: Optional[dict[str, TableField]] = None
    """Table fields."""


class ArgDetails(BaseModel):
    type: str
    """Data type that the argument takes."""

    description: str
    """Description of the argument."""

    required: Optional[bool] = True
    """Indicator of whether the argument must be provided."""


class TransformFunction(BaseModel):
    name: str
    """Function name."""

    description: str
    """Description of the function."""

    arguments: dict[str, ArgDetails]
    """Arguments the function takes."""


class SupervisorFeedback(BaseModel):
    source: str
    """Source field name to provide feedback on."""

    explanation: Optional[str] = None
    """Natural language explanation for why this feedback was given."""

    action: Optional[SupervisionAction] = None
    """Suporvisory action to be taken on this source field."""


class RequestModel(BaseModel):
    source: dict[str, InputTable]
    """Source schema."""

    target: dict[str, InputTable]
    """Target schema."""

    transforms: Optional[list[TransformFunction]] = []
    """Available transform functions."""

    data_samples: Optional[Any] = {}  # placeholder
    """Exemplar sample data (this is not yet supported)."""

    supervisor_feedback: Optional[dict[str, list[SupervisorFeedback]]] = Field(
        default={}, alias="supervision"
    )
    """Human supervisory feedback."""


class Transform(BaseModel):
    name: str
    """Transform function name."""

    arguments: dict[str, Any]
    """Transform function arguments and values."""


class MappingCandidate(BaseModel):
    source: str
    """Source field name for target. If the mapping also requires
    transformation, this field will be blank (and is_transformed true)."""

    explanation: str
    """Natural language explanation for why this mapping was chosen."""

    is_transformed: bool = False
    """Indicator if the mapping also requires a transformation function."""

    transform: Optional[Transform] = None
    """Transformation function and arguments."""


class Mapping(BaseModel):
    target: str
    """Target field name."""

    candidates: list[MappingCandidate]
    """List of potential source mappings for target."""


class MappingResponse(BaseModel):
    source: dict[str, InputTable]
    """Source table schema."""

    target: dict[str, InputTable]
    """Target table schema."""

    transforms: Optional[list[TransformFunction]] = []
    """Available transform functions."""

    mappings: list[Mapping]
    """Generated mappings of source fields to target fields."""


def format_rest_data_for_smt(data: RequestModel) -> dict[str, Any]:
    """
    Translate from REST API data format to format for SMT.

    Args:
        data (RequestModel): Client data from REST POST.

    Returns:
        dict: Input data for SMT.
    """
    # TODO: This function is currently not doing any schema reformatting...
    # remove this later if not needed and just use model_dump().
    data_dict = data.model_dump()
    smt_dict = {"source": data_dict["source"], "target": data_dict["target"]}
    if "data_samples" in data_dict:
        smt_dict["data_samples"] = data_dict["data_samples"]
    if "supervisor_feedback" in data_dict:
        smt_dict["supervisor_feedback"] = data_dict["supervisor_feedback"]
    return smt_dict


def _upgrade_type_field(data: dict[str, str]) -> None:
    """
    Remove 'metadata' from table field details (which holds 'type'), and use
    'type' directly.
    """
    for table in data:
        if "properties" not in data[table]:
            continue
        for field in data[table]["properties"]:
            if field == "null":
                continue
            data[table]["properties"][field]["type"] = data[table][
                "properties"
            ][field].pop("metadata")["type"]


def format_smt_data_for_response(data: dict[str, Any]) -> dict[str, Any]:
    """
    Format SMT response data into the schema for REST responses.

    Args:
        data (dict): Response data from SMT.

    Returns:
        dict: Response data for REST call.
    """
    response = {
        "source": deepcopy(data["source"]),
        "target": deepcopy(data["target"]),
    }
    # We need to slightly reformat the source/target schema by removing
    # "metadata" and using "type" in the details of each table field.
    _upgrade_type_field(response["source"])
    _upgrade_type_field(response["target"])
    mappings = []
    for mapping in data["matches"]["supervisor_pending_columns"]:
        candidates = mapping["shortlisted_candidates"]
        candidates.insert(0, mapping["recommendation"])
        mappings.append(
            {"target": mapping["target_column"], "candidates": candidates}
        )
    response["mappings"] = mappings
    return response


def _remove_metadata_from_tables(
    tables: dict[str, InputTable]
) -> dict[str, InputTable]:
    """
    Given a source or target schema tables, make a copy with the metadata
    field removed.

    Args:
        tables (dict[str, InputTable]): Tables to reproduce without metadata.

    Returns:
        dict[str, InputTable]: Bare tables, with metadata field removed.
    """
    tables_clean = {}
    for table, schema in tables.items():
        if table == "metadata":
            continue
        tables_clean[table] = schema
    return tables_clean


@app.post("/schema-matching")
async def schema_matching_endpoint(
    request_data: RequestModel,
) -> MappingResponse:
    """
    Returns the data of a stop given its unique identifier.

    Save internal state (matches)
    check that supervision fields are in matches.
    """
    inference_model = get_model_def(conf)
    model_id = inference_model.model_id
    platform = inference_model.platform
    if not request_data.transforms:
        # No transform functions provided, just do simple mapping
        json_output = run(
            loaded_data=format_rest_data_for_smt(request_data),
            platform_name=platform,
            shortlister_model_id=model_id,
            decider_model_id=model_id,
            shortlister_prompt_name="zeroshot_template",
            decider_prompt_name="llm_decider_template",
        )

        return MappingResponse(**format_smt_data_for_response(json_output))

    # Transform functions have been provided, find both mappings and
    # transformations
    mappings = get_transforms_all_targets(request_data, conf)

    mapping_response = MappingResponse(
        source=_remove_metadata_from_tables(request_data.source),
        target=_remove_metadata_from_tables(request_data.target),
        transforms=request_data.transforms,
        mappings=mappings,
    )

    return mapping_response


###############################################################################
# TODO
# Functions below are for transform function selection. These are a crude start
# to PoC #2 and should be moved somewhere else while being further developed.
# SHOULD BE IMPLEMENTED INSIDE OF SMT.


def make_tool_list(request_data: RequestModel) -> list[ToolDetails]:
    """
    Make a list of ToolDetails objects for the transform functions in a mapping
    request.

    Args:
        request_data (RequestModel): Request data from REST service POST.

    Returns:
        list[ToolDetails]: List of transform function details.
    """
    tool_list = []
    for transform in request_data.transforms:
        parameters = {}
        for param, props in transform.arguments.items():
            parameters[param] = {
                "type": props.type,
                "description": props.description,
                "required": props.required,
            }
        tool_details_dict = {
            "name": transform.name,
            "parameters": parameters,
            "description": transform.description,
            "api_type": APITypes.FUNCTION,
        }
        tool_list.append(ToolDetails(**tool_details_dict))
    return tool_list


def get_transform_for_target(
    target: str,
    target_type: str,
    target_description: str,
    sources: dict[str, TableField],
    tools: list[ToolDetails],
    conf: BaseConfig,
) -> ApiCallInf | None:
    """
    Determine what source fields and transformation to perform in order to
    produce target field.

    Args:
        target (str): Target field name.
        target_type (str): Data type of target field.
        target_description (str): Description of target field.
        sources (dict[str, TableField]): Details of source fields available.
        tools (list[ToolDetails]): Available ransformation function details.
        conf (BaseConfig): GIN configuration.

    Returns:
        ApiCallInf | None: Mapping and transformation suggestion from source
            fields to target, given as an API call inference.
    """
    if conf.generation.features.rag:
        # TODO need a way to downselect tools.
        # Semantic searching for a transform function based on target
        # field details may not be reliable.
        sys.stderr.write("RAG not supported\n")
        return
    else:
        # Provide all tools in context
        context: list[Document] = []
        for tool_details in tools:
            doc = Document(
                page_content=tool_to_semantic_description(tool_details),
                metadata={"tool_details_str": tool_details.model_dump_json()},
            )
            context.append(doc)

    # Create the query
    #
    # TODO this is hard coded for metrics, try to expand using the table
    # description from the source/target.
    #
    # TODO the "types" provided for metrics are more like the units of data that
    # is stored (bytes, percent) rather than the data type (int, float...). We
    # may need to have a lookup table between "metric types" (units) and data
    # types, but this table may depend on the metric data consumer/provider.
    #
    # We will omit the metric name from the query, as Granite frequently picks
    # this as the argument to the identity function.
    # query = f'I need to produce the metric "{target}", which has a type of {target_type}, and is described as "{target_description}".\n'
    query = f'I need to produce a metric which is described as "{target_description}", and has the type {target_type}.\n'
    # Append source metric details to query
    query += "I have the following source metrics available, one or two of which can be used with a single function call to produce what I need:"
    # TODO need a generic way to filter metrics or other entities. We will use
    # a crude method here of dividing based on whether the metric is for CPU or
    # memory
    if "cpu" in target.lower() or "cpu" in target_description.lower():
        metric_kind = "cpu"
    elif "memory" in target.lower() or "memory" in target_description.lower():
        metric_kind = "memory"
    else:
        raise Exception("Cannot determine metric kind (CPU or memory).")
    for source, props in sources.items():
        if metric_kind not in props.description.lower():
            # This source metric is not of the right kind
            continue
        query += f'\nMetric "{source}" has the type {props.type}, and is "{props.description}".'

    state = ToolCallingState(
        conf=conf,
        user_input=query,
        issues="",
        missing_value_int=get_missing_value_int(query),
        context=context,
        api_calls=[],
        iter_count=0,
        feedback="",
    )

    final_state = apply_tool_calling(state)
    api_calls = final_state["api_calls"]
    if len(api_calls) < 1:
        sys.stderr.write(f"No transform could be selected for '{target}'.")
        return
    if len(api_calls) > 1:
        map_log.warning(
            "Multiple transforms selected for '%s', picking first.", target
        )
        for call in api_calls:
            map_log.debug(call)
    return api_calls[0]


def get_transforms_all_targets(
    request_data: RequestModel, conf: BaseConfig
) -> list[Mapping]:
    """
    Determine what source fields and transformations to perform in order to
    produce target fields.

    Args:
        request_data (RequestModel): Request data from REST service POST.

    Returns:
        list[Mapping]: Mapping suggestions from source to target fields.
    """
    mappings = []
    tools = make_tool_list(request_data)
    # Add an "identity" tool to the list for direct mapping.
    identity = {
        "name": "identity",
        "parameters": {
            "item": {
                "type": "Any",
                "description": "Entity which will be returned, unmodified.",
                "required": True,
            }
        },
        "description": "This is an identity function which returns exactly what was provided to it.",
        "api_type": APITypes.FUNCTION,
    }
    tools.append(ToolDetails(**identity))
    # Match like table names
    for table in request_data.target:
        if table not in request_data.source:
            map_log.warning("No table '%s' in source.", table)
            continue
        for target, props in request_data.target[table].properties.items():
            map_log.debug("Mapping for table '%s', target '%s'", table, target)
            transform_function_call = get_transform_for_target(
                target=target,
                target_type=props.type,
                target_description=props.description,
                sources=request_data.source[table].properties,
                tools=tools,
                conf=conf,
            )
            if (
                not transform_function_call
                or not transform_function_call.valid
            ):
                # A transform was not successfully found
                map_log.info("No transform identified for target: %s", target)
                continue

            # Convert ApiCallInf into a Mapping
            if transform_function_call.name == "identity":
                # Identity function was identified... a simple mapping
                mapping_candidate = MappingCandidate(
                    source=transform_function_call.parameters["item"],
                    explanation="Granite tool calling suggestion.",
                    is_transformed=False,
                )
            else:
                transform = Transform(
                    name=transform_function_call.name,
                    arguments=transform_function_call.parameters,
                )
                mapping_candidate = MappingCandidate(
                    source="",
                    explanation="Granite tool calling suggestion.",
                    is_transformed=True,
                    transform=transform,
                )
            map_log.debug(
                "Mapping candidate for target '%s': %s",
                target,
                mapping_candidate,
            )
            mapping = Mapping(target=target, candidates=[mapping_candidate])
            mappings.append(mapping)
    return mappings
