"""Package for Generative AI Integration Rest Server (GIN)."""

__version__ = "0.1.1"
