import logging
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field
from typing import Dict, List, Optional, Any
from gin.smt import run
from gin.smt._run import InputPropertyDefinition, InputTableSchema
from gin.smt._types import OutputTableSchemaTransformations
from gin.common.types import ToolDetails, APITypes

# **Configure Logger**
logging.basicConfig(
    format="%(asctime)s - %(levelname)s - %(message)s",
    level=logging.INFO,
)
logger = logging.getLogger(__name__)

app = FastAPI()
CONFIG_PATH = "examples/gin_config/smt_simple_toolcalling_config.yaml"


class PropertySchema(BaseModel):
    type: Optional[str]
    description: Optional[str] = ""
    metadata: Optional[Dict[str, Any]] = {}


class TableSchema(BaseModel):
    title: str
    description: str
    properties: Dict[str, PropertySchema]


class FunctionArgument(BaseModel):
    type: str
    description: str
    default: Optional[Any] = None


class FunctionSchema(BaseModel):
    name: str
    description: str
    arguments: Dict[str, FunctionArgument]
    required: List[str]


class SchemaMatchingRequest(BaseModel):
    source: Dict[str, TableSchema] = Field(
        ..., description="Source schema definitions"
    )
    target: Dict[str, TableSchema] = Field(
        ..., description="Target schema definitions"
    )
    platform: Optional[str] = Field(
        "watsonx", description="Platform to run the transformation on"
    )
    explainer_model_id: Optional[str] = Field(
        None, description="ID of the explainer model"
    )
    judge_model_id: Optional[str] = Field(
        None, description="ID of the judge model"
    )
    ranker_model_id: Optional[str] = Field(
        None, description="ID of the ranker model"
    )


class TransformationRequest(SchemaMatchingRequest):
    functions: List[FunctionSchema] = Field(
        default=[], description="Optional function mappings"
    )
    mapping_type: Optional[str] = Field(
        "ONE_TO_ONE", description="Mapping type for the transformation"
    )


# **Transformation Functions**
def convert_to_input_table_schema(
    table_data: Dict[str, TableSchema]
) -> InputTableSchema:
    """Transforms incoming schema data into an InputTableSchema object."""
    logger.debug("Converting table data to InputTableSchema...")
    if len(table_data) != 1:
        logger.error("Expected exactly one table schema per request.")
        raise ValueError("Expected exactly one table schema per request.")

    table_name, table_info = next(iter(table_data.items()))
    properties = [
        InputPropertyDefinition(
            name=prop_name,
            description=prop_info.description or "",
            metadata={"type": prop_info.type} if prop_info.type else {},
        )
        for prop_name, prop_info in table_info.properties.items()
    ]

    logger.info(f"Converted table schema: {table_name}")
    return InputTableSchema(
        id=None,
        name=table_name,
        description=table_info.description,
        metadata={},
        properties=properties,
    )


def convert_to_transforms(
    functions_data: List[FunctionSchema],
) -> List[ToolDetails]:
    """
    Converts a list of function schemas into ToolDetails objects.
    """
    transforms = []
    for func in functions_data:
        parameters = {
            arg_name: {
                **arg.model_dump(),
            }
            for arg_name, arg in func.arguments.items()
        }
        parameters["required"] = func.required

        transform = ToolDetails(
            name=func.name,
            description=func.description,
            parameters=parameters,
            api_type=APITypes.FUNCTION,
        )
        transforms.append(transform)

    return transforms


def format_schema_matching_output(
    output: OutputTableSchemaTransformations,
) -> Dict[str, Any]:
    return {
        "mappings": [
            {
                "target": prop.name,
                "candidates": [
                    {
                        "source": t.arguments.get("item_1"),
                        "explanation": t.explanation,
                    }
                    for t in prop.transformations
                ],
            }
            for prop in output.properties
        ]
    }


def get_argument_index_mapping(
    functions: List[FunctionSchema],
) -> Dict[str, Dict[str, int]]:
    """
    Generates a mapping of function names to their argument index mapping.
    Ensures index order is preserved based on input functions.
    """
    function_index_map = {}

    for func in functions:
        argument_names = list(func.arguments.keys())
        function_index_map[func.name] = {
            arg: idx for idx, arg in enumerate(argument_names)
        }

    return function_index_map


def format_transformation_output(
    output: OutputTableSchemaTransformations,
    argument_index_mapping: Dict[str, Dict[str, int]],
) -> Dict[str, Any]:
    formatted_output = {"mappings": []}

    for prop in output.properties:
        mapping = {"target": prop.name, "candidates": []}

        for t in prop.transformations:
            function_name = t.transform_uid
            index_mapping = argument_index_mapping.get(function_name, {})

            candidate = {
                "transform_uid": t.transform_uid,
                "arguments": t.arguments,
                "param_position_map": {
                    arg: index_mapping.get(arg, -1)
                    for arg in t.arguments.keys()
                },  # Default to -1 if missing in input
                "explanation": t.explanation,
            }

            mapping["candidates"].append(candidate)

        formatted_output["mappings"].append(mapping)

    return formatted_output


# **Endpoints**
@app.post("/solve-schema-matching")
async def schema_matching_endpoint(
    request_data: SchemaMatchingRequest,
) -> Dict[str, Any]:
    logger.info("Received schema matching request.")
    try:
        source_schema = convert_to_input_table_schema(request_data.source)
        target_schema = convert_to_input_table_schema(request_data.target)

        run_kwargs = {
            "source_schema": source_schema,
            "target_schema": target_schema,
            "transformations": [],
            "mapping_type": "ONE_TO_ONE",
            "config_path": CONFIG_PATH,
        }

        if request_data.platform:
            run_kwargs["platform"] = request_data.platform
        if request_data.explainer_model_id:
            run_kwargs["explainer_model_id"] = request_data.explainer_model_id
        if request_data.judge_model_id:
            run_kwargs["judge_model_id"] = request_data.judge_model_id
        if request_data.ranker_model_id:
            run_kwargs["ranker_model_id"] = request_data.ranker_model_id

        output: OutputTableSchemaTransformations = run(**run_kwargs)
        print(output)
        logger.info("Schema matching completed successfully.")
        return format_schema_matching_output(output)

    except Exception as e:
        logger.exception(f"Unexpected error during schema matching: {e}")
        raise HTTPException(
            status_code=500, detail="Internal server error occurred."
        ) from e


@app.post("/solve-transformations")
async def transformation_endpoint(
    request_data: TransformationRequest,
) -> Dict[str, Any]:
    logger.info("Received transformation request.")
    try:
        source_schema = convert_to_input_table_schema(request_data.source)
        target_schema = convert_to_input_table_schema(request_data.target)
        transformations = convert_to_transforms(request_data.functions)
        argument_index_mapping = get_argument_index_mapping(
            request_data.functions
        )

        run_kwargs = {
            "source_schema": source_schema,
            "target_schema": target_schema,
            "transformations": transformations,
            "config_path": CONFIG_PATH,
        }

        if request_data.platform:
            run_kwargs["platform"] = request_data.platform
        if request_data.mapping_type:
            run_kwargs["mapping_type"] = request_data.mapping_type
        if request_data.explainer_model_id:
            run_kwargs["explainer_model_id"] = request_data.explainer_model_id
        if request_data.judge_model_id:
            run_kwargs["judge_model_id"] = request_data.judge_model_id
        if request_data.ranker_model_id:
            run_kwargs["ranker_model_id"] = request_data.ranker_model_id

        output: OutputTableSchemaTransformations = run(**run_kwargs)
        logger.info("Transformation process completed successfully.")

        # Pass index mapping into the output formatter
        return format_transformation_output(output, argument_index_mapping)

    except Exception as e:
        logger.exception(f"Unexpected error during transformation: {e}")
        raise HTTPException(
            status_code=500, detail="Internal server error occurred."
        ) from e
