"""
Custom types.

Currently these are just type aliases which serve to make type hints more
descriptive.
"""

from typing import Optional, List, TypeAlias
from types import NoneType

from pydantic import BaseModel
from gin.common.types import ApiCallInf

# OpenAPI v3 specification
ApiSpec: TypeAlias = dict

# Conversion between types that may be listed in an API specification and their
# Python counterparts
SPEC_TYPES = {
    "any": str,
    "array": list,
    "arraylist": list,
    "bigint": int,
    "bool": bool,
    "boolean": bool,
    "byte": int,
    "char": str,
    "dict": dict,
    "double": float,
    "float": float,
    "hashtable": dict,
    "hashmap": dict,
    "integer": int,
    "list": list,
    "long": int,
    "number": float,
    "null": NoneType,
    "object": dict,
    "queue": list,
    "stack": list,
    "short": int,
    "string": str,
    "tuple": tuple,
    "str": str,
}


class ApiCallStaticIssues(BaseModel):
    """Issues with generated API call."""

    api_call: ApiCallInf
    """The API call the issue is associate with"""
    none_func: Optional[bool] = False
    """We are not able to identify the USER's intent."""

    syntax_error: Optional[bool] = False
    """Some syntactical error with the raw substring from the LLM that prevents
    further processing to determine how the API call should be formatted."""

    call_hallucinated: Optional[bool] = False
    """Boolean that indicates whether the selected API call is hallucinated."""

    param_hallucinated: Optional[List[str]] = []
    """List of parameters that are not valid for the selected API call."""

    param_mistyped: Optional[List[str]] = []
    """List of parameters that have values of the incorrect type."""

    param_missing: Optional[List[str]] = []
    """List of required parameters that are missing from the API call."""

    param_missing_info: Optional[List[str]] = []
    """List of required parameters that are missing information from the user
    utterance."""

    param_outside_bounds: Optional[List[str]] = []
    """"List of parameters whose value is not part of the allowed values."""

    blank_substring: Optional[int] = 0
    """A count of the number of times a blank substring exists in a function
    call's arguments. This is where a set of commas occur with nothing between,
    such as my_func_call(param_a=5, param_b=84, , param_c=9)"""

    invalid_pair: Optional[List[str]] = []
    """Key-value substrings to a function call argument that do not contain a
    valid key-value pair. This can occur if a value is passed as a positional
    argument rather than as a keyword argument."""

    repeated_arg: Optional[List[str]] = []
    """Key-value substrings to a function call argument that use a keyword
    which has been provided more than once. This list includes all key-value
    substrings beyond the first instance of a particular keyword."""

    invalid_value: Optional[List[str]] = []
    """Key-value substrings to a function call argument that have a value which
    does not appear to be syntactically valid. This could be, for example, a
    string that does not have a closing quote or a list missing a bracket."""

    def has_issues(self) -> bool:
        """Return true if any issues exist."""
        if self.none_func:
            return True
        if self.syntax_error:
            return True
        if self.call_hallucinated:
            return True
        if self.param_hallucinated:
            return True
        if self.param_mistyped:
            return True
        if self.param_missing:
            return True
        if self.param_missing_info:
            return True
        if self.param_outside_bounds:
            return True
        if self.blank_substring:
            return True
        if self.invalid_pair:
            return True
        if self.repeated_arg:
            return True
        if self.invalid_value:
            return True
        return False
