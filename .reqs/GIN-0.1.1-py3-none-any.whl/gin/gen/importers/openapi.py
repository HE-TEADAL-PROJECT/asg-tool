"""
Import and supporting functions for OpenAPI specifications.
"""

import logging
import yaml

from gin.gen.types import ApiSpec
from gin.common.logging import Logging


def import_openapi_spec(spec_file_path: str) -> ApiSpec:
    """
    Import OpenAPI v3 specification file.

    Args:
        spec_file_path (str): Path to OpenAPI specification file.

    Returns:
        ApiSpec: OpenAPI specification.
    """
    base_log = logging.getLogger(Logging.BASE)

    if not spec_file_path:
        raise ValueError("OpenAPI specification file not supplied!")

    base_log.debug("Loading OpenAPI specification file: %s", spec_file_path)
    with open(spec_file_path, "r", encoding="UTF-8") as file:
        api_spec = yaml.safe_load(file)
    if "openapi" in api_spec:
        major = int(api_spec["openapi"].split(".")[0])
    elif "swagger" in api_spec:
        major = int(api_spec["swagger"].split(".")[0])
    else:
        major = 0
    if major != 3:
        base_log.warning(
            "This does not appear to be an OPenAPI v3 spec: %s", spec_file_path
        )
        # raise NotImplementedError('Convert specification file to OpenAPI v3')
    return api_spec


def check_for_endpoint_method(
    spec: ApiSpec, endpoint: str, method: str
) -> None:
    """
    Check that endpoint and method exists within OpenAPI v3 specification.

    If endpoint does not exist, raise errors

    Args:
        spec (ApiSpec): OpenAPI v3 specification.
        endpoint (str): Endpoint to check.
        method (str): Request method of endpoint to check.
    """
    base_log = logging.getLogger(Logging.BASE)
    if endpoint not in spec["paths"]:
        base_log.error("Endpoint does not exist: %s", endpoint)
        raise IndexError()
    if method not in spec["paths"][endpoint]:
        base_log.error(
            "Endpoint %s does not support method: %s", endpoint, method
        )
        raise IndexError()


def extract_security_for_path(
    spec: ApiSpec, endpoint: str, method: str
) -> list[str]:
    """
    Get security type for endpoint, if no security return default security.


    Args:
        spec (ApiSpec): OpenAPI v3 specification.
        endpoint (str): Endpoint.
        method (str): Request method of endpoint.
    """

    # Check if security is defined at the operation (endpoint+method) level
    operation_security = spec["paths"][endpoint][method].get("security", [])
    if operation_security:
        return operation_security

    # Check if security is defined at the endpoint level
    endpoint_security = spec["paths"][endpoint].get("security", [])

    if endpoint_security:
        return endpoint_security

    # If no security is defined, return default security (if exists)
    return spec.get("security", [])


def extract_server_for_path(
    spec: ApiSpec, endpoint: str, method: str
) -> list[str]:
    """
    Get server information for endpoint, if no server defined under endpoint use default.


    Args:
        spec (ApiSpec): OpenAPI v3 specification.
        endpoint (str): Endpoint.
        method (str): Request method of endpoint.
    """

    # Check if server is defined at the operation (endpoint+method) level
    operation_server = spec["paths"][endpoint][method].get("servers", [])
    if operation_server:
        return operation_server

    # Check if server is defined at the endpoint level
    endpoint_server = spec["paths"][endpoint].get("servers", [])

    if endpoint_server:
        return endpoint_server

    # If no server is defined, return default server (if exists)
    return spec.get("servers", [])
