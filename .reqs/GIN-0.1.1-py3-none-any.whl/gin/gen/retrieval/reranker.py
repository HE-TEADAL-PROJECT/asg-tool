from typing import Optional, Sequence, Any

from langchain.schema import Document
from langchain.callbacks.manager import Callbacks
from langchain.retrievers.document_compressors.base import (
    BaseDocumentCompressor,
)


class RerankModel(BaseDocumentCompressor):
    """
    Model for re-ranking documents.
    Args:
        model_def (ModelDef): Model to create an instance of.

    """

    reranker_model: Any

    def model_rerank(self, query, docs):
        return self.reranker_model.rerank(query, docs)

    class Config:
        """Configuration for this pydantic object."""

        extra = "forbid"
        arbitrary_types_allowed = True

    def compress_documents(
        self,
        documents: Sequence[Document],
        query: str,
        callbacks: Optional[Callbacks] = None,
    ) -> Sequence[Document]:
        """
        Compress documents using model.

        Args:
            documents (Sequence[Document]): A sequence of documents to compress.
            query (str): The query to use for compressing the documents.
            callbacks (Optional[Callbacks]): Callbacks to run during the compression process.

        Returns:
            Sequence[Document]: A sequence of compressed documents.
        """
        if len(documents) == 0:  # to avoid empty api call
            return []
        doc_list = list(documents)
        _docs = [d.page_content for d in doc_list]
        result = self.model_rerank(query, _docs)
        final_results = []
        for rank, res in enumerate(result, start=1):
            doc = doc_list[res.index]
            doc.metadata["relevance_score"] = res.score
            final_results.append(doc)
        return final_results
