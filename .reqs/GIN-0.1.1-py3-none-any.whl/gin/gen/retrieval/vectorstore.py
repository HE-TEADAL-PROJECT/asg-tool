"""
Vector stores for semantic searching.
"""

import json
from typing import List
from langchain_core.vectorstores import VectorStoreRetriever
from langchain_chroma import Chroma
import chromadb
from gin.gen.loaders import ToolDocumentLoader
from gin.common.types import ToolDetails
from gin.gen.retrieval.chroma_embedding import ChromaEmbedding


class LocalVS:
    """Local vector store used for semantic searching."""

    def __init__(
        self, embedding_model, persistent_vector_store_dir=""
    ) -> None:
        """
        Initialize class.

        Args:
            model_def (ModelDef): Model to use for embedding.
            persistent_vector_store_dir(str): Directory to save the VS data, if
                not provided creates an in memory instance.
        """
        self.persistent_vector_store_dir = persistent_vector_store_dir
        self.default_collection = "default"

        self.langchain_embeddings = embedding_model
        self.embeddings = ChromaEmbedding(embedding_model)
        self.langchain_vs = None
        self.langchain_retriever = None

        # The `persistent_vector_store_dir` parameter in the `LocalVS` class constructor is
        # used to specify the directory where the vector store data will be saved if a
        # persistent storage option is desired. If this parameter is provided with a directory
        # path, the vector store will be created as a `PersistentClient` using the specified
        # directory path. If the parameter is not provided or an empty string is passed, an
        # in-memory instance of the vector store (`EphemeralClient`) will be
        # created instead.
        if not persistent_vector_store_dir:
            self.vector = chromadb.EphemeralClient()
        else:
            self.vector = chromadb.PersistentClient(
                path=persistent_vector_store_dir
            )

    def load_ephemeral_langchain(
        self, tools: List[ToolDetails], title: str, top_k: int = 4
    ) -> VectorStoreRetriever:
        """
        Load one List of tools into ephemeral vector store with
        langchain and return it as retriever.

        Args:
            tools (List[ToolDetails]): List of tool objects.
            title (str): Unique ID for the particular application.
            top_k (int): Number of top results to return during retrieval.

        Returns:
            VectorStoreRetriever: Retriever for vector store.
        """
        loader = ToolDocumentLoader(tools, title)
        documents = loader.load()
        self.langchain_vs = Chroma.from_documents(
            documents, self.langchain_embeddings
        )
        return self.langchain_vs.as_retriever(
            search_type="similarity", search_kwargs={"k": top_k}
        )

    def load_tools(self, tools: list[ToolDetails], title: str) -> None:
        """
        Load OpenAPI specification into vector store.

        Args:
            spec (ToolDetails): OpenAPI specification.
            title (str): Unique ID for the particular application.
        """
        loader = ToolDocumentLoader(tools, title)
        documents = loader.load()
        collection = self.vector.get_or_create_collection(
            name=self.default_collection, embedding_function=self.embeddings
        )
        for doc in documents:
            tool_details_dict = json.loads(doc.metadata["tool_details_str"])
            id_ = title + "_" + tool_details_dict["name"]
            collection.add(
                ids=[id_], metadatas=doc.metadata, documents=doc.page_content
            )

    def get_retriever(self, top_k: int = 4) -> VectorStoreRetriever:
        """
        Get retriever for vector store.
        Args:
            top_k (int): Number of results to return during retrieval.
        Returns:
            VectorStoreRetriever: Retriever for vector store.
        """
        self.langchain_retriever = Chroma(
            client=self.vector,
            collection_name=self.default_collection,
            embedding_function=self.langchain_embeddings,
        )

        return self.langchain_retriever.as_retriever(
            search_type="similarity", search_kwargs={"k": top_k}
        )
