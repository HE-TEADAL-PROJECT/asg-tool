import logging

from langchain_core.vectorstores import VectorStoreRetriever

import gin.common.ai_platforms
import gin.gen.config
import gin.gen.importers.openapi
import gin.gen.retrieval.vectorstore
import gin.gen.loaders
from gin.common.logging import Logging
from gin.common.types import PlatformCredentials, ModelDef, ModelType
from gin.common.types import ToolDetails
from gin.common.ai_platforms import get_llm_on_platform


def get_embedding_model(conf: gin.gen.config.BaseConfig):
    model_shortname = conf.generation.retrieval.models[0]
    model_host = conf.models[model_shortname].host
    embedding_model = ModelDef(
        model_id=conf.models[model_shortname].id,
        credentials=PlatformCredentials(
            api_base=conf.ai_platforms[model_host].credentials.api_base,
            api_key=conf.ai_platforms[
                model_host
            ].credentials.api_key.get_secret_value(),
            api_project_id=conf.ai_platforms[
                model_host
            ].credentials.api_project_id,
        ),
        platform=conf.ai_platforms[model_host].platform,
        model_type=ModelType.EMBEDDINGS,
        model_params=conf.models[model_shortname].parameters,
    )
    return get_llm_on_platform(embedding_model)


def load_get_vs_ephemeral_langchain(
    conf: gin.gen.config.BaseConfig,
    tools: list[ToolDetails],
    title: str,
) -> VectorStoreRetriever:
    """
    Load list of tools into ephemeral vector store with langchain
    and return it as retriever.

    Args:
        conf (BaseConfig): Application configuration.
        tools (list[ToolDetails]): List of tool details.
        title (str): Unique ID for the particular application.

    Returns:
        VectorStoreRetriever: Vector store loaded with tool details.
    """
    embedding_model = get_embedding_model(conf)
    # Set up vector store and retriever.
    vectorstore = gin.gen.retrieval.vectorstore.LocalVS(embedding_model)
    return vectorstore.load_ephemeral_langchain(
        tools, title, top_k=conf.generation.retrieval.top_k
    )


def get_loaded_vs(
    conf: gin.gen.config.BaseConfig,
) -> VectorStoreRetriever:
    """
    Get the already loaded vector store as a retriever.

    Args:
        conf (BaseConfig): Application configuration.

    Returns:
        VectorStoreRetriever: Vector store.
    """
    embedding_model = get_embedding_model(conf)

    # Set up vector store and retriever.
    vectorstore = gin.gen.retrieval.vectorstore.LocalVS(
        embedding_model, conf.generation.retrieval.persistent_vector_store_dir
    )
    return vectorstore.get_retriever(top_k=conf.generation.retrieval.top_k)


def add_specs(
    conf: gin.gen.config.BaseConfig,
    specs_files: list[str],
    log_level: str = None,
) -> gin.gen.retrieval.vectorstore.LocalVS:
    """
    Load vector store with a list of specs.

    Args:
        conf (BaseConfig): Application configuration.
        specs_files (List[str]): Path to OpenAPI specification files.
        log_level (str): Logging level to set or None to set the default level.

    Returns:
        VectorStoreRetriever: Vector store.
    """
    # Set log level
    Logging(log_level=log_level)

    base_log = logging.getLogger(Logging.BASE)
    embedding_model = get_embedding_model(conf)
    # Set up vector store and embeddings model
    vectorstore = gin.gen.retrieval.vectorstore.LocalVS(
        embedding_model, conf.generation.retrieval.persistent_vector_store_dir
    )
    # Path to OpenAPI specification files.
    for spec_file in specs_files:
        # Import the OpenAPI specification file
        openapi_spec = gin.gen.importers.openapi.import_openapi_spec(spec_file)
        spec_title = openapi_spec["info"]["title"]
        base_log.info("Load spec file: %s", spec_title)
        tools = gin.gen.loaders.openapi_to_tool_list(openapi_spec)
        vectorstore.load_tools(tools, title=spec_title)

    return vectorstore
