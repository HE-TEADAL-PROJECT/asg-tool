from typing import List, Any

from langchain.schema import Document
from langchain_core.vectorstores import VectorStoreRetriever
from langchain_core.callbacks.manager import CallbackManagerForRetrieverRun
from langchain_core.vectorstores import VectorStore


class VectorStoreRetrieverWithScores(VectorStoreRetriever):
    """
    A retriever that returns documents with their similarity scores.

    OLD:
        retriever = my_vector_store.as_retriever(search_type="similarity")

    NEW:
        retriever = RetrieverWithScores.from_vector_store(my_vector_store, search_type="similarity")
    """

    def _get_relevant_documents(
        self, query: str, *, run_manager: CallbackManagerForRetrieverRun
    ) -> List[Document]:
        if self.search_type == "similarity":
            docs_and_similarities = (
                self.vectorstore._similarity_search_with_relevance_scores(
                    query, **self.search_kwargs
                )
            )
        elif self.search_type == "similarity_score_threshold":
            docs_and_similarities = (
                self.vectorstore.similarity_search_with_relevance_scores(
                    query, **self.search_kwargs
                )
            )
        elif self.search_type == "mmr":
            docs = self.vectorstore.max_marginal_relevance_search(
                query, **self.search_kwargs
            )
            docs_and_similarities = [(doc, 0.0) for doc in docs]
        else:
            raise ValueError(f"search_type of {self.search_type} not allowed.")

        for doc, score in docs_and_similarities:
            doc.metadata = {**doc.metadata, **{"similarity_score": score}}
        return [doc for (doc, _) in docs_and_similarities]

    @staticmethod
    def from_vector_store(
        vector_store: VectorStore, **kwargs: Any
    ) -> "VectorStoreRetrieverWithScores":
        """
        Return VectorStoreRetriever initialized from this VectorStore.
        This is basically a copy of VectorStore.as_retriever method.

        """
        tags = kwargs.pop("tags", None) or []
        return VectorStoreRetrieverWithScores(
            vectorstore=vector_store, **kwargs, tags=tags
        )
