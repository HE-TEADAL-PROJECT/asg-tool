"""
Retrieval of best candidates for API calls from a large pool of available APIs.
"""
