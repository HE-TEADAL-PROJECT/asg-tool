"""LLM-specific classes and functions."""

import logging
from typing import List, Any, Tuple, Callable
from langchain.prompts import PromptTemplate
from langchain_core.prompts.string import DEFAULT_FORMATTER_MAPPING

from gin.gen.types import ApiCallInf
from gin.common.types import ModelDef
from gin.common.logging import Logging

from gin.gen.models.gorilla import MODELS as MODELS_GORILLA
from gin.gen.models.granite import MODELS as MODELS_GRANITE
from gin.gen.models.llama import MODELS as MODELS_LLAMA

DEAFULT_MODEL_ID = "ibm/granite-3-8b-instruct"
DEAFULT_MODEL_CLASS = "granite"

MODELS = {
    "gorilla": MODELS_GORILLA,
    "granite": MODELS_GRANITE,
    "llama": MODELS_LLAMA,
}


def get_model_functions(
    model_id: str,
) -> Tuple[
    Callable[[Any], str],
    Callable[[], PromptTemplate],
    Callable[[str], List[ApiCallInf]],
]:
    """
    Given a model ID, return the appropriate functions.

    Args:
        model_id (str): Model ID

    Returns:
        Tuple[
            Callable[[Any], str],         # Function for making a call description
            Callable[[], PromptTemplate], # Function for getting the prompt template
            Callable[[str], List[ApiCallInf]] # Function for preparing API calls
        ]: The model functions corresponding to `model_id`.
        If the model is not supported, returns the functions of a default model
        in the following order: make_call_desc, get_prompt_template, prep.
    """
    base_log = logging.getLogger(Logging.BASE)
    for model_class, model_ids in MODELS.items():
        if model_id in model_ids:
            model_data = MODELS.get(model_class, {}).get(model_id, {})
            return (
                model_data.get("make_call_desc"),
                model_data.get("get_prompt_template"),
                model_data.get("prep"),
            )

    base_log.error(
        "Model is not supported: %s, returning default model functions",
        model_id,
    )

    default_model_data = MODELS[DEAFULT_MODEL_CLASS][DEAFULT_MODEL_ID]
    return (
        default_model_data.get("make_call_desc"),
        default_model_data.get("get_prompt_template"),
        default_model_data.get("prep"),
    )


class ApiPromptTemplate(PromptTemplate):
    """Prompt template class for fabricating custom API descriptors in f-strings."""

    model_id: str
    """The LLM which will receive the content from this template."""

    def format(self, **kwargs: Any) -> str:
        base_log = logging.getLogger(Logging.BASE)
        kwargs = self._merge_partial_and_user_variables(**kwargs)
        # Currently 'tool_details_str' in kwargs contains a serialized
        # ToolDetails object.
        # We will overwrite this with the complete API call description
        # formatted for the specific LLM.
        mcd_func = get_model_functions(self.model_id)[0]
        if not mcd_func:
            base_log.error(
                "Model does not have make_call_desc function: %s",
                self.model_id,
            )
            raise NotImplementedError()
        # Make the tool description for the LLM, overwriting the serialized
        # ToolDetails. This will get inserted as part of the context in the
        # prompt.
        kwargs["tool_details_str"] = mcd_func(**kwargs)
        return DEFAULT_FORMATTER_MAPPING[self.template_format](
            self.template, **kwargs
        )


def get_prompt_template(model_def: ModelDef) -> PromptTemplate:
    """
    Get the prompt template for an LLM.

    Args:
        model_def (ModelDef): Model to get prompt template for.

    Returns:
        PromtTemplate: Prompt template for LLM.
    """
    base_log = logging.getLogger(Logging.BASE)
    gpt_func = get_model_functions(model_def.model_id)[1]
    if not gpt_func:
        base_log.error(
            "Model does not have get_prompt_template function: %s",
            model_def.model_id,
        )
        raise NotImplementedError()
    return gpt_func()


def get_document_prompt_template(model_def: ModelDef) -> PromptTemplate:
    """
    Get template for API endpoint description.

    This is the format that the API descriptions will be mapped to and inserted
    into the 'context' variable of the LLM prompt.

    Args:
        model_def (ModelDef): Model to get prompt template for.

    Returns:
        PromptTemplate: Template for API endpoint descriptions.
    """
    document_prompt = ApiPromptTemplate(
        model_id=model_def.model_id,
        input_variables=["tool_details_str"],
        template="{tool_details_str}",
    )
    return document_prompt


def prep(model_def: ModelDef, raw_inf: str) -> List[ApiCallInf]:
    """
    Convert raw LLM response to a list of API calls in standard format.

    Args:
        model_def (ModelDef): Model used to create inference.
        raw_inf (str): Raw response from the LLM.

    Returns:
        list: List of API calls.
    """
    base_log = logging.getLogger(Logging.BASE)
    prep_func = get_model_functions(model_def.model_id)[2]
    if not prep_func:
        base_log.error(
            "Model does not have prep function: %s", model_def.model_id
        )
        raise NotImplementedError()
    return prep_func(raw_inf)
