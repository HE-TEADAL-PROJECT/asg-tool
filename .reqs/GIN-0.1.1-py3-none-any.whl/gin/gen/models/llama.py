import json
import logging
from typing import List


from gin.gen.util import remove_invalid_json_escapes
from gin.gen.types import ApiCallInf
from gin.common.logging import Logging


def prep(raw_inf: str) -> List[ApiCallInf]:
    """
    Convert raw LLM response to a list of API calls in standard format.

    Args:
        raw_inf (str): Raw response from the LLM.

    Returns:
        list: List of API calls.
    """
    base_log = logging.getLogger(Logging.BASE)
    calls_raw = raw_inf.split("\n")
    calls = []
    # Split apart individual API calls and convert each to standard format
    for call_str_raw in calls_raw:
        base_log.debug("Parsing call string: %s", call_str_raw)
        call_str = call_str_raw.strip()
        call_str = remove_invalid_json_escapes(call_str)
        try:
            call_dict = json.loads(call_str)
            call_dict["valid"] = True
        except json.decoder.JSONDecodeError:
            # Could not decode JSON
            base_log.error("Could not load JSON string: %s", call_str)
            call_dict = {"valid": False}
        call_dict["raw_str"] = call_str_raw
        if "arguments" in call_dict:
            # Rename 'arguments' key to 'parameters'
            if "parameters" in call_dict:
                # A 'parameters' field should not be produced by Granite
                base_log.error(
                    'Call inference contains both "arguments" and "parameters": %s',
                    call_str,
                )
            call_dict["parameters"] = call_dict.pop("arguments")
        calls.append(ApiCallInf(**call_dict))

    return calls


MODELS = {
    "peri/llama-3-70b-instruct": {
        "make_call_desc": None,
        "get_prompt_template": None,
        "prep": prep,
    },
    "meta-llama/llama-3-1-70b-instruct": {
        "make_call_desc": None,
        "get_prompt_template": None,
        "prep": prep,
    },
}
