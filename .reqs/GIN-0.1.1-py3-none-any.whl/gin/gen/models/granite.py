"""Granite Unified API models"""

import json
import logging
import re
from typing import List, Any

from langchain.prompts import PromptTemplate

from gin.gen.util import remove_invalid_json_escapes
from gin.gen.types import ApiCallInf
from gin.common.types import ToolDetails

from gin.common.logging import Logging


# The Granite Unified API model takes function description strings as JSON
# artifacts with the format (as a single line, broken here only for legibility):
#
# {"name": "<api_name_1>", "description": "api description",
#  "arguments": {"arg1_name": "arg1_description",
#                "arg2_name": "arg2_description"...}}

# The Granite 3 Instruct model takes function description strings as JSON
# artifacts with the format (as a single line, broken here only for legibility):
#
# {"name": "<api_name_1>", "description": "api description",
#  "parameters": {
#       "type": "object",
#       "properties":
#         {"param1_name": {"type": "param name", "description": "param description" },
#          "param2_name": {"type": "param name", "description": "param description" }
#       },
#        "required": ["required param1 name", ...] }}


def make_call_desc(fmt: str = "", **kwargs: Any) -> str:
    """
    Make a string that describes the API call for the LLM.

    Args:
        fmt (str): The format for creating the call string, such as 'granite3'
            or 'granite'.

    Returns:
        str: Description of a function call, formatted for LLM consumption.
    """
    # Load seraialized ToolDetails from tool_details_str
    tool_details_dict = json.loads(kwargs["tool_details_str"])
    tool_details = ToolDetails(**tool_details_dict)

    # Return as a JSON formatted string
    tool_details_return = {
        "name": tool_details.name,
        "description": tool_details.description,
        "parameters": tool_details.parameters,
    }
    return json.dumps(tool_details_return)


def get_prompt_template() -> PromptTemplate:
    """
    Get the prompt template for the Granite Unified API LLM.

    Returns:
        PromptTemplate: Prompt template for LLM.
    """
    prompt_template = (
        "SYSTEM: You are a helpful assistant with access to"
        + " the following function calls. Your task is to produce a sequence"
        + " of function calls necessary to generate response to the user"
        + " utterance. Use the following function calls as required.\n"
        + " If you are not able to identify the USER's intent, please return"
        + ' "none" function from the below function library or return'
        + ' "<function_call> {{"name": "none", "arguments": {{}}}}".\n'
        + "<|function_call_library|>\n"
        + "{context}\n"
        + '{{"name": "none", "arguments": {{}}}}\n\n'
        + "USER: {input}\n"
        + "ASSISTANT: "
    )
    prompt = PromptTemplate(
        input_variables=["input", "context"],
        template=prompt_template,
    )
    return prompt


def get_prompt_template_granite3() -> PromptTemplate:
    """
    Get the prompt template for the Granite 3 Unified API LLM.

    Returns:
        PromptTemplate: Prompt template for LLM.
    """
    prompt_template = (
        "<|start_of_role|>system<|end_of_role|> You are a helpful assistant with access to the following function calls."
        + " Your task is to produce a sequence of function calls necessary to generate response"
        + " to the user utterance. Use the following function calls as required {context}"
        + " If you are not able to identify the USER's intent, please return"
        + ' "none" function from the below function library or return'
        + ' {{"name": "none", "arguments": {{}}}}\n\n'
        + "<|start_of_role|>user<|end_of_role|> {input} <|end_of_text|>\n<|start_of_role|>assistant<|end_of_role|>"
    )
    prompt = PromptTemplate(
        input_variables=["input", "context"],
        template=prompt_template,
    )
    return prompt


def prep(raw_inf: str) -> List[ApiCallInf]:
    """
    Convert raw LLM response to a list of API calls in standard format.

    Args:
        raw_inf (str): Raw response from the LLM.

    Returns:
        list: List of API calls.
    """
    base_log = logging.getLogger(Logging.BASE)

    calls = []
    # Split apart individual API calls and convert each to standard format
    calls_raw = raw_inf.split("<function_call>")
    calls_raw.pop(0)
    for call_str_raw in calls_raw:
        base_log.debug("Parsing call string: %s", call_str_raw)
        call_str = call_str_raw.strip()
        call_str = remove_invalid_json_escapes(call_str)
        try:
            call_dict = json.loads(call_str)
            call_dict["valid"] = True
        except json.decoder.JSONDecodeError:
            try:
                # HACK
                # ibm/granite-20b-code-instruct has been found to add single
                # quotes around dict values to arguments. This is a hack fix
                # to remove all single quotes and try re-parsing.
                call_dict = json.loads(call_str.replace("'", ""))
                base_log.error(
                    "Removed all single quotes from LLM inference to allow JSON parsing: %s",
                    call_str,
                )
                call_dict["valid"] = True
            except json.decoder.JSONDecodeError:
                # Could not decode JSON
                base_log.error("Could not load JSON string: %s", call_str)
                call_dict = {"valid": False}
        call_dict["raw_str"] = call_str_raw
        if "arguments" in call_dict:
            # Rename 'arguments' key to 'parameters'
            if "parameters" in call_dict:
                # A 'parameters' field should not be produced by Granite
                base_log.error(
                    'Call inference contains both "arguments" and "parameters": %s',
                    call_str,
                )
            call_dict["parameters"] = call_dict.pop("arguments")
        calls.append(ApiCallInf(**call_dict))

    return calls


def prep_granite3(raw_inf: str) -> List[ApiCallInf]:
    """
    Convert raw LLM response to a list of API calls in standard format.

    Args:
        raw_inf (str): Raw response from the LLM.

    Returns:
        list[ApiCallInf]: List of API calls.
    """

    base_log = logging.getLogger(Logging.BASE)
    base_log.debug(f"prep_granite3 - enter with: {raw_inf}")
    calls = []

    # Extract JSON-like substring between { and }
    match = re.search(r"\{(.*)\}", raw_inf, re.DOTALL)
    base_log.debug(f"match={match}")
    if not match:
        # No JSON-like structure found
        return [ApiCallInf(
            raw_str=raw_inf,
            valid=False,
            issues={"missing_braces": True}
        )]

    functions_array = "[" + match.group(0) + "]"
    base_log.debug(f"functions_array={functions_array}")
    try:
        functions = json.loads(functions_array)
    except json.JSONDecodeError:
        return [ApiCallInf(
            raw_str=raw_inf,
            valid=False,
            issues={"syntax_error": True}
        )]

    for func in functions:
        call_dict = dict(func)  # ensure we don't mutate json's dict
        call_dict["valid"] = True
        call_dict["raw_str"] = raw_inf
        if "arguments" in call_dict:
            if "parameters" in call_dict:
                base_log.error(
                    'Call inference contains both "arguments" and "parameters": %s',
                    raw_inf,
                )
            call_dict["parameters"] = call_dict.pop("arguments")
        calls.append(ApiCallInf(**call_dict))

    return calls

MODELS = {
    "ibm/granite-20b-code-instruct": {
        "make_call_desc": make_call_desc,
        "get_prompt_template": get_prompt_template,
        "prep": prep,
    },
    "ibm/granite-20b-code-instruct-unified-api": {
        "make_call_desc": make_call_desc,
        "get_prompt_template": get_prompt_template,
        "prep": prep,
    },
    "ibm-granite/granite-20b-code-instruct-unified-api": {
        "make_call_desc": make_call_desc,
        "get_prompt_template": get_prompt_template,
        "prep": prep,
    },
    "ibm/granite-8b-unified-api-model-v0": {
        "make_call_desc": make_call_desc,
        "get_prompt_template": get_prompt_template,
        "prep": prep,
    },
    "ibm/granite-8b-unified-api-model-v2": {
        "make_call_desc": make_call_desc,
        "get_prompt_template": get_prompt_template,
        "prep": prep,
    },
    "ibm/granite-3-8b-instruct": {
        # use lambda function that sets the format in make_call_desc to granite3.
        "make_call_desc": lambda **kwargs: make_call_desc(
            fmt="granite3", **kwargs
        ),
        "get_prompt_template": get_prompt_template_granite3,
        "prep": prep_granite3,
    },
    "ibm-granite/granite-3.1-8b-instruct": {
        # use lambda function that sets the format in make_call_desc to granite3.
        "make_call_desc": lambda **kwargs: make_call_desc(
            fmt="granite3", **kwargs
        ),
        "get_prompt_template": get_prompt_template_granite3,
        "prep": prep_granite3,
    },
}
