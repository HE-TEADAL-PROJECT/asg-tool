"""Gorilla OpenFunctions models."""

import json
import logging
from typing import List, Any

from langchain.prompts import PromptTemplate

from gin.gen.util import func_call_format_good, get_kv_pairs
from gin.gen.types import ApiCallInf
from gin.common.types import ToolDetails
from gin.common.logging import Logging


# The Gorilla OpenFunctions v2 model takes function description strings as JSON
# artifacts with the format (combined as a list, broken here for legibility):
#
# [{"name": "<api_name_1>",
#  "description": "api description",
#  "parameters": {    <-- Only present if there are params
#    "type": "dict",
#    "properties": {
#      "arg1_name": {
#        "type": "arg1_type",
#        "description": "arg1_description",
#        "default": "default_value"   <-- Only present if there is a default
#      },
#      "arg2_name": {
#        "type": "arg2_type",
#        "description": "arg2_description"
#      }
#    },
#    "required": ["arg1_name"]   <-- Only present if required params exist
#  }
# }, <next API call goes here...>]


def make_call_desc(**kwargs: Any) -> str:
    """Make a string that describes the API call for the LLM."""
    # Load seraialized ToolDetails from tool_details_str
    tool_details_dict = json.loads(kwargs["tool_details_str"])
    tool_details = ToolDetails(**tool_details_dict)

    # Make dict of function parameters and their description.
    args_desc = {"type": "dict", "properties": {}}
    required = []
    for name, param_details in tool_details.parameters.items():
        args_desc["properties"][name] = {
            "type": param_details.type,
            "description": param_details.description,
        }
        if param_details.default:
            args_desc["properties"][name]["default"] = param_details.default
        if param_details.required:
            required.append(name)
        # TODO add support for array/object types, references
        # Addressed in https://github.ibm.com/mc-connectors/connector/issues/51
        # TODO add support for default values. Partly addressed in
        # https://github.ibm.com/mc-connectors/connector/issues/185
    if required:
        args_desc["required"] = required

    # Complete description structure for the API call
    call_desc = {
        "name": tool_details.name,
        "description": tool_details.description,
    }
    if tool_details.parameters:
        call_desc["parameters"] = args_desc
    # Return as a JSON formatted string
    return json.dumps(call_desc)


# Prompt used in v2, found at
# https://huggingface.co/gorilla-llm/gorilla-openfunctions-v2
def get_prompt_template() -> PromptTemplate:
    """
    Get the prompt template for the Gorilla LLM.

    Returns:
        PromptTemplate: Prompt template for LLM.
    """
    prompt_template = (
        "You are an AI programming assistant, utilizing the"
        + " Gorilla LLM model, developed by Gorilla LLM, and you only answer"
        + " questions related to computer science. For politically sensitive"
        + " questions, security and privacy issues, and other non-computer"
        + " science questions, you will refuse to answer.\n"
        + "### Instruction: <<function>>{context}\n"
        + "<<question>>{input}\n"
        + "### Response: "
    )
    prompt = PromptTemplate(
        input_variables=["input", "context"],
        template=prompt_template,
    )
    return prompt


def prep(raw_inf: str) -> List[ApiCallInf]:
    """
    Convert raw LLM response to a list of API calls in standard format.

    This step first splits an inference into individual function call
    substrings. For each substring it then performs a syntactic check (a simple
    regular expression), and then splits apart the function name, and each of
    the argument key/value pairs, and returns the results along with any issues
    encountered along the way in a dict.

    Args:
        raw_inf (str): Raw response from the LLM.

    Returns:
        list: List of API calls.
    """
    base_log = logging.getLogger(Logging.BASE)
    calls = []
    # Split apart individual API calls and convert each to standard format
    # TODO need a more careful method of identifying and splitting individual
    # function calls. addressed in
    # https://github.ibm.com/mc-connectors/connector/issues/185
    for call_str_raw in raw_inf.strip().split("), "):
        call_str = call_str_raw.strip()
        if call_str == "":
            continue
        if call_str[-1:] != ")":
            call_str += ")"
        base_log.debug("Parsing call string: %s", call_str)
        call_dict = {"raw_str": call_str}

        # Check syntax
        call_dict["valid"] = func_call_format_good(call_str)
        if not call_dict["valid"]:
            calls.append(ApiCallInf(**call_dict))
            continue

        # Function call
        call_dict["name"] = call_str.split("(", 1)[0]
        # Parse arguments
        call_dict["parameters"], call_dict["issues"] = get_kv_pairs(call_str)
        calls.append(ApiCallInf(**call_dict))
    return calls


MODELS = {
    "gorilla-llm/gorilla-openfunctions-v2": {
        "make_call_desc": make_call_desc,
        "get_prompt_template": get_prompt_template,
        "prep": prep,
    }
}
