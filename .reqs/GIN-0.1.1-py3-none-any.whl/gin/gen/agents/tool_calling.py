import json
import logging
import copy
from typing import Any, List, TypedDict
from langchain.chains.combine_documents import create_stuff_documents_chain
from langgraph.graph import END, StateGraph
from langchain_core.documents.base import Document
from pydantic import ValidationError


import gin.gen.agents
import gin.common.ai_platforms
import gin.common.con_spec
from gin.common.types import ToolDetails

import gin.gen.config
import gin.gen.eval
import gin.gen.models
from gin.common.util import get_details_for_call
from gin.gen.config import BaseConfig
from gin.gen.types import (
    SPEC_TYPES,
    ApiCallStaticIssues,
)
from gin.gen.loaders import tool_to_semantic_description
from gin.common.logging import Logging
from gin.common.ai_platforms import get_llm_on_platform
from gin.common.types import ApiCallInf, ModelPurpose

# Import the reflector API and the output classes and enums (from llm_reasoning_judge/function_call_eval/output_schema.py)
from gin.gen.util.llm_reasoning_judge_interface import (
    MistakeType,
    ReflectionResult,
    load_api,
)


class ToolCallingState(TypedDict):
    conf: BaseConfig
    user_input: str
    issues: str
    missing_value_int: int
    context: List[Document]
    api_calls: List[ApiCallInf]
    static_api_calls: List[ApiCallInf]
    LLM_api_calls: List[ApiCallInf]
    iter_count: int
    feedback: ReflectionResult
    static_issues: List[ApiCallStaticIssues]


def _get_missing_info_value(type_str: str, missing_value_int: int) -> Any:
    """
    Get a unique value to use as a placeholder for a parameter that does not
    have its value specified in a user query.

    Args:
        type_str (str): String descriptor of of the value type to construct.
        missing_value_int (int): Integer value that is used as a base to
            construct a missing value.

    Returns:
        Any: Missing information placeholder, of appropriate type.
    """
    value_type = SPEC_TYPES[type_str.lower()]

    # Make a missing value placeholder of the appropriate type
    if value_type is bool:
        # Coming up with a unique bool doesn't quite work, so more intelligence
        # may be needed here, possibly sending a real bool and flipping the
        # placeholder value, and seeing if the LLM inference flipping coincides
        # with the placeholder flip.
        return f"missing_bool_{missing_value_int}"
    elif value_type is dict:
        return {"missing_info": missing_value_int}
    elif value_type is float:
        return float(f"2.{missing_value_int}")
    elif value_type is int:
        return missing_value_int
    elif value_type is list:
        return [missing_value_int, "missing_info"]
    elif value_type is str:
        return f"xx{missing_value_int}_missing_info"
    elif value_type is tuple:
        return (missing_value_int, "missing_info")
    else:
        raise ValueError(f"Invalid type: {type_str} , {value_type}")


###############################################################################
# Nodes
###############################################################################


def _inference_node(state: ToolCallingState) -> dict[str, Any]:
    tool_calling_log = logging.getLogger(Logging.TOOL_CALLING)
    inference_model = gin.gen.config.get_model_def(state["conf"])
    tool_calling_log.debug(
        "Inferencing with model: %s and input: %s and context: %s",
        inference_model,
        state["user_input"] + state["issues"],
        state["context"],
    )
    # Get our LLM for inferencing
    llm = get_llm_on_platform(inference_model)

    # Get the prompt template for the LLM
    prompt_template = gin.gen.models.get_prompt_template(inference_model)

    # Get the prompt template that describes API calls. This will be inserted
    # into the main prompt template for the LLM.
    document_prompt_template = gin.gen.models.get_document_prompt_template(
        inference_model
    )

    # This sets up the chain for the LLM. Each Document provided in the state
    # context will have information from the 'metadata' field of the Document
    # used as part of the 'context' variable to the prompt template, and
    # these will be separated by newlines, which is specific how the Granite
    # Unified API model wants to receive this content. The document separator
    # may be specific to each LLM, so we should update this if needed.
    document_chain = create_stuff_documents_chain(
        llm,
        prompt_template,
        document_prompt=document_prompt_template,
        document_separator="\n",
    )

    prompt_value = {
        "context": state["context"],
        "input": state["user_input"] + state["issues"],
    }
    raw_response = document_chain.invoke(prompt_value)
    tool_calling_log.debug("Raw LLM response: %s", raw_response)
    api_calls = gin.gen.models.prep(inference_model, raw_response)
    tool_calling_log.debug("API calls from prep: %s", api_calls)
    for api_call in api_calls:
        tool_calling_log.info(
            "LLM: %s parameters: %s", api_call.name, api_call.parameters
        )
    if state["iter_count"] == 0:  # the first iteration is for generation
        return {
            "api_calls": api_calls,
            "iter_count": state["iter_count"] + 1,
            "static_api_calls": copy.deepcopy(api_calls),
            "LLM_api_calls": copy.deepcopy(api_calls),
        }
    #  the other iterations are for regeneration based on the static checks
    return {
        "static_api_calls": api_calls,
        "iter_count": state["iter_count"] + 1,
    }


def _static_evaluate_node(state: ToolCallingState) -> dict[str, Any]:
    """
    Perform static checks of each API call.

    This is a passive step that performs no corrective actions, but keeps note
    of any issues in each call's ApiCallInf object
    """
    if not state["conf"].generation.features.static_checks:
        return state
    api_calls = state["static_api_calls"]
    context = state["context"]
    static_issues = gin.gen.eval.evaluate_call_list(
        api_calls=api_calls,
        context=context,
        missing_value_int=state["missing_value_int"],
    )
    return {
        "context": context,
        "static_issues": static_issues,
    }


def _modify_prompt_query_node(state: ToolCallingState) -> dict[str, Any]:
    """Modify prompt query by appending content based on issues found in prior
    inference."""
    workflow_log = logging.getLogger(Logging.AGENTIC_WORKFLOW)
    if not state["conf"].generation.features.static_checks:
        return state
    static_issues = state["static_issues"]
    issues = []
    for i, static_issue in enumerate(static_issues):
        if static_issue.syntax_error:
            issues.append(
                f"Note that the function call {
                    static_issue.api_call.raw_str} has invalid syntax."
            )
            workflow_log.info(issues[-1])
        if static_issue.call_hallucinated:
            issues.append(
                f"Note that {
                    static_issue.api_call.name} is not a valid API call. "
                f"You must choose from the provided function calls library."
            )
            workflow_log.info(issues[-1])
        if static_issue.param_hallucinated:
            issues.append(
                f"Note that the parameters {
                    static_issue.param_hallucinated} "
                f"are not valid for the API call {static_issue.api_call.name}."
            )
            workflow_log.info(issues[-1])
        for param in static_issue.param_mistyped:
            tool_details = get_details_for_call(
                static_issue.api_call.name, state["context"]
            )
            if "type" in param:
                issues.append(
                    f"Note that the parameter '{param}' is of type "
                    f"{tool_details.parameters[param]["type"]}."
                )
                workflow_log.info(issues[-1])

        for param in static_issue.param_outside_bounds:
            tool_details = get_details_for_call(
                static_issue.api_call.name, state["context"]
            )
            if "enum" in param:
                issues.append(
                    f"Note that the parameter '{param}' allowed values are "
                    f"{tool_details.parameters[param]["enum"]}."
                )
                workflow_log.info(issues[-1])
        for param in static_issue.param_missing:
            tool_details = get_details_for_call(
                static_issue.api_call.name, state["context"]
            )
            # Create a placeholder value for missing information
            if "type" in tool_details.parameters[param]:
                missing_value = _get_missing_info_value(
                    tool_details.parameters[param]["type"],
                    state["missing_value_int"],
                )
            else:
                missing_value = _get_missing_info_value(
                    "string", state["missing_value_int"]
                )
            issues.append(
                f"Include the required parameter {param} "
                f"for API call {
                    static_issue.api_call.name}, but use the value "
                f"""'{missing_value}'"""
                f" if there is not enough information to "
                f"provide an appropriate value."
            )
            workflow_log.info(issues[-1])
        if static_issue.blank_substring:
            issues.append(
                "Remove the blank substring in the function call's arguments."
            )
            workflow_log.info(issues[-1])
        if static_issue.invalid_pair:
            issues.append(
                f"The parameters {static_issue.invalid_pair} "
                f"are not valid key-value pairs for API call {
                    static_issue.api_call.name}."
            )
            workflow_log.info(issues[-1])
        if static_issue.repeated_arg:
            issues.append(
                f"Make sure not to repeat the parameters {
                    static_issue.repeated_arg} "
                f"for API call {static_issue.api_call.name}."
            )
            workflow_log.info(issues[-1])
        if static_issue.invalid_value:
            issues.append(
                f"'{static_issue.invalid_value}' is an invalid parameter "
                f"for API call {static_issue.api_call.name}."
            )
            workflow_log.info(issues[-1])

    # If issues is blank we shouldn't have ended up at this node, but we'll
    # harmlessly return a blank issues string if we do.
    issues_str = ""
    if issues:
        issues_str = "\n" + " ".join(issues)

    return {
        "issues": issues_str,
    }


def _llm_evaluate_node(state: ToolCallingState) -> dict[str, Any]:
    """Evaluate the generated API calls using the LLM reflector API."""
    if not state["conf"].generation.features.llm_eval:
        return state

    evaluation_model = gin.gen.config.get_model_def(
        state["conf"], ModelPurpose.EVAL
    )

    # Call the reflector API with the list of available APIs, the user query, and the generated API calls to validate.
    # The output will be a ReflectionResult object that contains the feedback from the reflector API.
    # Import the reflector API and the output classes and enums (from llm_reasoning_judge/function_call_eval/output_schema.py)
    from gin.gen.util.llm_reasoning_judge_interface import (
        api_calls_LLM_reflector,
    )

    fc_reflector_output_json = api_calls_LLM_reflector(
        api_specs_user_request_api_calls=(
            "API Specification: "
            + "\n".join(
                [f"{api_spec.metadata}" for api_spec in state["context"]]
            ),
            state["user_input"],
            [api_call.raw_str for api_call in state["static_api_calls"]],
        ),
        logs_dir="fc_reflector_logs",
        parallel_eval_model_id=evaluation_model.model_id,
        cot_generator_model_id=evaluation_model.model_id,
        judge_model_id=evaluation_model.model_id,
        transformation_agent_model_id=evaluation_model.model_id,
        num_parallel=10,
        parallel_api_calls_judge=True,
        extra_judge=False,
        check_transformations=True,
        platform="rits",
    )
    fc_reflector_output_dict = json.loads(fc_reflector_output_json)
    fc_reflector_output = ReflectionResult(**fc_reflector_output_dict)

    return {
        "feedback": fc_reflector_output,
        "iter_count": state["iter_count"] + 1,
    }


def _regenerate_node(state: ToolCallingState) -> dict:
    """Modify state based on LLM feedback before performing inference."""
    if not state["conf"].generation.features.llm_eval:
        return state

    evaluation_model = gin.gen.config.get_model_def(
        state["conf"], ModelPurpose.EVAL
    )
    api_calls = copy.deepcopy(state["static_api_calls"])
    feedback = state["feedback"]

    # If the feedback is None, not valid, correct, or there are no API calls, return the same state without any changes to the API calls.
    if (
        feedback is None
        or not feedback.valid_llm_response
        or feedback.is_correct
        or not api_calls
    ):
        return {
            "iter_count": state["iter_count"] + 1,
            "LLM_api_calls": api_calls,
        }

    # If the feedback contains an alternative list of API calls, return the alternative list of API calls.
    if (
        feedback.alternative_list_of_api_calls
        and feedback.alternative_list_of_api_calls.alternative_value
    ):
        api_calls = gin.gen.models.prep(
            evaluation_model,
            "\n".join(
                feedback.alternative_list_of_api_calls.alternative_value
            ),
        )
        return {"LLM_api_calls": api_calls}

    # Check if the feedback contains any issues in the API calls. If so, correct the issues in the API calls.
    if feedback.api_calls_results:

        # Iterate through the API calls in the feedback and correct the issues in the API calls.
        for i, api_call_result in enumerate(feedback.api_calls_results):

            # Check if the API call is not valid and contains issues.
            if not api_call_result.is_valid and api_call_result.issues:

                # Iterate through the issues in the API call and correct the issues.
                for issue in api_call_result.issues:

                    # Check if the issue is a wrong API selection mistake type. If so, correct the API call using the alternative API call.
                    if issue.mistake_type == MistakeType.WRONG_API_SELECTION:
                        api_calls[i] = gin.gen.models.prep(
                            evaluation_model, issue.alternative_value
                        )[0]

                    # Check if the issue is a wrong units transformation mistake type. If so, correct the transformation using the alternative value.
                    elif (
                        issue.mistake_type
                        == MistakeType.WRONG_UNITS_TRANSFORMATION
                    ):

                        # Check if the alternative type is in the SPEC_TYPES dictionary. If so, correct the parameter using the alternative type
                        # (or str if the alternative type is not in the SPEC_TYPES dictionary) and the alternative value.
                        if issue.alternative_type in SPEC_TYPES:
                            api_calls[i].parameters[issue.entity_name] = (
                                SPEC_TYPES[issue.alternative_type](
                                    issue.alternative_value
                                )
                            )
                        else:
                            api_calls[i].parameters[
                                issue.entity_name
                            ] = issue.alternative_value
                    elif (
                        issue.mistake_type == MistakeType.WRONG_PARAMETER_VALUE
                    ):

                        # Check if the alternative type is in the SPEC_TYPES dictionary. If so, correct the parameter using the alternative type
                        # (or str if the alternative type is not in the SPEC_TYPES dictionary) and the alternative value.
                        if issue.alternative_type in SPEC_TYPES:
                            api_calls[i].parameters[issue.entity_name] = (
                                SPEC_TYPES[issue.alternative_type](
                                    issue.alternative_value
                                )
                            )
                        else:
                            api_calls[i].parameters[
                                issue.entity_name
                            ] = issue.alternative_value

    return {"LLM_api_calls": api_calls}


###############################################################################
# Conditional edge functions
###############################################################################


def _determine_node_after_static_eval(state: ToolCallingState) -> str:
    """
    Determines the next step after static evaluation.

    Args:
        state (ToolCallingState): The current graph state.

    Returns:
        str: Next node or step to proceed with.
    """
    workflow_log = logging.getLogger(Logging.AGENTIC_WORKFLOW)
    if not state["conf"].generation.features.static_checks:
        workflow_log.info("--- CONDITIONAL: Static checks disabled ---")
        return "pass"
    static_issues = state["static_issues"]
    # Flag if any API call has issues
    has_issues = False
    for static_issue in static_issues:
        if not static_issue.has_issues():
            continue
        has_issues = True

        if static_issue.none_func:
            workflow_log.info("--- CONDITIONAL: Cannot identify function ---")
            workflow_log.error(
                "Cannot identify function to call. Query lacks details or "
                "cannot be fulfilled with available functions, please try to "
                "rephrase your query."
            )
            return "none_func"

        if static_issue.param_missing_info:
            workflow_log.info("--- CONDITIONAL: Missing information ---")
            workflow_log.error(
                "Query lacks details to fill parameters: %s",
                static_issue.param_missing_info,
            )
            # Get document for this API call, and print out information on each
            # parameter that is missing.
            tool_details = get_details_for_call(
                static_issue.api_call.name, state["context"]
            )
            ref_params = tool_details.parameters
            for param in static_issue.param_missing_info:
                workflow_log.error(
                    'Documentation on parameter "%s":\n%s',
                    param,
                    json.dumps(ref_params[param], indent=2),
                )
            return "missing_info"

    if not has_issues:
        workflow_log.info("--- CONDITIONAL: Static checks OK ---")
        return "static_checks_ok"
    workflow_log.info("--- CONDITIONAL: Static checks found issues ---")

    iter_count = state["iter_count"]
    max_iter = state["conf"].generation.max_iter
    if iter_count >= max_iter:
        workflow_log.info(
            "--- CONDITIONAL: Iteration limit reached: %d ---", max_iter
        )
        return "max_iter"
    workflow_log.info(
        "--- CONDITIONAL: Correct issues (iteration %d of %d) ---",
        iter_count + 1,
        max_iter,
    )
    return "static_checks_not_ok"


def _determine_node_after_llm_eval(state: ToolCallingState) -> str:
    """
    Determines the next step after LLM evaluation.

    Args:
        state (ToolCallingState): The current graph state.

    Returns:
        str: Next node or step to proceed with.
    """
    workflow_log = logging.getLogger(Logging.AGENTIC_WORKFLOW)
    if not state["conf"].generation.features.llm_eval:
        workflow_log.info("--- CONDITIONAL: LLM evaluation disabled ---")
        return "pass"

    if state["feedback"] is not None:
        feedback: ReflectionResult = state["feedback"]
        if not feedback.valid_llm_response:
            workflow_log.info("--- CONDITIONAL: LLM evaluation failed ---")
            workflow_log.info(
                "LLM evaluation failed: %s", feedback.error_message
            )
            return "llm_eval_no_feedback"
        if feedback.is_correct:
            workflow_log.info("--- CONDITIONAL: LLM evaluation OK ---")
            return "llm_eval_ok"
        if feedback.mistake_types[MistakeType.NEED_MORE_APIS]:
            workflow_log.info(
                "--- CONDITIONAL: LLM evaluation needs more APIs ---"
            )
            workflow_log.info(
                "LLM evaluation needs more APIs: %s",
                feedback.mistake_explanations,
            )
            return "llm_eval_need_more_apis"
        if feedback.mistake_types[MistakeType.NEED_MORE_INFORMATION]:
            workflow_log.info(
                "--- CONDITIONAL: LLM evaluation needs more information ---"
            )
            workflow_log.info(
                "LLM evaluation needs more information: %s",
                feedback.mistake_explanations,
            )
            return "llm_eval_need_more_info"
        workflow_log.info("--- CONDITIONAL: LLM evaluation found issues ---")
    else:
        workflow_log.info("--- CONDITIONAL: LLM evaluation lacks feedback ---")
        return "llm_eval_no_feedback"

    iter_count = state["iter_count"]
    max_iter = state["conf"].generation.max_iter
    if iter_count >= 2 * max_iter:
        workflow_log.info(
            "--- CONDITIONAL: Iteration limit reached: %d ---", max_iter
        )
        return "max_iter"

    workflow_log.info(
        "--- CONDITIONAL: Correct issues (iteration %d of %d) ---",
        iter_count + 1,
        max_iter,
    )
    return "llm_eval_not_ok"


###############################################################################
# Workflow construction and execution
###############################################################################


def apply_tool_calling(
    initial_state: ToolCallingState,
    log_level: str = None,
) -> dict[str, Any] | Any:
    """
    Set up and execute tool-calling agentic workflow.

    Args:
        initial_state (ToolCallingState): Input state to the start of the
            workflow.
        log_level (str): Logging level to set or None to set the default level.

    returns:
        dict[str, Any] | Any: Final state of the workflow.
    """
    # Set log level
    Logging(log_level=log_level)
    tool_calling_log = logging.getLogger(Logging.TOOL_CALLING)

    conf = initial_state["conf"]
    if conf.generation.features.llm_eval:
        tool_calling_log.debug(
            "LLM Evaluation enabled, loading llm_as_judge package",
        )
        load_api()

    builder = StateGraph(ToolCallingState)

    # Add nodes of workflow.
    # This node performs API call generation.
    builder.add_node("inference", _inference_node)
    # This node provides static evaluation, listing issues in each
    # call's ApiCallInf object. No corrective actions are taken here.
    builder.add_node("static_eval", _static_evaluate_node)
    # This node modifies the LLM prompt for API call generation, based on
    # issues found from static evaluation.
    builder.add_node("modify_prompt_query", _modify_prompt_query_node)
    # This node uses an LLM inspector to evaluate the generated API calls
    # for the user's query. Feedback is added to the state, but corrective
    # actions are not taken at this node.
    builder.add_node("llm_eval", _llm_evaluate_node)
    # This node modifies the state based on feedback from LLM evaluation.
    builder.add_node("regenerate", _regenerate_node)

    # Set up edges between nodes
    builder.set_entry_point("inference")
    builder.add_edge("inference", "static_eval")
    builder.add_conditional_edges(
        "static_eval",
        _determine_node_after_static_eval,
        {
            # Static checks are inactive
            "pass": "llm_eval",
            # No issues found during static checks.
            "static_checks_ok": "llm_eval",
            # Not enough information in user query.
            "missing_info": END,
            # No supplied function can fulfill the user's request.
            "none_func": END,
            # Some other issue was found, but we've reached the iteration
            # limit.
            "max_iter": "llm_eval",
            # Some other issue was found, and we will modify the user query
            # in an attempt to correct this.
            "static_checks_not_ok": "modify_prompt_query",
        },
    )
    builder.add_edge("modify_prompt_query", "inference")
    builder.add_conditional_edges(
        "llm_eval",
        _determine_node_after_llm_eval,
        {
            # LLM evaluation is inactive
            "pass": END,
            # LLM evaluation gives the OK.
            "llm_eval_ok": END,
            # Issues found during LLM evaluation.
            "llm_eval_not_ok": "regenerate",
            # LLM evaluation needs more APIs.
            # TODO: Add another iteration with larger top_k RAG value.
            "llm_eval_need_more_apis": END,
            # LLM evaluation needs more information.
            "llm_eval_need_more_info": END,
            # LLM evaluation provided no feedback.
            "llm_eval_no_feedback": END,
            # Issues found, but we've reached the iteration limit.
            "max_iter": "regenerate",
        },
    )

    # Compile and execute the workflow
    graph = builder.compile()
    final_state = graph.invoke(initial_state)
    tool_calling_log.debug(
        "Final apis: api_calls - %s static_api_calls - %s LLM_api_calls -  %s",
        final_state["api_calls"],
        final_state["static_api_calls"],
        final_state["LLM_api_calls"],
    )

    return final_state


def simple_tool_calling(
    functions: list,
    query: str,
    config_file: str = None,
    config_dict: dict = None,
    log_level: str = None,
) -> dict:
    """
    Perform function calling for the given query using the provided list of functions.

    Args:
        config_file (str): Path to GIN configuration file.
        config_dict (dict): Dict of GIN configuration, in case both are given, config_file will be used.
        functions (list): A list of function. Each function is represented as a dictionary,
            described as follows:
            {
                "name" -required: "function name",
                "parameters": {
                    "parameter-name": {
                        "type" -required: data type given as a string,
                        "description" -required: The parameter description, given as a string,
                        "location" -optional: "QUERY" or "HEADER" or "PATH" or "COOKIE"
                        "default" -optional: A default value if not specified, type can be any,
                        "enum" -optional: Allowed values for enumerated types, type can be any,
                    }
                    "required" -required :list of required parameters.
                }
                "description" -required: "function description",
                "api_type" -required: "REST" or "FUNCTION"
                "call_meta": optional {
                    "endpoint": URL endpoint (without servername) for call given as string,
                    "method": HTTP method to use, one of "GET", "POST", "DELETE", or "PUT"
                    "auth_type": [ auth methods ]
                    "output_schema": Dictionary of the output schema,
                    "servers": as set of server addresses given as a list
                    }
           }
           For each function the `name`, `description` and `required` are required.
           For each parameter the `type` and `description` are required.
        query (str): User query.
        log_level (str): Logging level to set or None to set the default level.

    Returns:
        dict: Final state of workflow

    Exceptions:
        KeyError - when a required parameter
        ValueError - If neither config_file nor config_dict are given,
          or when the dict can't be casted to BaseConfig
    """

    # Set log level
    Logging(log_level=log_level)
    tool_calling_log = logging.getLogger(Logging.TOOL_CALLING)

    conf = None
    if config_file is not None:
        conf = gin.gen.config.import_config(config_file)
    else:
        if config_dict is None:
            raise ValueError(
                "Either config_file or config_dict must be provided."
            )
        try:
            conf = BaseConfig(**config_dict)
        except ValidationError as err:
            tool_calling_log.error("Error: %s", err)
            raise ValueError("config_dict must be valid.")

    tool_list = []

    context: list[Document] = []
    for func in functions:
        tool_details = ToolDetails(**func)
        tool_list.append(tool_details)
        doc = Document(
            page_content=tool_to_semantic_description(tool_details),
            metadata={"tool_details_str": tool_details.model_dump_json()},
        )
        context.append(doc)

    state = {
        "conf": conf,
        "user_input": query,
        "issues": "",
        "missing_value_int": gin.gen.util.get_missing_value_int(query),
        "context": context,
        "api_calls": [],
        "static_api_calls": [],
        "LLM_api_calls": [],
        "iter_count": 0,
        "feedback": None,
        "static_issues": None,
    }

    return apply_tool_calling(state)
