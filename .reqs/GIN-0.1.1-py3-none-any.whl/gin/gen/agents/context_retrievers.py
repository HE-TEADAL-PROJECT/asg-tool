import logging
from typing import List
from langchain.retrievers import ContextualCompressionRetriever
from langchain_core.documents import Document

from gin.gen.retrieval import vectorstore_loader
from gin.gen.retrieval.retriever_with_scores import (
    VectorStoreRetrieverWithScores,
)
from gin.common.logging import Logging
from gin.common.types import ToolDetails
import gin.gen.retrieval.reranker as reranker
from gin.common.ai_platforms import get_llm_on_platform
from gin.common.types import PlatformCredentials, ModelDef, ModelType
from gin.gen.config import BaseConfig


def retrieve_tools_from_catalog(
    query: str, conf: BaseConfig, tools: List[ToolDetails], title: str
) -> List[Document]:
    """
    Retrieve the documents relevant to the given query.

    Args:
        query (str): User query.
        conf (BaseConfig): GIN config.
        tools (List[ToolDetails]): List of the given tools (only needed for
            ephemeral VS).
        title (str): Unique ID for the particular application (only needed for
            ephemeral VS).

    Returns:
        List[Document]: List of the retrieved relevant documents.
    """
    base_log = logging.getLogger(Logging.BASE)
    # Get API retriever
    if not conf.generation.retrieval.persistent_vector_store_dir:
        base_log.info("Ephemeral vector store used")
        retriever = vectorstore_loader.load_get_vs_ephemeral_langchain(
            conf, tools, title
        )
    else:
        # Persistent VS - loading the already populated VS(offline with flow1).
        base_log.info("Persistent vector store used")
        retriever = vectorstore_loader.get_loaded_vs(conf)

    top_k = conf.generation.retrieval.top_k
    retriever_with_scores = VectorStoreRetrieverWithScores.from_vector_store(
        retriever.vectorstore, search_kwargs={"k": top_k}
    )
    if conf.generation.retrieval.rerank is not None:
        rerank_model_shortname = conf.generation.retrieval.rerank.model
        logging.debug(
            "Using reranking with model: %s\n", rerank_model_shortname
        )
        base_log.debug(
            "rerank top_n: %d", conf.generation.retrieval.rerank.top_n
        )
        model_host = conf.models[rerank_model_shortname].host
        parameters = conf.models[rerank_model_shortname].parameters

        if "return_options" not in parameters:
            parameters["return_options"] = {}
        parameters["return_options"]["top_n"] = top_k

        reranker_model_def = ModelDef(
            model_id=conf.models[rerank_model_shortname].id,
            credentials=PlatformCredentials(
                api_base=conf.ai_platforms[model_host].credentials.api_base,
                api_key=conf.ai_platforms[
                    model_host
                ].credentials.api_key.get_secret_value(),
                api_project_id=conf.ai_platforms[
                    model_host
                ].credentials.api_project_id,
            ),
            platform=conf.ai_platforms[model_host].platform,
            model_type=ModelType.EMBEDDINGS,
            model_params=parameters,
        )

        reranker_model = get_llm_on_platform(reranker_model_def)
        base_log.debug("top_k: %d", conf.generation.retrieval.top_k)
        compressor = reranker.RerankModel(reranker_model=reranker_model)
        compression_retriever = ContextualCompressionRetriever(
            base_compressor=compressor, base_retriever=retriever_with_scores
        )
        # This will retrieve the context with documents re-ranking
        retriever = compression_retriever

    else:
        # This will retrieve the context without documents re-ranking
        retriever = retriever_with_scores

    base_log.info("User: %s", query)

    # Perform documents retrieval with the user's query
    context = retriever.invoke(query)
    base_log.debug("Retrieval returned context: %s", context)
    return context
