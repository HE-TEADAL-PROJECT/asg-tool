from typing import Dict, Any, List, Optional
from pydantic import BaseModel
from enum import Enum


class MistakeType(Enum):
    """
    Enumeration of possible types of mistakes in API calls.
    - WRONG_NUMBER_OF_APIS: The number of API calls is incorrect (e.g., missing or redundant API calls).
    - NEED_MORE_APIS: Additional API calls are required in the available specification list to fulfill the user request.
    - WRONG_API_SELECTION: The selected API is incorrect, and an alternative API is suggested.
    - NEED_MORE_INFORMATION: More details are needed to complete a parameter value in an API call.
    - WRONG_PARAMETER_VALUE: The parameter value is incorrect, and an alternative value is suggested.
    - WRONG_UNITS_TRANSFORMATION: Incorrect units transformation in parameter values, and an alternative transformed value is suggested.
    """

    WRONG_NUMBER_OF_APIS = "wrong number of APIs"
    NEED_MORE_APIS = "need more APIs"
    WRONG_API_SELECTION = "wrong API selection"
    NEED_MORE_INFORMATION = "need more information"
    WRONG_PARAMETER_VALUE = "wrong parameter value"
    WRONG_UNITS_TRANSFORMATION = "wrong units transformation"


class EntityType(Enum):
    """
    Enumeration of the type of entity associated with a mistake.
    - LIST_OF_API_CALLS: Refers to a list of API calls.
    - API_CALL: Refers to a single API call.
    - PARAMETER: Refers to a parameter within an API call.
    """

    LIST_OF_API_CALLS = "list of API calls"
    API_CALL = "API call"
    PARAMETER = "parameter"


class Mistake(BaseModel):
    """
    Represents a general mistake in API calls or parameters.
    Attributes:
        mistake_type (MistakeType): The type of mistake (e.g., wrong API selection).
        entity_type (EntityType): The type of entity associated with the mistake (e.g., API call or parameter).
        entity_name (Optional[str]): The name of the entity associated with the mistake (e.g., API name or parameter name).
        explanation (Optional[str]): A detailed explanation of the mistake.
        alternative_value (Optional[Any]): Suggested alternative value for fixing the mistake.
        alternative_type (Optional[Any]): Suggested type or format for the alternative value.
        extra_info (Optional[Dict[str, Any]]): Additional information or metadata about the mistake.
    """

    mistake_type: MistakeType
    entity_type: EntityType
    entity_name: Optional[str] = None
    explanation: Optional[str] = None
    alternative_value: Optional[Any] = None
    alternative_type: Optional[Any] = None
    extra_info: Optional[Dict[str, Any]] = None


class APICallResult(BaseModel):
    """
    Represents the result of validating an individual API call.
    Attributes:
        api_call (str): The API call being validated.
        is_valid (bool): Whether the API call is valid or not.
        issues (Optional[List[Mistake]]):
            - A single mistake, if the issue relates to the entire API call (e.g., wrong API selection).
            - A list of mistakes, if multiple parameter issues exist.
            - None, if the API call is valid.
        alternative_api_call (Optional[str]): Only for parameter issues with the same API function. Suggested alternative API call without unit transformation mistakes.
    """

    api_call: str
    is_valid: bool
    issues: Optional[List[Mistake]] = None
    alternative_api_call: Optional[str] = None


class ReflectionResult(BaseModel):
    """
    Represents the overall validation result for a set of API calls.
    Attributes:
        list_of_api_calls (Optional[List[str], str]):
            - A list of API calls if multiple calls are being validated.
            - A list of API calls in a single string format, if provided.
            - None, if no calls are provided.
        is_correct (bool): Whether the entire list of API calls is correct based on the user request.
        valid_llm_response (bool): Whether the LLM model provided a valid response for the validation task.
        error_message (Optional[str]): A message describing the error that occurred.
        api_calls_results (Optional[List[APICallResult]]): A list of results for each API call in the list.
        alternative_list_of_api_calls (Optional[Mistake]): An alternative list of API calls if the original list is incorrect (e.g., wrong number of APIs).
        mistake_types (Optional[Dict[MistakeType, bool]]): A dictionary of mistake types and their presence in the validation results.
        mistake_explanations (Optional[str]): A detailed explanation of the mistakes in the API calls (for wrong number of APIs or need more APIs or need more information).
    """

    list_of_api_calls: Optional[List[str]] = None
    is_correct: bool
    valid_llm_response: bool
    error_message: Optional[str] = None
    api_calls_results: Optional[List[APICallResult]] = None
    alternative_list_of_api_calls: Optional[Mistake] = None
    mistake_types: Optional[Dict[MistakeType, bool]] = None
    mistake_explanations: Optional[str] = None
