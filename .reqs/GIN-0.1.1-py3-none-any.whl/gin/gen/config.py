"""Application configuration."""

import json
import logging
from typing import Dict, List, Optional
import yaml
from pydantic import (
    BaseModel,
    ConfigDict,
    SecretStr,
    Field,
    ValidationError,
    field_validator,
    ValidationInfo,
)
from varsubst import varsubst, exceptions

from gin.common.types import ModelPurpose, Platform
from gin.common.logging import Logging
from gin.common.types import ModelDef, PlatformCredentials, ModelType


class AIPlatformCredentials(BaseModel):
    """Credentials for accessing model platforms."""

    api_key: SecretStr
    api_base: Optional[str] = Field(
        None, description="API endpoint for model platform."
    )
    api_project_id: Optional[str] = Field(
        None, description="Project ID for model platform."
    )


class AIPlatformConfig(BaseModel):
    """API hosting platform configuration details."""

    platform: Platform
    """Hosting platform to use."""

    credentials: AIPlatformCredentials
    """Credentials for accessing the hosting platform."""


class AIModelConfig(BaseModel):
    """AI model parameters."""

    id: str
    """Model ID."""

    host: str
    """Host for model."""

    parameters: dict | None = None
    """Parameters for model."""


class RerankConfig(BaseModel):
    """Rerank configuration parameters."""

    top_n: int = Field(4, gt=0, alias="topN")
    """Number of API matches to retrieve after reranking."""

    model: str
    """Model to use for documents reranking."""


class RetrievalConfig(BaseModel):
    """API retrieval configuration."""

    models: List[str]
    """Encoding models to use for retrieval."""

    top_k: int = Field(5, gt=0, alias="topK")
    """Number of API matches to retrieve."""
    persistent_vector_store_dir: Optional[str] = Field(
        default=None, alias="persistentVectorStoreDir"
    )
    """Directory to keep vector store information persistent."""

    rerank: Optional[RerankConfig] = Field(default=None)
    """Rerank configuration. Skip to disable reranking."""

    @field_validator("rerank")
    def validate_rerank_top_n(cls, rerank: RerankConfig, info: ValidationInfo):
        base_log = logging.getLogger(Logging.BASE)
        if info.data["top_k"] <= 5:
            base_log.debug(
                "topK = %s, increasing to 6 due to use of reranking.",
                info.data["top_k"],
            )
            info.data["top_k"] = 6
        if info.data["top_k"] < rerank.top_n:
            raise ValueError("rerank topN should be less than topK")
        return rerank


class Features(BaseModel):
    """Features to utilize during API call generation."""

    rag: bool = False
    """Utilize RAG to downselect calls from OpenAPI specification."""

    static_checks: bool = Field(alias="staticChecks", default=True)
    """Perform static checks on generated API calls."""

    llm_eval: bool = Field(alias="llmEval", default=False)
    """Utilize an LLM evaluator to inspect generated API calls."""


class EvaluationConfig(BaseModel):
    """Configuration for LLM evaluation of generated API calls."""

    models: List[str]
    """Encoding models to use for evaluation."""


class GenerationConfig(BaseModel):
    """API call generation configuration."""

    models: List[str]
    """Encoding models to use for generation."""

    max_iter: int = Field(alias="maxIter")
    """Maximum number of inference iterations before failing."""

    override: Dict[str, dict] | None = None
    """Connector parameter or call overrides."""

    retry_method: Dict[str, list] | None = Field(
        default=None, alias="retryMethod"
    )
    """How to regenerate a failed connector."""

    features: Features = Features()  # Default values
    """Features to utilize during generation."""

    retrieval: Optional[RetrievalConfig] = None
    """API retrieval configuration."""

    evaluation: Optional[EvaluationConfig] = None
    """API call evaluation configuration."""


class BaseConfig(BaseModel):
    """Automatic Code Generation configuration."""

    model_config = ConfigDict(
        title="GIN Configuration",
        validate_assignment=True,
        validate_default=True,
        use_attribute_docstrings=True,
    )

    ai_platforms: Dict[str, AIPlatformConfig] = Field(alias="aiPlatforms")
    """Model hosting platforms"""

    models: Dict[str, AIModelConfig]
    """AI model configuration."""

    generation: GenerationConfig
    """API call generation configuration."""


def import_config(conf_file_path: str, log_level: str = None) -> BaseConfig:
    """
    Import configuration file.

    Args:
        conf_file_path (str): Path to configuration file.
        log_level (str): Logging level to set or None to set the default level.

    Returns:
        BaseConfig: Application configuration.
    """
    # Set log level
    Logging(log_level=log_level)

    base_log = logging.getLogger(Logging.BASE)
    base_log.debug("Loading GIN configuration file: %s", conf_file_path)
    try:
        conf = None
        with open(conf_file_path, "r", encoding="UTF-8") as file:
            conf_dict = yaml.safe_load(file)
        conf = BaseConfig(**conf_dict)
    except ValidationError as err:
        base_log.error(
            "Validation error loading config file: %s", conf_file_path
        )
        base_log.error("Error: %s", err)
    except FileNotFoundError:
        base_log.error("Configuration file not found: %s", conf_file_path)
    return conf


def export_config(config: BaseConfig, conf_file_path: str) -> None:
    """
    Export configuration file.

    Args:
        config (BaseConfig): Application configuration.
        conf_file_path (str): Path to configuration file.
    """
    with open(conf_file_path, "w", encoding="UTF-8") as file:
        yaml.dump(config.model_dump(), file)


def make_config_json_schema() -> str:
    """
    Create a JSON Schema for the application configuration.

    Returns:
        str: JSON Schema of application configuration.
    """
    return json.dumps(BaseConfig.model_json_schema(), indent=2)


def resolve_env_references(obj: BaseModel):
    """
    lookup environment references in SecretStr variables in the class instance
    For any SecretStr which holds a reference to an environment variable (i.e., ${foo})
    try to substitute the reference with the value from the environment.

    Args:
        obj (BaseModel): the object to update
    """
    fields = obj.model_fields_set
    for fieldname in fields:
        field = getattr(obj, fieldname)
        if isinstance(field, SecretStr):
            try:
                field_value = field.get_secret_value()
                new_value = SecretStr(varsubst(field_value))
                setattr(obj, fieldname, new_value)
            except AttributeError:
                # The attribute referred in 'fieldname' is not define in the
                # configuration class instance, skipping.
                pass
            except exceptions.KeyUnresolvedException:
                # The environment variable that was referred in the
                # configuration is not defined, skipping.
                pass


def get_model_def(
    conf: BaseConfig, model_use: ModelPurpose = ModelPurpose.API_GEN
):
    """
    Get LLM definition instance, describing what model to use and how to use it.

    Args:
       config (BaseConfig): Application configuration.
       model_use (ModelPurpose): Enumeration to indicate the purpose of the model.

    Returns:
       model_def (ModelDef): Model to create an instance of.
    """
    base_log = logging.getLogger(Logging.BASE)
    if model_use == ModelPurpose.EVAL:
        # This model is used for generated call evaluation
        model_shortname = conf.generation.evaluation.models[0]
    elif model_use == ModelPurpose.API_GEN:
        # Model is used for API call generation
        model_shortname = conf.generation.models[0]
    else:
        base_log.error("Enumeration not supported: %s", str(model_use))
        return None

    model_host = conf.models[model_shortname].host
    inference_model = ModelDef(
        model_id=conf.models[model_shortname].id,
        credentials=PlatformCredentials(
            api_base=conf.ai_platforms[model_host].credentials.api_base,
            api_key=conf.ai_platforms[
                model_host
            ].credentials.api_key.get_secret_value(),
            api_project_id=conf.ai_platforms[
                model_host
            ].credentials.api_project_id,
        ),
        model_type=ModelType.LLM,
        platform=conf.ai_platforms[model_host].platform,
        model_params=conf.models[model_shortname].parameters,
    )
    return inference_model
