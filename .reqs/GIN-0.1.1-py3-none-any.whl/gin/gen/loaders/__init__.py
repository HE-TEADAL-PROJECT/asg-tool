"""
Custom document loaders for LangChain.
"""

import logging
import copy
from typing import Iterator
from langchain_core.documents import Document
from langchain_core.document_loaders import BaseLoader

from gin.gen.importers.openapi import (
    check_for_endpoint_method,
    extract_security_for_path,
    extract_server_for_path,
)
from gin.common.types import ToolDetails, HTTPMethod, AuthType
from gin.common.logging import Logging
from gin.gen.util import ref_resolver
from gin.gen.types import ApiSpec


class ToolDocumentLoader(BaseLoader):
    """
    Loader for Tool Calling.
    """

    def __init__(self, tools: list[ToolDetails], title: str) -> None:
        """
        Initialize loader.

        Args:
            tools (list[ToolDetails]): List of tool details.
            title (str): Unique ID for the application or tools set.
        """
        self.tools = tools
        self.title = title

    def lazy_load(self) -> Iterator[Document]:
        """
        A lazy loader that reads the tools one by one.
        """
        for tool_details in self.tools:
            yield Document(
                page_content=tool_to_semantic_description(tool_details),
                metadata={"tool_details_str": tool_details.model_dump_json()},
            )


def openapi_to_tool_list(spec: ApiSpec) -> list[ToolDetails]:
    """
    Make a list of ToolDetails objects for the endpoints/methods in an
    OpenAPI specification.

    Args:
        spec (ApiSpec): OpenAPI v3 specification.

    Returns:
        list[ToolDetails]: List of API call details.
    """
    tool_list = []
    for endpoint in spec["paths"]:
        for method in spec["paths"][endpoint]:
            if method not in HTTPMethod:
                # Unsupported method
                continue
            tool_details = openapi_endpoint_to_tool_details(
                spec, endpoint, method
            )
            tool_list.append(tool_details)
    return tool_list


def openapi_endpoint_to_tool_details(
    spec: ApiSpec, endpoint: str, method: str
) -> ToolDetails:
    """
    Make description of API call from OpenAPI spec endpoint and method.

    Args:
        spec (ApiSpec): OpenAPI v3 specification.
        endpoint (str): Endpoint to use.
        method (str): Request method of endpoint to use.

    Returns:
        ToolDetails: Function call details.
    """
    base_log = logging.getLogger(Logging.BASE)

    check_for_endpoint_method(spec, endpoint, method)

    # Start building tool_details_dict, which will ultimately get converted
    # to a ToolDetails object.
    tool_details_dict = {
        "api_type": "rest",
        "call_meta": {"method": method, "endpoint": endpoint},
    }

    # Use the operationId as a dummy function name for the REST call if
    # available (the OpenAPI specification doesn't require it, but if provided
    # it must be unique), otherwise create a (potentially long) function name
    # from the method and endpoint.
    if "operationId" in spec["paths"][endpoint][method]:
        tool_details_dict["name"] = spec["paths"][endpoint][method][
            "operationId"
        ]
    else:
        tool_details_dict["name"] = (
            method
            + "."
            + endpoint.replace("/", ".").replace("{", "").replace("}", "")
        )

    # Get parameters for endpoint and the specific method used.
    if (
        "parameters" in spec["paths"][endpoint][method]
        or "parameters" in spec["paths"][endpoint]
    ):
        tool_details_dict["parameters"] = _make_params_dict(
            spec, endpoint, method
        )

    # Make a description from summary and description fields in the OpenAPI spec
    summary = ""
    description = ""
    if "summary" in spec["paths"][endpoint][method]:
        summary = spec["paths"][endpoint][method]["summary"]
    if "description" in spec["paths"][endpoint][method]:
        description = spec["paths"][endpoint][method]["description"]
    if summary != "" and summary[-1] != ".":
        # Make sure non-blank summary ends with a period.
        summary += "."
    if description != "" and description[-1] != ".":
        # Make sure non-blank description ends with a period.
        description += "."
    if summary == "" and description == "":
        base_log.warning(
            "paths.%s missing API description and summary.", endpoint
        )
        # We don't have a summary or description, so make one up based on the
        # function call name.
        tool_details_dict["description"] = (
            f"Function call for {tool_details_dict["name"]}."
        )
    else:
        # Combine summary and description into a single description.
        tool_details_dict["description"] = f"{summary} {description}".strip()

    # Get the response schema (if it exists)
    if "responses" in spec["paths"][endpoint][method]:
        tool_details_dict["call_meta"]["output_schema"] = _make_output_dict(
            spec, endpoint, method
        )

    # Get authorization details
    path_security = extract_security_for_path(spec, endpoint, method)
    security_methods = []
    for sec_desc in path_security:
        for sec_name, scopes in sec_desc.items():
            security_scheme = (
                spec.get("components", {})
                .get("securitySchemes", {})
                .get(sec_name, {})
            )
            if (
                security_scheme.get("type") == "http"
                and security_scheme.get("scheme") == "bearer"
            ):
                security_methods.append(
                    {
                        "name": sec_name,
                        "type": AuthType.BEARER,
                        "in": security_scheme.get("in", "header"),
                        "description": security_scheme.get("description", ""),
                        "bearerFormat": security_scheme.get(
                            "bearerFormat", "JWT"
                        ),
                        "scopes": scopes,
                        "scheme": security_scheme.get("scheme", ""),
                    }
                )

            # Handle API Key Authentication
            elif security_scheme.get("type") == "apiKey":
                security_methods.append(
                    {
                        "name": sec_name,
                        "type": AuthType.API_KEY,
                        "description": security_scheme.get("description", ""),
                        "in": security_scheme.get("in", "header"),
                        "name_in_request": security_scheme.get("name", ""),
                        "scopes": scopes,
                        "scheme": security_scheme.get("scheme", ""),
                    }
                )
            else:
                base_log.warning(
                    "paths.%s security type %s is not supported",
                    endpoint,
                    security_scheme.get("type"),
                )

    if path_security == []:
        # Endpoint doesn't need any type of security (publicly accessible)
        security_methods.append(
            {
                "name": "",
                "type": AuthType.NO_AUTH,
                "description": "",
                "in": "",
                "name_in_request": "",
                "scopes": "",
                "scheme": "",
            }
        )
    tool_details_dict["call_meta"]["auth_type"] = security_methods

    # Get servers, if defined
    servers = extract_server_for_path(spec, endpoint, method)
    tool_details_dict["call_meta"]["servers"] = servers

    # base_log.debug("Captured tool details: %s", json.dumps(tool_details_dict, indent=2))
    return ToolDetails(**tool_details_dict)


def _add_params_to_dict(
    spec_params: list[dict], path: str, params_dict: dict
) -> None:
    """
    Add parameters from an OpenAPI spec endpoint or method to provided dict.

    Args:
        spec_params (list): Parameters from OpenAPI specification.
        path (str): Path within the OpenAPI spec the parameters are from, used
            for logging messages.
        params_dict (dict): Dict of parameter details in format matching
            ToolParameterDetails. This dict will be modified by this function.
    """
    req_list = []
    for param in spec_params:
        name = param["name"]
        params_dict[name] = {}

        if "schema" in param:
            # take everything under schema remove examples
            for key in param["schema"]:
                if key != "example":
                    params_dict[name][key] = copy.deepcopy(
                        param["schema"][key]
                    )

        if "required" in param:
            assert isinstance(param["required"], bool)
            if param["required"]:
                req_list.append(name)

        if "description" in param:
            params_dict[name]["description"] = param["description"]
        else:
            # Take the parameter name if we don't have a description
            params_dict[name][
                "description"
            ] = f"Parameter for {param['name']}."

        params_dict[name]["location"] = param["in"]

    params_dict["required"] = req_list


def _make_output_dict(spec: ApiSpec, endpoint: str, method: str) -> dict:
    """
    Make a dict of output schema with their type and descriptions.

    Args:
        spec (ApiSpec): OpenAPI v3 specification.
        endpoint (str): Endpoint to use.
        method (str): Request method of endpoint to use.

    Returns:
        dict: The Flattened output schema.
    """
    output_schema = {}
    responses = (
        spec["paths"].get(endpoint, {}).get(method, {}).get("responses", {})
    )
    http_code = "200" if "200" in responses else "default"
    if http_code in responses:
        content = responses[http_code].get("content", {})
        content_type = None
        if "application/json" in content:
            content_type = "application/json"
        elif "application/json; charset=utf-8" in content:
            content_type = "application/json; charset=utf-8"
        # else:
        # base_log.warning("Only JSON content type is supported: %s %s has %s", method,endpoint,list(content.keys()), )
        if content_type:
            schema = content[content_type].get("schema", {})
            output_schema = ref_resolver.resolve_ref_for_object(spec, schema)
            # if not output_schema:
            # base_log.warning( "Couldn't resolve output schema for: %s %s", method, endpoint,)
    # else:
    # base_log.warning("Supported HTTP codes ['200', 'default'] are not specified: %s %s has %s", method,endpoint, list(responses.keys()),  )
    # base_log.debug("Output schema for %s %s: %s", method, endpoint, output_schema)
    return output_schema


def _make_params_dict(spec: ApiSpec, endpoint: str, method: str) -> dict:
    """
    Make a dict of parameters with their type and descriptions.

    Args:
        spec (ApiSpec): OpenAPI v3 specification.
        endpoint (str): Endpoint to use.
        method (str): Request method of endpoint to use.

    Returns:
        dict: Parameter names and details.
    """
    parameters = {}
    method_params = []
    flatten_method_params = []
    if "parameters" in spec["paths"][endpoint][method]:
        method_params = spec["paths"][endpoint][method]["parameters"]
    path = f"paths.{endpoint}.{method}.parameters"
    for method_param in method_params:
        flatten_method_params.append(
            ref_resolver.resolve_ref_for_object(spec, method_param)
        )
    _add_params_to_dict(flatten_method_params, path, parameters)
    # Check for common parameters that are defined at the endpoint level
    if "parameters" not in spec["paths"][endpoint]:
        # base_log.debug(f"Parameters for endpoint {endpoint} and method {method} are: {parameters}" )
        return parameters
    endpoint_params = spec["paths"][endpoint]["parameters"]
    path = f"paths.{endpoint}.parameters"
    flatten_endpoint_params = []
    for endpoint_param in endpoint_params:
        flatten_endpoint_params.append(
            ref_resolver.resolve_ref_for_object(spec, endpoint_param)
        )
    _add_params_to_dict(flatten_endpoint_params, path, parameters)
    # base_log.debug( f"Parameters for endpoint {endpoint} and method {method} are: {parameters}")
    return parameters


def tool_to_semantic_description(tool_details: ToolDetails) -> str:
    """
    Make a semantic description of a tool, for use with embedding models.

    Args:
        tool_details (ToolDetails): Tool details to describe.

    Returns:
        str: Semantic description of the tool.
    """

    description = tool_details.description

    if tool_details.parameters:
        description += " Has parameters:\n"
    for param in tool_details.parameters:
        if param != "required":
            if "description" in tool_details.parameters[param]:
                description += f"{param}: {tool_details.parameters[param]["description"]}\n"
            else:
                description += f"{param}]n"

    return description
