"""
Offline checking and issue classification of LLM inferences.
"""

import logging
from typing import List

from langchain_core.documents.base import Document

from gin.common.util import get_details_for_call
from gin.gen.types import (
    SPEC_TYPES,
    ApiCallStaticIssues,
)

from gin.common.types import ApiCallInf
from gin.common.logging import Logging


def evaluate_call(
    call: ApiCallInf, context: List[Document], missing_value_int: int
) -> ApiCallStaticIssues:
    """
    Check for issues with inferred call.

    This performs static evaluation of an API call, and add to the call's
    issues, The possible issue keys are:

    - call_hallucinated: The assigned value of True indicates the selected call
        is not in the shortlist of calls provided to the LLM. Further processing will be
        aborted in this case.

    - param_hallucinated: The list assigned to this key contains parameter
        names that were selected by the LLM, but are not valid parameters for
        the chosen API call.

    - param_mistyped: The list assigned to this key contain parameter names
        that are valid for the API call, but the value assigned to the
        parameter by the LLM are not of the type required.

    - param_missing: The list assigned to this key contain parameter names that
        are required for the API call, but were not provided by the LLM.

    - param_missing_info: The list assigned to this key contain parameter names
        that are required for the API call, but were not provided by the query.

    Args:
        call (ApiCallInf): API call from LLM.
        context (list): Contextual documents provided to LLM of available APIs.
        missing_value_int (int): Values that correspond to placeholders for
            missing information in the user query will contain this integer
            somewhere in it, when the value is converted to a string.
     Returns:
      ApiCallStaticIssues: issues in the api call
    """
    issues: ApiCallStaticIssues = ApiCallStaticIssues(api_call=call)

    base_log = logging.getLogger(Logging.BASE)

    base_log.debug("Evaluating call: %s", call)

    # Check that incoming call is of valid format
    if not call.valid:
        issues.syntax_error = True
        base_log.debug("Skipping evaluation of invalid call: %s", call)
        return issues

    # We are not able to identify the USER's intent.
    if call.name == "none":
        issues.none_func = True
        base_log.debug("We are not able to identify the USER's intent.")
        return issues

    # Get Document in context that corresponds to this API call
    tool_details = get_details_for_call(call.name, context)

    # Check that call exists in context
    if not tool_details:
        issues.call_hallucinated = True
        base_log.debug("Call issues: %s", issues)
        return issues

    # Make sure parameters from LLM are valid
    for param, value in call.parameters.items():
        # Check if parameter is part of API call
        if param not in tool_details.parameters:
            issues.param_hallucinated.append(param)
            continue
        # Check if parameter contains a dummy value corresponding to missing
        # information. This check must come before type checking, as we don't
        # care if the type is correct when information is missing.
        # We want to see if our missing_value_int appears anywhere in the
        # string representation of the value, as our int has been verified to
        # not exist in the user's query.
        if str(missing_value_int) in str(value):
            issues.param_missing_info.append(param)
            continue
        # Check that type is correct
        if "type" in tool_details.parameters[param]:
            if not isinstance(
                # TODO this is OpenAPI spec specific, we could have custom type
                # lists based on the API type given in tool_details.api_type
                value,
                SPEC_TYPES[tool_details.parameters[param]["type"].lower()],
            ):
                param_type_name = tool_details.parameters[param][
                    "type"
                ].lower()
                value_type = SPEC_TYPES[param_type_name.lower()]
                # TODO this is a fix for float and int we need to add it in a different node in tool_calling
                if value_type is float:
                    call.parameters[param] = float(value)
                    base_log.debug(
                        f"param: {param} values: {value} param type: {
                                param_type_name} cast to float"
                    )
                elif value_type is int:
                    call.parameters[param] = int(value)
                    base_log.debug(
                        f"param: {param} values: {value} param type: {
                                param_type_name} cast to int"
                    )
                else:
                    issues.param_mistyped.append(param)

        if "enum" in tool_details.parameters[param]:
            if tool_details.parameters[param]["enum"]:
                if isinstance(value, list):
                    diff_list = list(
                        set(value)
                        - set(tool_details.parameters[param]["enum"])
                    )
                else:
                    diff_list = list(
                        set([value])
                        - set(tool_details.parameters[param]["enum"])
                    )
                if diff_list:
                    issues.param_outside_bounds.append(param)
                    base_log.debug(
                        f"Values that are not allowed in {
                            param} are: {diff_list}"
                    )
        # for nested_types ( array and dict)
        # TODO need to write something more general- that deals with greater level of nesting
        if "type" in tool_details.parameters[param]:
            if tool_details.parameters[param]["type"].lower() == "array":
                nested_type = "items"
            elif tool_details.parameters[param]["type"].lower() == "dict":
                nested_type = "properties"
            else:
                nested_type = ""
            if (
                nested_type
                and nested_type in tool_details.parameters[param]
                and "enum" in tool_details.parameters[param][nested_type]
            ):
                if tool_details.parameters[param][nested_type]["enum"]:
                    if isinstance(value, list):
                        diff_list = list(
                            set(value)
                            - set(
                                tool_details.parameters[param][nested_type][
                                    "enum"
                                ]
                            )
                        )
                    else:
                        diff_list = list(
                            set([value])
                            - set(
                                tool_details.parameters[param][nested_type][
                                    "enum"
                                ]
                            )
                        )
                    if diff_list:
                        issues.param_outside_bounds.append(param)
                        base_log.debug(
                            f"Values that are not allowed in {
                                param} are: {diff_list}"
                        )

    # Check if any required parameters were not included in the call
    for param in tool_details.parameters:
        if (
            param in tool_details.parameters["required"]
            and param not in call.parameters
        ):
            # Required parameter is missing
            issues.param_missing.append(param)

    base_log.debug("Call issues: %s", issues)
    return issues


def evaluate_call_list(
    api_calls: List[ApiCallInf],
    context: List[Document],
    missing_value_int: int,
) -> List[ApiCallStaticIssues]:
    """
    Check for issues with inferred API calls.

    Args:
        api_calls (list): List of API calls from LLM.
        context (list): Contextual documents provided to LLM of available APIs.
        missing_value_int (int): Values that correspond to placeholders for
            missing information in the user query.
    Returns:
      List[ApiCallStaticIssues]: list of issues in the api call
    """
    issues = []
    for call in api_calls:
        issue = evaluate_call(call, context, missing_value_int)
        issues.append(issue)
    return issues
