from enum import Enum
from typing import Any, Dict, List, Optional
import importlib.util
import sys
import logging
from gin.common.logging import Logging
from pydantic import BaseModel


class MistakeType(Enum):
    """
    Enumeration of possible types of mistakes in API calls.
    - WRONG_NUMBER_OF_APIS: The number of API calls is incorrect (e.g., missing or redundant API calls).
    - NEED_MORE_APIS: Additional API calls are required in the available specification list to fulfill the user request.
    - WRONG_API_SELECTION: The selected API is incorrect, and an alternative API is suggested.
    - NEED_MORE_INFORMATION: More details are needed to complete a parameter value in an API call.
    - WRONG_PARAMETER_VALUE: The parameter value is incorrect, and an alternative value is suggested.
    - WRONG_UNITS_TRANSFORMATION: Incorrect units transformation in parameter values, and an alternative transformed value is suggested.
    """

    WRONG_NUMBER_OF_APIS = "wrong number of APIs"
    NEED_MORE_APIS = "need more APIs"
    WRONG_API_SELECTION = "wrong API selection"
    NEED_MORE_INFORMATION = "need more information"
    WRONG_PARAMETER_VALUE = "wrong parameter value"
    WRONG_UNITS_TRANSFORMATION = "wrong units transformation"


class EntityType(Enum):
    """
    Enumeration of the type of entity associated with a mistake.
    - LIST_OF_API_CALLS: Refers to a list of API calls.
    - API_CALL: Refers to a single API call.
    - PARAMETER: Refers to a parameter within an API call.
    """

    LIST_OF_API_CALLS = "list of API calls"
    API_CALL = "API call"
    PARAMETER = "parameter"


class Mistake(BaseModel):
    """
    Represents a general mistake in API calls or parameters.
    Attributes:
        mistake_type (MistakeType): The type of mistake (e.g., wrong API selection).
        entity_type (EntityType): The type of entity associated with the mistake (e.g., API call or parameter).
        entity_name (Optional[str]): The name of the entity associated with the mistake (e.g., API name or parameter name).
        explanation (Optional[str]): A detailed explanation of the mistake.
        alternative_value (Optional[Any]): Suggested alternative value for fixing the mistake.
        alternative_type (Optional[Any]): Suggested type or format for the alternative value.
        extra_info (Optional[Dict[str, Any]]): Additional information or metadata about the mistake.
    """

    mistake_type: MistakeType
    entity_type: EntityType
    entity_name: Optional[str] = None
    explanation: Optional[str] = None
    alternative_value: Optional[Any] = None
    alternative_type: Optional[Any] = None
    extra_info: Optional[Dict[str, Any]] = None


class APICallResult(BaseModel):
    """
    Represents the result of validating an individual API call.
    Attributes:
        api_call (str): The API call being validated.
        is_valid (bool): Whether the API call is valid or not.
        issues (Optional[List[Mistake]]):
            - A single mistake, if the issue relates to the entire API call (e.g., wrong API selection).
            - A list of mistakes, if multiple parameter issues exist.
            - None, if the API call is valid.
        alternative_api_call (Optional[str]): Only for parameter issues with the same API function. Suggested alternative API call without unit transformation mistakes.
    """

    api_call: str
    is_valid: bool
    issues: Optional[List[Mistake]] = None
    alternative_api_call: Optional[str] = None


class ReflectionResult(BaseModel):
    """
    Represents the overall validation result for a set of API calls.
    Attributes:
        list_of_api_calls (Optional[List[str], str]):
            - A list of API calls if multiple calls are being validated.
            - A list of API calls in a single string format, if provided.
            - None, if no calls are provided.
        is_correct (bool): Whether the entire list of API calls is correct based on the user request.
        valid_llm_response (bool): Whether the LLM model provided a valid response for the validation task.
        error_message (Optional[str]): A message describing the error that occurred.
        api_calls_results (Optional[List[APICallResult]]): A list of results for each API call in the list.
        alternative_list_of_api_calls (Optional[Mistake]): An alternative list of API calls if the original list is incorrect (e.g., wrong number of APIs).
        mistake_types (Optional[Dict[MistakeType, bool]]): A dictionary of mistake types and their presence in the validation results.
        mistake_explanations (Optional[str]): A detailed explanation of the mistakes in the API calls (for wrong number of APIs or need more APIs or need more information).
    """

    list_of_api_calls: Optional[List[str]] = None
    is_correct: bool
    valid_llm_response: bool
    error_message: Optional[str] = None
    api_calls_results: Optional[List[APICallResult]] = None
    alternative_list_of_api_calls: Optional[Mistake] = None
    mistake_types: Optional[Dict[MistakeType, bool]] = None
    mistake_explanations: Optional[str] = None


def api_calls_LLM_reflector(
    api_specs_user_request_api_calls,
    logs_dir,
    parallel_eval_model_id,
    cot_generator_model_id,
    judge_model_id,
    transformation_agent_model_id,
    num_parallel=10,
    parallel_api_calls_judge=True,
    extra_judge=True,
    check_transformations=True,
    platform="genai",
):
    """
    Mock LLM reflector implementation
    """
    return ReflectionResult(
        is_correct=True,
        valid_llm_response=True,
        api_calls_results=[],
        mistake_types={
            MistakeType.WRONG_NUMBER_OF_APIS: False,
            MistakeType.NEED_MORE_APIS: False,
            MistakeType.WRONG_API_SELECTION: False,
            MistakeType.NEED_MORE_INFORMATION: False,
            MistakeType.WRONG_PARAMETER_VALUE: False,
            MistakeType.WRONG_UNITS_TRANSFORMATION: False,
        },
        mistake_explanations="",
    ).model_dump_json()


def load_api():
    """
    Dynamically loads llm_reasoning_judge package from the specified path, overwriting a dummy llm_reasoning_judge_interface package if the path exists.

    This function checks if the specified path contains a valid package. If valid, it dynamically loads the package and overwrites the dummy implementation
    of the package. Otherwise, it retains the dummy package and logs a message.

    Args:
        llm_reasoning_judge_path (str): The file system path to the llm_reasoning_judge local package directory.

    Behavior:
        - If the package path exists and is valid, the real package will replace the dummy package under the
          name "dummy_package" in the `sys.modules` registry.
        - If the path does not exist or is invalid, the dummy package will remain in use, and a message will
          be logged to the console.

    Notes:
        - Ensure that the real package is structured like a standard Python package, with an `__init__.py` file.
        - This function dynamically updates the `sys.modules` registry, so you must import the
          llm_reasoning_judge_interface package after calling this function to get the updated module.
    """
    base_log = logging.getLogger(Logging.BASE)
    try:
        # Try importing the package dynamically
        llm_reasoning_judge_package = importlib.import_module(
            "llm_reasoning_judge"
        )

        sys.modules["gin.gen.util.llm_reasoning_judge_interface"] = (
            llm_reasoning_judge_package
        )
        base_log.debug(
            "Loaded llm_reasoning_judge package from: %s",
            llm_reasoning_judge_package,
        )
    except Exception as e:
        base_log.debug(f"Failed to load llm_reasoning_judge package: {e}")
