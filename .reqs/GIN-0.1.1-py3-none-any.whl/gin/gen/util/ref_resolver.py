import logging
from gin.common.logging import Logging

base_log = logging.getLogger(Logging.BASE)


def resolve_ref_for_object(spec, obj, _visited_refs=None):
    """
    Resolve all references for an object given in the spec.

    Args:
        spec (dict): OpenAPI v3 specification.
        obj (dict): Object to resolve all references for (also nested).
        _visited_refs (set): set to hold visited references to avoid circular dependencies.

    Returns:
        dict: Dict of the object schema with all references resolved.
    """
    if _visited_refs is None:
        _visited_refs = set()

    if isinstance(obj, dict):
        if "$ref" in obj:
            ref = obj["$ref"]
            if not isinstance(ref, str):
                # This is a parameter called '$ref', but not actually a
                # reference pointer.
                return obj
            if ref[:2] != "#/":
                raise NotImplementedError(
                    "Only local references are supported"
                )
            if ref in _visited_refs:
                base_log.warning(
                    "Circular reference detected for ref: %s", ref
                )
                # Return the reference path in case of circular dependency.
                return obj["$ref"]
            _visited_refs.add(ref)
            parts = ref.lstrip("#/").split("/")
            ref_obj = spec
            for part in parts:
                if part not in ref_obj:
                    raise KeyError(f"Cannot complete reference: {ref}")
                ref_obj = ref_obj[part]
            resolved_obj = resolve_ref_for_object(spec, ref_obj, _visited_refs)
            # remove from visited_refs so in other sub-objects we resolve again
            _visited_refs.remove(ref)
            return resolved_obj
        else:
            # if there is no reference go deeper in the object schema
            return {
                key: resolve_ref_for_object(spec, value, _visited_refs)
                for key, value in obj.items()
            }
    elif isinstance(obj, list):
        # resolve each item and return a list as the original object
        return [
            resolve_ref_for_object(spec, item, _visited_refs) for item in obj
        ]
    else:
        return obj
