"""
Generic utilities.
"""

import ast
import re


def get_missing_value_int(query: str) -> int:
    """
    Get an integer that does not exist in the user query. This is used as a
    base for creating placeholder values for required parameters that have
    not been provided in the user query.
    Args:
        query (str): User query.
    Returns:
        int: Integer value that does not exist in the query.
    """
    missing_value_int = 35317
    while str(missing_value_int) in query:
        missing_value_int += 1700


def to_snake_case(arb_case: str) -> str:
    """
    Take a string in arbitrary case and return in snake_case.

    Args:
        arb_case (str): String in arbitrary naming convention.

    Returns:
        str: String in snake_case format.
    """
    arb_case = arb_case.strip()
    if len(arb_case) == 0:
        return ""
    snake_case = ""
    last_was_upper = True
    for cc in arb_case:
        if cc == "_":
            snake_case += "_"
        elif cc == " ":
            continue
        elif cc.isupper():
            if last_was_upper:
                snake_case += cc.lower()
            else:
                snake_case += "_" + cc.lower()
            last_was_upper = True
        else:
            if last_was_upper:
                if len(snake_case) > 0:
                    if snake_case[-2:-1] == "_":
                        snake_case += cc
                    else:
                        snake_case = (
                            snake_case[:-1] + "_" + snake_case[-1] + cc
                        )
                else:
                    snake_case = cc
            else:
                snake_case += cc
            last_was_upper = False

    if snake_case[0] == "_":
        return snake_case[1:]
    return snake_case


def to_pascal_case(arb_case: str) -> str:
    """
    Take a string in arbitrary case and return in PascalCase.

    Args:
        arb_case (str): String in arbitrary naming convention.

    Returns:
        str: String in PascalCase format.
    """
    arb_case = arb_case.strip()
    pascal_case = ""
    capitalize_next = True
    for cc in arb_case:
        if cc == "_":
            capitalize_next = True
            continue
        if cc == " ":
            continue
        if capitalize_next:
            pascal_case += cc.upper()
            capitalize_next = False
        else:
            pascal_case += cc
    return pascal_case


def remove_invalid_json_escapes(json_str: str):
    """
    Take a JSON string and remove invalid uses of the escape character '\'.

    Args:
        json_str (str): JSON string

    Returns
        str: JSON string with no improper use of the escape character.
    """
    escapes = json_str.strip().split("\\")
    clean_substrs = [escapes[0]]
    for substr in escapes[1:]:
        if not substr:
            # This is an escaped backslash
            clean_substrs.append("\\\\")
            continue
        elif substr[0] in '"/\b\f\n\r\t':
            # The character is escapable, keep the backslash
            clean_substrs.append("\\")
        clean_substrs.append(substr)
    return "".join(clean_substrs)


def func_call_format_good(func_str: str) -> bool:
    """
    Check that the function string format is structurally correct.

    Args:
        func_str (str): Function call string.

    Returns:
        bool: True if format is correct.
    """
    regex = "^[a-zA-Z0-9_]([a-zA-Z0-9_\\.]*)(\\((.|\n)*\\))$"
    return re.search(regex, func_str.strip()) is not None


def _get_kv_substrings(arg_str: str) -> list:
    """Get kwarg-value substrings from a string of all kwarg-value pairs.

    The full argument string is split into substrings by splitting at commas,
    and then checking that these commas are not part of the value assigned to
    a key. In the case where a value is a tuple or function call (surrounded by
    parenthesis), dict (surrounded by braces), list (surrounded by brackets),
    or string (surrounded by single or double quotes), any of these value types
    may contain commas which need to remain in place.

    The substrings returned will have leading and trailing whitespace removed.
    This function does no error reporting on invalid substrings, and will add
    erroneous substrings to the substring list.

    Args:
        arg_str (str): String of keyword arguments and values

    Returns:
        list: Substrings of individual kwarg-value pairs.
    """
    # The list of substrings we're building here
    kv_substrings = []
    # Characters which when begin a value indicate the start of a string
    # sequence that may contain a comma as part of the value, along with their
    # closing counterpart.
    special_chars = {"(": ")", "{": "}", "[": "]", '"': '"', "'": "'"}
    # Indicator if this substring is a continuation of the last substring, and
    # what char we need to find to complete the value for the substring
    eol_char = ""
    # Divide string by commas. We'll check if any commas are internal to
    # the value (such as passing a list, dict, set, or str as a value to a
    # kwarg).
    for substr in arg_str.strip().split(","):
        if eol_char == "":
            substr = substr.lstrip()
            if "=" not in substr:
                # Erroneous substring, add it and move on
                kv_substrings.append(substr.rstrip())
                continue
            key, value = substr.split("=", 1)
            key = key.strip()
            value = value.lstrip()
            if value == "":
                # Erroneous substring, add it and move on
                kv_substrings.append(f"{key}=")
                continue
            # Evaluate substring
            if value[0] not in special_chars:
                # No need to concatenate next substring with this one
                kv_substrings.append(f"{key}={value.rstrip()}")
                continue
            # See if this substring needs to be combined with the next one
            eol_char = special_chars[value[0]]
            if len(value) == 1:
                continue
            # Indicator if the next character is escaped
            escaped = False
            for char in value[1:]:
                if char == eol_char and not escaped:
                    # Found closing character
                    eol_char = ""
                    break
                if char == "\\" and not escaped:
                    escaped = True
                elif escaped:
                    escaped = False
            if eol_char == "":
                # This substring is complete
                kv_substrings.append(f"{key}={value.rstrip()}")
            else:
                # This substring needs to be combined with the next
                kv_substrings.append(f"{key}={value}")
        else:
            # This is a continuation of the last substring.
            escaped = False
            for char in substr:
                if char == eol_char and not escaped:
                    # Found closing character
                    eol_char = ""
                    break
                if char == "\\" and not escaped:
                    escaped = True
                elif escaped:
                    escaped = False
            if eol_char == "":
                # This substring is complete
                kv_substrings[-1] += "," + substr.rstrip()
            else:
                # This substring needs to be combined with the next
                kv_substrings[-1] += "," + substr
    return kv_substrings


def get_kv_pairs(func_str: str) -> tuple:
    """Get key-value pairs from a function call string.

    In the process of parsing into key value pairs, any issues encountered
    along the way will be reported into the following groups, which are the
    keys to the issues dict returned (the key will only exist if the issue
    occurs, and in most cases will contain a list of substrings that exhibit
    the issue).

    - blank_substring: A count of the number of times a blank substring exists.
        This is where a set of commas occur with nothing between, such as
        my_func_call(param_a=5, param_b=84, , param_c=9)

    - invalid_pair: An argument does not contain a valid key-value pair, which
        can occur if a value is passed as a positional argument rather than as
        a keyword argument.

    - repeated_arg: An argument with the same keyword has been provided more
        than once. In this case the first occurrence of the key will be added
        to the returned dict of arguments, and subsequent occurrences will be
        added to the issues dict.

    - invalid_value: The value to an argument does not appear to be
        syntactically valid. This could be a string that does not have a
        closing quote or a list missing a bracket.

    Args:
        func_str (str): Function call string

    Returns:
        tuple: dict of arguments, and dict of issues.
            Keys for issues will only show up if that issue occurs.
            Issues are 'blank_substring', 'invalid_pair', 'repeated_arg'
            'invalid_value'.
    """
    # Take whatever is between parenthesis
    if "(" not in func_str:
        arg_str = ""
    else:
        arg_str = func_str.split("(", 1)[1].rsplit(")", 1)[0].strip()

    kwargs = {}
    issues = {}
    if arg_str == "":
        # Check for empty arguments; this will prevent returning with a blank
        # substring issue.
        return (kwargs, issues)
    # Divide arguments string into key/value substrings
    kv_substrings = _get_kv_substrings(arg_str)
    # Separate arguments and values, iterating over key/value substrings
    for ii, kv_str in enumerate(kv_substrings):
        if kv_str == "":
            # Blank substring
            if ii == len(kv_substrings) - 1:
                # Not an issue if this is at the very end
                continue
            if "blank_substring" not in issues:
                issues["blank_substring"] = 0
            issues["blank_substring"] += 1
            continue
        if "=" not in kv_str:
            # Not a key/value pair
            if "invalid_pair" not in issues:
                issues["invalid_pair"] = []
            issues["invalid_pair"].append(kv_str)
            continue
        key, val = kv_str.split("=", 1)
        if key in kwargs:
            # Repeated argument
            if "repeated_arg" not in issues:
                issues["repeated_arg"] = []
            issues["repeated_arg"].append(kv_str)
            continue
        val = val.strip()
        if len(val) >= 2 and val[0] == val[-1] and val[0] in ['"', "'"]:
            # Value is a string. This will not correctly process with
            # ast.literal_eval(), so we deal with this case here first.
            kwargs[key] = val[1:-1]
        else:
            try:
                kwargs[key] = ast.literal_eval(val)
            except BaseException:
                # Some error with val
                if "invalid_value" not in issues:
                    issues["invalid_value"] = []
                issues["invalid_value"].append(kv_str)
                # Add the kwarg with None, so at least we know the arg was used
                kwargs[key] = None
    return (kwargs, issues)
