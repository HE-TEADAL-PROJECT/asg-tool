from typing import Any, Optional
from pydantic import BaseModel, ConfigDict, model_serializer
from typing import List, Dict


class AppliedTransform(BaseModel):
    transform_uid: str
    """Transform function."""
    arguments: Optional[dict[str, Any]] = {}
    explanation: Optional[str] = None

    def __eq__(self, value):
        return (
            self.transform_uid == value.transform_uid
            and self.arguments == value.arguments
        )


class OutputPropertyTransformations(BaseModel):
    model_config = ConfigDict(extra="allow")
    name: str
    transformations: List[AppliedTransform] = []

    @model_serializer
    def to_dict(self) -> Dict[str, Any]:
        return {
            "name": self.name,
            "transformations": [
                transform.model_dump() for transform in self.transformations
            ],
        }


class OutputTableSchemaTransformations(BaseModel):
    name: str
    properties: List[OutputPropertyTransformations]

    @model_serializer
    def to_dict(self) -> Dict[str, Any]:
        return {
            "name": self.name,
            "properties": {
                prop.name: prop.model_dump() for prop in self.properties
            },
        }
