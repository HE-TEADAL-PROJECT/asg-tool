from gin.gen.agents.tool_calling import simple_tool_calling
from langchain_core.prompts import ChatPromptTemplate
from ._types import AppliedTransform
from gin.common.types import ToolDetails
from typing import List, Any
from toolkit._types import InputPropertyDefinition

template = ChatPromptTemplate(
    messages=[
        (
            "human",
            (
                "Choose a subset of the following arguments and a function to produce the value of `{target_property}`, described as: {target_property_description}.\n\n"
                "Arguments: {source_properties}\n\n"
                "Instructions:\n"
                "- Wrap each chosen argument with `[$PROPERTY]` when using it as an input to the function."
            ),
        ),
    ],
    input_variables=[
        "target_property",
        "target_property_description",
        "source_properties",
    ],
)


def find_transform(
    target_property: InputPropertyDefinition,
    sources: List[InputPropertyDefinition],
    transforms: List[ToolDetails],
    config_path: str,
    trace: Any,
) -> List[AppliedTransform]:
    """
    Finds and applies transforms for the given target property and source properties.

    Args:
        target_property: The target property definition to transform to
        sources: List of source property definitions
        transforms: Available transformation functions
        config_path: Path to the configuration file

    Returns:
        List[AppliedTransform]: List of applied transforms, including identities
    """
    # Prepare data for template
    dump_sources = [
        {
            "description": source.description,
            "name": source.name,
            "metadata": source.metadata,
        }
        for source in sources
    ]

    dump_target = {
        **target_property.model_dump(),
        "name": target_property.name,
    }
    functions = [transform.model_dump() for transform in transforms]

    # If no functions, return identity transforms on all sources with justifications
    if not functions:
        identity_transforms = []
        for source in sources:
            justification = next(
                (
                    candidate.judge_output.justification
                    for candidate in trace.trace[target_property.name]
                    if candidate.source_property.name == source.name
                ),
                None,
            )
            identity_transforms.append(
                AppliedTransform(
                    transform_uid="identity",
                    arguments={"item_1": source.name},
                    explanation=justification,
                )
            )
        return identity_transforms

    if not dump_sources:
        return []
    # Get transform from LLM
    query = template.format(
        target_property=dump_target["name"],
        target_property_description=dump_target["description"],
        source_properties=dump_sources,
    )
    result_transform = simple_tool_calling(
        query=query,
        functions=functions,
        config_file=config_path,
    )

    single_source_candidates = [
        (candidate.source_property.name, candidate.judge_output.justification)
        for candidate in trace.trace[target_property.name]
        if candidate.judge_output
        and candidate.judge_output.selected_explanation == "supportive"
    ]

    # Create default identity transforms with justifications
    applied_transforms = [
        AppliedTransform(
            transform_uid="identity",
            arguments={"item_1": source_name},
            explanation=justification,
        )
        for source_name, justification in single_source_candidates
    ]

    def create_new_transform(transform, trace, target_property):
        # Get justifications for all source properties used in the transform
        source_justifications = []
        inserted_sources = []
        for source_name in transform.parameters.values():
            for candidate in trace.trace[target_property.name]:
                if (
                    candidate.source_property.name == source_name
                    and source_name not in inserted_sources
                ):
                    inserted_sources.append(source_name)
                    source_justifications.append(
                        candidate.judge_output.justification
                    )
                    break

        combined_justification = "\n".join(source_justifications)

        return AppliedTransform(
            transform_uid=transform.name,
            arguments=transform.parameters,
            explanation=combined_justification,
        )

    if result_transform and result_transform["LLM_api_calls"]:
        transform = result_transform["LLM_api_calls"][0]
        if transform.name is None:
            return applied_transforms

        new_transform = create_new_transform(transform, trace, target_property)
        return (
            [new_transform] + applied_transforms
            if new_transform and new_transform not in applied_transforms
            else applied_transforms
        )
