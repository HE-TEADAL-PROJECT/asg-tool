from toolkit.explain_judge_rank._state_models import (
    PropertyProgress,
    TraceSchema,
)
from typing import List, Dict
from gin.common.types import ToolDetails
from toolkit._types import InputPropertyDefinition, InputTableSchema


def _find_transfrom_by_name(
    transform_name: str, transforms: List[ToolDetails]
) -> ToolDetails:
    """
    Finds the transform by name.

    Args:
        transform_name (str): The transform name to find.
        transforms (List[Transform]): The list of transforms to search.

    Returns:
        Transform: The transform with the given name.
    """
    return next(
        (
            transform
            for transform in transforms
            if transform.name == transform_name
        ),
        None,
    )


def _extract_sources_from_target(
    target_property: str, sources: List[PropertyProgress]
) -> List[InputPropertyDefinition]:
    """
    Extracts the sources from the  for the given target property.

    Args:
        target_property (str): The target property to extract sources for.
        sources (List[PropertyProgress]): The list of sources to extract from.

    Returns:
        List[PropertyProgress]: A list of sources for the target property.
    """
    return [
        source.source_property
        for source in sorted(
            [s for s in sources if s.verdict == "Accepted"],
            key=lambda x: x.rank,
        )
    ]


def extract_target_by_name(
    target_property: str, target_schema: InputTableSchema
):
    """
    Extracts the target property by name.

    Args:
        target_property (str): The target property to extract.
        target_schema (InputTableSchema): The target schema to extract from.

    Returns:
        InputPropertyDefinition: The target property definition.
    """
    return next(
        (
            col
            for col in target_schema.properties
            if col.name == target_property
        ),
        None,
    )


def fetch_sources_by_target_from_trace(
    trace: TraceSchema,
) -> Dict[str, List[InputPropertyDefinition]]:
    """
    Extracts the sources from the trace.

    Args
        trace (TraceSchema): The trace to extract sources from.

    Returns:
        Dict[str, List[str]]: A dictionary mapping target properties to their sources.
    """

    return {
        target_property: _extract_sources_from_target(target_property, sources)
        for target_property, sources in trace.trace.items()
    }
