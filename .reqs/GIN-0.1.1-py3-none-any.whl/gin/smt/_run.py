from ._types import (
    OutputTableSchemaTransformations,
    OutputPropertyTransformations,
)
from toolkit import solve_binary as solve_sm
from toolkit._types import (
    InputPropertyDefinition,
    FinalOutput,
    InputTableSchema,
    Tools,
)
from typing import List, Dict
from toolkit.explain_judge_rank import (
    explainer_template,
    judge_template,
    ranker_template,
)
from ._utils import fetch_sources_by_target_from_trace, extract_target_by_name
from ._transform import find_transform
from gin.common.types import ToolDetails

DEFAULT_CANDIDATE_MODEL_ID = "meta-llama/llama-3-3-70b-instruct"
DEFAULT_EXPLAINER_MODEL_ID = DEFAULT_JUDGE_MODEL_ID = (
    DEFAULT_RANKER_MODEL_ID
) = DEFAULT_CANDIDATE_MODEL_ID


def run(
    source_schema: InputTableSchema,
    target_schema: InputTableSchema,
    transformations: List[ToolDetails],
    **kwargs,
) -> OutputTableSchemaTransformations:
    """
    Run the SMT solver to generate the output schema.

    Args:
        source_schema: Input table schema.
        target_schema: Target table schema.
        transformations: List of transformations to apply.

    Returns:
        Output table schema.
    """
    config_path = kwargs.get("config_path", None)
    config = {
        "explainer_model_id": kwargs.get(
            "explainer_model_id", DEFAULT_EXPLAINER_MODEL_ID
        ),
        "judge_model_id": kwargs.get("judge_model_id", DEFAULT_JUDGE_MODEL_ID),
        "ranker_model_id": kwargs.get(
            "ranker_model_id", DEFAULT_RANKER_MODEL_ID
        ),
        "explainer_prompt": explainer_template,
        "judge_prompt": judge_template,
        "ranker_prompt": ranker_template,
        # Mapping type would be ONE_TO_ONE automatically, if no transformation is provided (empty list).
        "mapping_type": (
            kwargs.get("mapping_type", "ONE_TO_ONE")
            if transformations
            else "ONE_TO_ONE"
        ),
        "platform": kwargs.get("platform", "rits"),
    }
    tool = Tools.EXPLAIN_JUDGE_RANK

    # Call the SMT solver to generate the output schema.
    final_output: FinalOutput = solve_sm(
        source_schema_dict=source_schema.model_dump(),
        target_schema_dict=target_schema.model_dump(),
        tool=tool.value,
        **config,
    )

    trace = final_output.trace
    output_table = final_output.table
    sources_by_target: Dict[str, List[InputPropertyDefinition]] = (
        fetch_sources_by_target_from_trace(trace)
    )
    output_properties = [
        OutputPropertyTransformations(
            name=target_property_name,
            transformations=(
                find_transform(
                    extract_target_by_name(
                        target_property=target_property_name,
                        target_schema=target_schema,
                    ),
                    sources=sources_by_target[target_property_name],
                    transforms=transformations,
                    config_path=config_path,
                    trace=trace,
                )
            ),
        )
        for target_property_name, target_property in [
            (name, next(p for p in output_table.properties if p.name == name))
            for name in sources_by_target
        ]
    ]

    return OutputTableSchemaTransformations(
        name=output_table.name,
        properties=output_properties,
    )
