"""Package for Generative AI Integration (GIN)."""

__version__ = "0.1.1"
