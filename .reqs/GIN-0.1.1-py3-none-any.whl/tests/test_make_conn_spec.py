import unittest
import gin.common.con_spec
from gin.gen.types import ApiCallInf
from tests.data.docs import doc_events


class TestMakeConnSpec(unittest.TestCase):
    def test_fields(self):
        api_calls = ApiCallInf(
            raw_str="",
            valid=True,
            name="agentMonitoringEvents",
            parameters={
                "to": 1627885440,
                "windowSize": 600000,
                "excludeTriggeredBefore": True,
                "filterEventUpdates": False,
            },
        )

        transform_fn = gin.common.con_spec.TransformFunction(
            function="func1",
            description="func1 description",
            params={"arg1": 3},
            output=" outputField1",
        )
        exports = gin.common.con_spec.ProcessDataSet(
            dataframe="input_frame",
            fields={"outField1": [transform_fn, transform_fn]},
        )

        connector = gin.common.con_spec.make_connector_spec(
            api_calls=[api_calls],
            context=doc_events,
            user_input="test input",
            out_dataframes=None,
            exports={"outputdf": exports},
        )

        self.assertTrue("outputdf" in connector.spec.output.exports.keys())
        self.assertTrue(
            "func1 description"
            == connector.spec.output.exports["outputdf"]
            .fields["outField1"][0]
            .description
        )
        self.assertTrue(
            "arg1"
            in connector.spec.output.exports["outputdf"]
            .fields["outField1"][1]
            .params
        )


if __name__ == "__main__":
    unittest.main()
