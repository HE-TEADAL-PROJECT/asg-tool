import os
import pickle
import unittest
from unittest.mock import patch
import pandas as pd

import gin.common.con_spec
import gin.gen.config
import gin.executor.exec
from gin.common.types import EnvToken

# Connector file example to test
CONNECTOR_FILE = "tests/instana/connector.yaml"
# Pickled response from a successful execution of the connector
GET_RESPONSE_FILE = "tests/instana/response_success.pickle"
# Pickled response from an unauthorized error execution of the connector
GET_RESPONSE_UNAUTH_FILE = "tests/instana/response_unauthorized.pickle"


class TestUtil(unittest.TestCase):

    @patch("gin.executor.rest_apis.requests.get")
    def test_connector_execution(self, get_mock):
        connector = gin.common.con_spec.import_connector_from_file(
            CONNECTOR_FILE
        )
        # Get the environment variable that stores the API key, and set that
        # environment variable to a fake key
        api_key_env_var = (
            connector.spec.apicalls["events.getEvents"]
            .arguments[0]
            .value.split("$")[1]
        )
        os.environ[api_key_env_var] = "fakeKey012"
        # Make sure we can get that key from the loaded connector
        self.assertEqual(
            os.environ[api_key_env_var],
            EnvToken("$" + api_key_env_var).get_secret_value(),
        )

        # Load a pickled responses from an actual execution
        with open(GET_RESPONSE_FILE, "rb") as file:
            get_response = pickle.load(file)
        with open(GET_RESPONSE_UNAUTH_FILE, "rb") as file:
            get_response_unauth = pickle.load(file)

        # Mock the executor's execution of request.get() using the pickled
        # responses
        def get(url, params=None, headers=None, **kwargs):
            # Get value for 'Authorization' from provided header
            if headers:
                auth_val = headers.get("Authorization", None)
            else:
                auth_val = None
            # Expected authorization value for successful authentication
            auth_val_expected = (
                "apiToken "
                + EnvToken("$" + api_key_env_var).get_secret_value()
            )
            # Return response based on authorization
            if auth_val == auth_val_expected:
                return get_response
            return get_response_unauth

        # Set the patched requests.get to our mocked get function
        get_mock.side_effect = get

        # Run example connector, getting raw output format
        output = gin.executor.exec.run_from_spec_file(CONNECTOR_FILE)

        expected_dataframe = pd.json_normalize(get_response.json())
        # self.assertAlmostEqual(output["out"], expected_dataframe, msg=f"{output["out"]}\n\n{expected_dataframe}" )
        self.assertEqual(len(output[""]), len(expected_dataframe))
