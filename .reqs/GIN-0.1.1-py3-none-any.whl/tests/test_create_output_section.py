import pytest
import json
from gin.common.con_spec import Dataset, create_output_section
from gin.common.types import ApiCallInf
from tests.data.docs import doc_events, doc_service

event_call = ApiCallInf(
    raw_str=json.dumps(
        {
            "name": "getEvents",
            "arguments": {
                "windowSize": 300000,
                "excludeTriggeredBefore": True,
                "eventTypeFilters": ["INCIDENT"],
            },
        }
    ),
    valid=True,
    name="getEvents",
    parameters={
        "windowSize": 300000,
        "excludeTriggeredBefore": True,
        "eventTypeFilters": ["INCIDENT"],
    },
)


@pytest.mark.parametrize("call,context", [(event_call, doc_events)])
def test_out_dataframes_array(call, context):
    res_out = create_output_section(call, context)
    assert isinstance(res_out[call.name], Dataset)
    expected = Dataset(api=call.name)
    assert expected == res_out[call.name]


service_call = ApiCallInf(
    raw_str=json.dumps(
        {
            "name": "getServicesMap",
            "arguments": {"applicationId": "Robot Shop T"},
        }
    ),
    valid=True,
    name="getServicesMap",
    parameters={"applicationId": "Robot Shop T"},
)


@pytest.mark.parametrize("call,context", [(service_call, doc_service)])
def test_out_dataframes_multiple_tables(call, context):
    res_out = create_output_section(call, context)
    assert isinstance(res_out["connections"], Dataset)
    assert isinstance(res_out["services"], Dataset)
    expected = {}
    expected["connections"] = Dataset(api=call.name, path="connections")
    expected["services"] = Dataset(api=call.name, path="services")
    assert expected == res_out
