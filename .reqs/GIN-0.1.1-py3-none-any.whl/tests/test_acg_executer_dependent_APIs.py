import unittest
from unittest.mock import patch
import pandas as pd

import gin.common.con_spec
import gin.gen.config
import gin.executor.exec
from gin.common.con_spec import Dataset

# Connector file example to test
CONNECTOR_FILE = "tests/instana/test_connector.yaml"

test_output = {
    "application_resources.getApplications": {
        "items": [
            {"id": "1", "name": "fake1"},
            {"id": "2", "name": "fake2"},
            {"id": "3", "name": "fake3"},
        ]
    },
    "application_topology.getServicesMap": {
        "services": [
            {"service_id": "1", "name": "fake1"},
            {"service_id": "2", "name": "fake2"},
            {"service_id": "3", "name": "fake3"},
        ]
    },
}

was_executed = {
    "application_resources.getApplications": False,
    "application_topology.getServicesMap": False,
}


class TestUtil(unittest.TestCase):

    @patch("gin.executor.exec.ConnectorRequest._route_to_api_call_type")
    def test_perform_api_call_dep_calling(self, get_mock):
        """
        Test that dependent APIs are being called.
        """
        connector_request = gin.executor.exec.ConnectorRequest(
            spec_file=CONNECTOR_FILE
        )
        # Get the environment variable that stores the API key, and set that
        # environment variable to a fake key
        # Setup pre-reqs in exec
        connector_request.api_calls_result = {}
        connector_request.executed_apis = {}

        test_api_name = "application_topology.getServicesMap"
        test_api_output_spec = {
            "services": connector_request.con_spec.spec.output.data["services"]
        }
        self.assertIsInstance(test_api_output_spec["services"], Dataset)

        # Mock the executor's _route_to_api_call_type() using the pickled
        # responses
        def route_to_api_call_type(
            api_name, reference_resolution, output_data=None, timeout=None
        ):
            output = {}
            for key, value_array in test_output[api_name].items():
                output[key] = pd.json_normalize(value_array)
            was_executed[api_name] = True
            return output

        get_mock.side_effect = route_to_api_call_type
        connector_request.perform_api_call(test_api_name, test_api_output_spec)

        # Check that all dependent APIs were called
        for key, was_exec in was_executed.items():
            self.assertTrue(
                was_exec, msg=f"Did not execute API call to {key}."
            )
