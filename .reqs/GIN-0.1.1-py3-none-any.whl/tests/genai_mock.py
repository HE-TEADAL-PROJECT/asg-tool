from typing import Optional, Union, List, Dict
from genai.client import Client


class MockCredentials:
    """Mock credentials class for API access."""

    def __init__(self, api_key, api_endpoint="https://bam-api.res.ibm.com"):
        if not api_key:
            raise ValueError("api_key must be provided")
        self.api_key = api_key
        self.api_endpoint = api_endpoint


class MockTextGenerationResult:
    """Mock result class for text generation."""

    def __init__(self, generated_text):
        self.generated_text = generated_text

    def model_dump(self, exclude=None, exclude_none=False):
        """Mock serialization method for testing purposes."""
        data = {"generated_text": self.generated_text}

        if exclude:
            for key in exclude:
                data.pop(key, None)

        if exclude_none:
            data = {k: v for k, v in data.items() if v is not None}

        return data


class MockTextGenerationResponse:
    """Mock response class for text generation."""

    def __init__(self, results):
        self.generated_text = results
        self.results = results

    def model_dump(self, exclude=None, exclude_none=False):
        """Mock serialization method for testing purposes."""
        data = {"generated_text": self.generated_text}

        if exclude:
            for key in exclude:
                data.pop(key, None)

        if exclude_none:
            data = {k: v for k, v in data.items() if v is not None}

        return data


class MockTextGeneration:
    """Mock class for text generation API calls."""

    def create(
        self,
        *,
        model_id: Optional[str] = None,
        prompt_id: Optional[str] = None,
        input: Optional[str] = None,
        inputs: Optional[Union[List[str], str]] = None,
        parameters: Optional[dict] = None,
        moderations: Optional[dict] = None,
        data: Optional[dict] = None,
        execution_options: Optional[dict] = None,
    ):
        """Simulate text generation."""
        ret_val = []
        if input:
            ret_val += [
                MockTextGenerationResponse(
                    [
                        MockTextGenerationResult(
                            f"Generated text for input: {input}"
                        )
                    ]
                )
            ]
        elif inputs:
            if isinstance(inputs, list):
                ret_val += [
                    MockTextGenerationResponse(
                        [
                            MockTextGenerationResult(
                                f"Generated text for input: {inp}"
                            )
                            for inp in inputs
                        ]
                    )
                ]
            else:
                ret_val += [
                    MockTextGenerationResponse(
                        [
                            MockTextGenerationResult(
                                f"Generated text for input: {inputs}"
                            )
                        ]
                    )
                ]
        else:
            ret_val += [
                MockTextGenerationResponse(
                    [MockTextGenerationResult("Generated text for no input")]
                )
            ]

        return ret_val


class MockTextRerankResult:
    """Mock result class for text reranking."""

    def __init__(self, score, index):
        self.score = score
        self.index = index


class MockTextRerankResponse:
    """Mock response class for text reranking."""

    def __init__(self, query, results):
        self.query = query
        self.results = results


class MockTextRerankCreateResponse:

    def __init__(self, result):
        self.result: MockTextRerankResponse = result


class MockTextRerank:
    """Mock class for text reranking API calls."""

    def create(
        self,
        *,
        model_id: str,
        query: str,
        documents: List[str],
        parameters: Optional[Dict] = None,
    ) -> MockTextRerankResponse:
        """Simulate text reranking."""
        score = 1.0 / len(documents)
        results = [
            MockTextRerankResult(score, i) for i in range(len(documents))
        ]
        return MockTextRerankCreateResponse(
            result=MockTextRerankResponse(query, results)
        )


class MockTextEmbeddingCreateResults:

    def __init__(
        self, embedding: List[float], input_text: Optional[str] = None
    ):
        self.embedding = embedding
        self.input_text = input_text


class MockTextEmbeddingResponse:
    """Mock response class for text embedding."""

    def __init__(self, results):
        self.results = results


class MockTextEmbedding:
    """Mock class for text embedding API calls."""

    def create(
        self,
        *,
        model_id: str,
        inputs: Union[str, List[str]],
        parameters: Optional[Dict] = None,
        execution_options: Optional[Dict] = None,
    ):
        """Simulate text embedding generation."""
        ret_val = []

        def generate_embeddings(input_text):
            return MockTextEmbeddingCreateResults(
                embedding=[0.1] * 768, input_text=input_text
            )

        if isinstance(inputs, list):
            ret_val = [
                MockTextEmbeddingResponse(
                    [
                        generate_embeddings(input_text=input_text)
                        for input_text in inputs
                    ]
                )
            ]
        else:
            ret_val = [
                MockTextEmbeddingResponse(
                    [generate_embeddings(input_text=inputs)]
                )
            ]

        return ret_val


class MockExperimental:
    """Mock class for experimental features."""

    def __init__(self):
        self.rerank = MockTextRerank()


class MockText:
    """Mock class grouping text-related functionalities."""

    def __init__(self):
        self.generation = MockTextGeneration()
        self.experimental = MockExperimental()
        self.embedding = MockTextEmbedding()


class MockClient(Client):
    """Mock client class for interacting with the API."""

    def __init__(self, credentials):
        if not isinstance(credentials, MockCredentials):
            raise ValueError("Valid credentials must be provided.")
        self.credentials = credentials
        self.text = MockText()
