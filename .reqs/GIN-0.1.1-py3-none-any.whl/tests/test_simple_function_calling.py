import unittest
from unittest.mock import patch

from typing import Any

from gin.gen.agents.tool_calling import (
    ToolCallingState,
    simple_tool_calling,
)

# Connector file example to test
CONFIG_FILE = "./tests/test_configs/mock_config.yaml"

test_queries = [
    {
        "query": "What is the capital of Brazil?",
        "functions": [
            {
                "name": "country_info.largest_city",
                "description": "Fetch the largest city of a specified country.",
                "parameters": {
                    "country": {
                        "type": "string",
                        "description": "Name of the country.",
                        "required": True,
                    },
                },
                "api_type": "rest",
            },
            {
                "name": "country_info.capital",
                "description": "Fetch the capital city of a specified country.",
                "parameters": {
                    "country": {
                        "type": "string",
                        "description": "Name of the country.",
                        "required": True,
                    },
                },
                "api_type": "rest",
            },
            {
                "name": "country_info.population",
                "description": "Fetch the current population of a specifie country.",
                "parameters": {
                    "country": {
                        "type": "string",
                        "description": "Name of the country.",
                        "required": True,
                    },
                },
                "api_type": "rest",
            },
        ],
    },
    {
        "query": "Compute the Euclidean distance between two points A(3,4) and B(1,2).",
        "functions": [
            {
                "name": "EuclideanDistance.calculate",
                "description": "Calculate the Euclidean distance between two points.",
                "parameters": {
                    "pointA": {
                        "type": "array",  ##"items": {"type": "integer"},
                        "description": "Coordinates for Point A.",
                        "required": True,
                    },
                    "pointB": {
                        "type": "array",  ##"items": {"type": "integer"},
                        "description": "Coordinates for Point B.",
                        "required": True,
                    },
                    "rounding": {
                        "type": "integer",
                        "description": "Optional: The number of decimals to round off the result. Default 0",
                    },
                },
                "api_type": "rest",
            },
            {
                "name": "angleToXAxis.calculate",
                "description": "Calculate the angle between two points with respect to x-axis.",
                "parameters": {
                    "pointA": {
                        "type": "array",  ##"items": {"type": "integer"},
                        "description": "Coordinates for Point A.",
                        "required": True,
                    },
                    "pointB": {
                        "type": "array",  ## "items": {"type": "integer"},
                        "description": "Coordinates for Point B.",
                        "required": True,
                    },
                    "rounding": {
                        "type": "integer",
                        "description": "Optional: The number of decimals to round off the result. Default 0",
                    },
                },
                "api_type": "rest",
            },
        ],
    },
]


class TestSimpleFunctionCalling(unittest.TestCase):

    @patch("gin.gen.agents.tool_calling.apply_tool_calling")
    def test_simepl_function_calling(self, get_mock):

        def apply_tool_calling(
            initial_state: ToolCallingState,
            log_level: str = None,
        ) -> dict[str, Any] | Any:
            return None

        get_mock.side_effect = apply_tool_calling

        for test_query in test_queries:
            query = test_query["query"]
            functions = test_query["functions"]

            output = simple_tool_calling(
                config_file=CONFIG_FILE,
                functions=functions,
                query=query,
                log_level="DEBUG",
            )
            self.assertIsNone(output)


if __name__ == "__main__":
    unittest.main()
