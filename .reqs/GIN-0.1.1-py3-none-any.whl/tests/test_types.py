import unittest

import gin.gen.types


class TestTypes(unittest.TestCase):

    def test_issues(self):
        api_call = gin.gen.types.ApiCallInf(raw_str="api_call")
        issues = gin.gen.types.ApiCallStaticIssues(api_call=api_call)
        self.assertEqual(issues.has_issues(), False)
        issues = gin.gen.types.ApiCallStaticIssues(
            api_call=api_call, syntax_error=True
        )
        self.assertEqual(issues.has_issues(), True)
        issues = gin.gen.types.ApiCallStaticIssues(
            api_call=api_call, call_hallucinated=True
        )
        self.assertEqual(issues.has_issues(), True)
        issues = gin.gen.types.ApiCallStaticIssues(
            api_call=api_call, param_hallucinated=["para"]
        )
        self.assertEqual(issues.has_issues(), True)
        issues = gin.gen.types.ApiCallStaticIssues(
            api_call=api_call, param_mistyped=["param"]
        )
        self.assertEqual(issues.has_issues(), True)
        issues = gin.gen.types.ApiCallStaticIssues(
            api_call=api_call, param_missing=["arg"]
        )
        self.assertEqual(issues.has_issues(), True)
        issues = gin.gen.types.ApiCallStaticIssues(
            api_call=api_call, blank_substring=1
        )
        self.assertEqual(issues.has_issues(), True)
        issues = gin.gen.types.ApiCallStaticIssues(
            api_call=api_call, invalid_pair=["arg5"]
        )
        self.assertEqual(issues.has_issues(), True)
        issues = gin.gen.types.ApiCallStaticIssues(
            api_call=api_call, repeated_arg=["param=5"]
        )
        self.assertEqual(issues.has_issues(), True)
        issues = gin.gen.types.ApiCallStaticIssues(
            api_call=api_call, invalid_value=["arg=x"]
        )
        self.assertEqual(issues.has_issues(), True)


if __name__ == "__main__":
    unittest.main()
