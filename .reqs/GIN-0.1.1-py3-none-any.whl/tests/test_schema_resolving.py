import unittest
from gin.gen.loaders import ref_resolver


# to use as base_log when running the test for catching logged messages
class DummyLogger:

    def __init__(self):
        self.errors = []
        self.warnings = []

    def error(self, msg, *args):
        self.errors.append(msg % args)

    def warning(self, msg, *args):
        self.warnings.append(msg % args)


dummy_log = DummyLogger()

# Mocking base_log to use the dummy logger in tests
ref_resolver.base_log = dummy_log


class TestResolveRef(unittest.TestCase):

    def setUp(self):
        # Reset the dummy logger before each test
        dummy_log.errors = []

    def test_resolve_simple_reference(self):
        spec = {
            "components": {
                "schemas": {
                    "A": {
                        "type": "object",
                        "properties": {"name": {"type": "string"}},
                    }
                }
            }
        }
        ref_obj = {"$ref": "#/components/schemas/A"}
        expected = {
            "type": "object",
            "properties": {"name": {"type": "string"}},
        }
        result = ref_resolver.resolve_ref_for_object(spec, ref_obj)
        self.assertEqual(result, expected)

    def test_resolve_nested_references(self):
        spec = {
            "components": {
                "schemas": {
                    "A": {"$ref": "#/components/schemas/B"},
                    "B": {
                        "type": "object",
                        "properties": {"id": {"type": "integer"}},
                    },
                }
            }
        }
        ref_obj = {"$ref": "#/components/schemas/A"}
        expected = {
            "type": "object",
            "properties": {"id": {"type": "integer"}},
        }
        result = ref_resolver.resolve_ref_for_object(spec, ref_obj)
        self.assertEqual(result, expected)

    def test_circular_reference(self):
        spec = {
            "components": {
                "schemas": {
                    "A": {"$ref": "#/components/schemas/B"},
                    "B": {"$ref": "#/components/schemas/A"},
                }
            }
        }
        ref_obj = {"$ref": "#/components/schemas/A"}
        result = ref_resolver.resolve_ref_for_object(spec, ref_obj)
        # when detecting circular dependency we send a warning and keep the ref
        self.assertEqual(result, "#/components/schemas/A")
        self.assertTrue(
            any(
                "Circular reference detected" in warn
                for warn in dummy_log.warnings
            )
        )

    def test_list_of_dicts_with_references(self):
        spec = {
            "components": {
                "schemas": {
                    "A": {
                        "type": "object",
                        "properties": {"name": {"type": "string"}},
                    },
                    "B": {
                        "type": "object",
                        "properties": {
                            "items": {
                                "type": "array",
                                "items": {"$ref": "#/components/schemas/A"},
                            }
                        },
                    },
                }
            }
        }
        ref_obj = {
            "type": "array",
            "items": {"$ref": "#/components/schemas/B"},
        }
        expected = {
            "type": "array",
            "items": {
                "type": "object",
                "properties": {
                    "items": {
                        "type": "array",
                        "items": {
                            "type": "object",
                            "properties": {"name": {"type": "string"}},
                        },
                    }
                },
            },
        }
        result = ref_resolver.resolve_ref_for_object(spec, ref_obj)
        self.assertEqual(result, expected)

    def test_multiple_instances_of_same_reference(self):
        spec = {
            "components": {
                "schemas": {
                    "A": {
                        "type": "object",
                        "properties": {"name": {"type": "string"}},
                    },
                    "B": {
                        "type": "object",
                        "properties": {
                            "first": {"$ref": "#/components/schemas/A"},
                            "second": {"$ref": "#/components/schemas/A"},
                        },
                    },
                }
            }
        }
        ref_obj = {"$ref": "#/components/schemas/B"}
        expected = {
            "type": "object",
            "properties": {
                "first": {
                    "type": "object",
                    "properties": {"name": {"type": "string"}},
                },
                "second": {
                    "type": "object",
                    "properties": {"name": {"type": "string"}},
                },
            },
        }
        result = ref_resolver.resolve_ref_for_object(spec, ref_obj)
        self.assertEqual(result, expected)

    def test_external_reference(self):
        spec = {
            "components": {
                "schemas": {
                    "A": {"$ref": "https://api.example.com/schemas/Pet.yaml"}
                }
            }
        }
        ref_obj = {"$ref": "#/components/schemas/A"}
        with self.assertRaises(NotImplementedError) as context:
            ref_resolver.resolve_ref_for_object(spec, ref_obj)
        self.assertTrue(
            "Only local references are supported" in str(context.exception)
        )

    def test_nonexistent_reference(self):
        spec = {
            "components": {
                "schemas": {"A": {"$ref": "#/components/schemas/Nonexistent"}}
            }
        }
        ref_obj = {"$ref": "#/components/schemas/A"}
        with self.assertRaises(KeyError) as context:
            ref_resolver.resolve_ref_for_object(spec, ref_obj)
        self.assertTrue("Cannot complete reference" in str(context.exception))


if __name__ == "__main__":
    unittest.main()
