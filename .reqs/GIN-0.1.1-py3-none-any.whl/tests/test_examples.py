import unittest
import os.path
import glob

from gin.common.con_spec import ConnectorSpec, import_connector_from_file


class TestExamples(unittest.TestCase):

    def _test_import_connector_from_file(self, filename: str):
        # Act
        result = import_connector_from_file(filename)

        # Assert
        assert isinstance(result, ConnectorSpec)

    def test_connector_specs(self):
        specs_path = os.path.join("examples", "connector_specs")
        # Assisted by WCA@IBM
        # Latest GenAI contribution: ibm/granite-20b-code-instruct-v2

        for file in glob.glob(os.path.join(specs_path, "*.yaml")):
            self._test_import_connector_from_file(file)


if __name__ == "__main__":
    unittest.main()
