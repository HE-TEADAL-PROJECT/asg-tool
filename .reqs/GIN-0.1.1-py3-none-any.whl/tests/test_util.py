import pytest
import gin.gen.util as util
from gin.common.util import get_fstring_kwords


@pytest.mark.parametrize(
    "input_str, expected",
    [
        ("PascalCase", "pascal_case"),
        ("camelCase", "camel_case"),
        ("snake_case", "snake_case"),
        ("ABCdef", "ab_cdef"),
        ("AbCdEf", "ab_cd_ef"),
        ("abCde", "ab_cde"),
        ("ABCDE", "abcde"),
        ("", ""),
        ("space var", "spacevar"),
    ],
)
def test_to_snake_case(input_str, expected):
    assert util.to_snake_case(input_str) == expected


@pytest.mark.parametrize(
    "input_str, expected",
    [
        ("PascalCase", "PascalCase"),
        ("camelCase", "CamelCase"),
        ("snake_case", "SnakeCase"),
        ("ABCdef", "ABCdef"),
        ("AbCdEf", "AbCdEf"),
        ("abCde", "AbCde"),
        ("ABCDE", "ABCDE"),
        ("", ""),
        ("space var", "Spacevar"),
    ],
)
def test_to_pascal_case(input_str, expected):
    assert util.to_pascal_case(input_str) == expected


@pytest.mark.parametrize(
    "input_str, expected",
    [
        (
            """{"name": "sentiment_analysis", "arguments": '{"text": "I love the food here! It\'s always fresh and delicious.", "language": "English"}'}""",
            """{"name": "sentiment_analysis", "arguments": '{"text": "I love the food here! It\'s always fresh and delicious.", "language": "English"}'}""",
        ),
        ('{"name": "\\/\\b\\f\\n\\r\\t"}', '{"name": "\\/bfnrt"}'),
    ],
)
def test_remove_invalid_json_escapes(input_str, expected):
    assert util.remove_invalid_json_escapes(input_str) == expected


@pytest.mark.parametrize(
    "input_str, expected",
    [
        ('some.call(param=4, arg = "bla bla")', True),
        ("function_call()", True),
        ("some.call(", False),
        (".notvalid()", False),
    ],
)
def test_func_call_format_good(input_str, expected):
    assert util.func_call_format_good(input_str) == expected


@pytest.mark.parametrize(
    "input_str, expected_kv, expected_issues",
    [
        ("func_call()", {}, {}),
        ("func_call(param=5)", {"param": 5}, {}),
        ('func_call(param="a_str", n= 2.0)', {"param": "a_str", "n": 2.0}, {}),
        (
            'func_call(param="a=str", n={"a": 4})',
            {"param": "a=str", "n": {"a": 4}},
            {},
        ),
        (
            'func_call(param="=\'=a=str", x=, n={"a": 4})',
            {"param": "='=a=str", "x": None, "n": {"a": 4}},
            {"invalid_value": ["x="]},
        ),
        (
            '  func_call(param="a_str", , n = 2.0)',
            {"param": "a_str", "n": 2.0},
            {"blank_substring": 1},
        ),
        (
            'func_call( var, param="a_str",n =2.0) ',
            {"param": "a_str", "n": 2.0},
            {"invalid_pair": ["var"]},
        ),
        (
            '  func_call(\nparam=9, param="a_str", n = 2.0) ',
            {"param": 9, "n": 2.0},
            {"repeated_arg": ['param="a_str"']},
        ),
        (
            'func_call(param="a_str", str=nope, n = 2.0)',
            {"param": "a_str", "n": 2.0, "str": None},
            {"invalid_value": ["str=nope"]},
        ),
        (
            'func_call(param="a_str", str="nope, n = 2.0)',
            {"param": "a_str", "str": None},
            {"invalid_value": ['str="nope, n = 2.0']},
        ),
        ("func_call param=5)", {}, {}),
        ("func_call(\nparam=5,\n)", {"param": 5}, {}),
    ],
)
def test_get_kv_pairs(input_str, expected_kv, expected_issues):
    kv_pairs, issues = util.get_kv_pairs(input_str)
    assert kv_pairs == expected_kv
    assert issues == expected_issues


@pytest.mark.parametrize(
    "input_str, expected",
    [
        (
            "Some {f-string} a{b}{CD}e{f}.{g}",
            ["f-string", "b", "CD", "f", "g"],
        ),
        ("Bla {foo} not {bar {baz}", ["foo", "baz"]),
        ("empty", []),
    ],
)
def test_get_fstring_kwords(input_str, expected):
    assert get_fstring_kwords(input_str) == expected
